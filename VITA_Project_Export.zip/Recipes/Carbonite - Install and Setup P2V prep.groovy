/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "Carbonite - Install and Setup (P2V prep)",
  "Description": "",
  "VersionNumber": 4
}


*********TransitionManager-Recipe-Script*********/



groups: [
	[
        name: 'cm_migrate_vms',
        description: 'All VMs being migrated with Carbonite',
        filter : [
            class: 'device',
			asset: [
				custom1: 'P2V',
			],
        ],
    ],
],
tasks: [

	// Start Wave
	[
        id:1,
        title: 'Start Install/Configuration Wave',
        type: 'milestone',
        team: 'PROJ_MGR',
    ],
	[
		id: 5,
		title: 'Install Carbonite Agent: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Agent - 1. Push Install - Via Setup.exe'
		],
        filter: [
            group: 'cm_migrate_vms'
        ]
		
	],
	[
		id: 10,
		title: 'Activate License: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Agent - 2. Activate License'
		],
        filter: [
            group: 'cm_migrate_vms'
        ]
		
	],
    [
		id: 15,
		title: 'Apply Server Configuration: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Agent - 3. Apply Server Settings from TM'
		],
		filter: [
            group: 'cm_migrate_vms'
        ]
	],
	[
		id: 20,
		title: 'Get Recommended Job Options: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Agent - 4. Get Recommended Job Options'
		],
        filter: [
            group: 'cm_migrate_vms'
        ]
	],
    [
		id: 40,
		title: 'Create Replication Job: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Replication Job - 1. Create Job'
		],
		filter: [
            group: 'cm_migrate_vms'
        ]
		
	],

    [
		id: 50,
		title: 'Start Replication Job: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'Carbonite - Replication Job - 2. Start Job'
		],
		filter: [
            group: 'cm_migrate_vms'
        ]
		
	],

	

	// Wave Complete
	[
        id:10000,
        title: 'Complete Wave',
        type: 'milestone',
        team: 'PROJ_MGR',
    ],
]


