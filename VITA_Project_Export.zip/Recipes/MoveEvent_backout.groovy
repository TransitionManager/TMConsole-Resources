/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "MoveEvent_backout",
  "Description": "",
  "VersionNumber": 1
}


*********TransitionManager-Recipe-Script*********/


// VITA move event backout recipe

groups: 
		[
		
		// Application groups

			[
				name: 'ALL_APPS',
				filter: [
					class: 'application',
				],
			],

			[
				name: 'APPS_W_DB',
				filter: [
					class: 'device',
					dependency: [
						class: 'application',
						mode: 'requires',
						type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
					],
				],
			],
			[
				name: 'APPS_WO_DB',
				filter: [
					class: 'application',
					include: 'ALL_APPS',
					exclude: 'APPS_W_DB',
				],
			],			
			[
				name: 'APPS_W_RUNS_ON',
				filter: [
					class: 'device',
					dependency: [
						class: 'application',
						mode: 'requires',
						type: [ 'RUNS ON'],
					],
				],
			],			
			[
				name: 'APPS_WO_RUNS_ON',
				filter: [
					class: 'application',
					include: 'ALL_APPS',
					exclude: 'APPS_W_RUNS_ON',
				],
			],
			[
				name: 'APPS_W_DB_AND_RUNS_ON',
				filter: [
					class: 'application',
					include: 'APPS_W_DB',
					exclude: 'APPS_WO_RUNS_ON',
				],
			],

		// Server groups

			[
				name: 'ALL_SERVERS',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Blade', 'Server', 'VM', ],
					],
				],
			],
			[
				name: 'BLADES',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Blade', ],
					],
				],
			],			
			[
				name: 'RACK-MOUNTED_SERVERS',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Server', ],
					],
				],
			],			
			[
				name: 'PHYSICAL_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					asset: [ 
						physical: true, 
					],
				],
			],
			[
				name: 'VIRTUAL_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					exclude: 'PHYSICAL_SERVERS',
				],
			],			
			[
				name: 'VMWARE_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						assetType: 'VM',
						custom1: 'V2V'
					],
				],
			],
			[
				name: 'DMZ_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom56: '%DMZ%',
					],
				],
			],			

			// Server move-method groups

			[
				name: 'LPARS_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'LPAR',
					],
				],
			],
			[
				name: 'L&S_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'L&S',
					],
				],
			],
			[
				name: 'V2V_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'V2V',
					],
				],
			],
			[
				name: 'P2V_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'P2V',
					],
				],
			],
			

			[
				name: 'APP_VMS',
				filter: [
					class: 'application',
					dependency: [ 
						class: 'device',
						mode: 'supports',
						type: [ 'Runs On', ],
					],
				],
			],			
			[
				name: 'DB_SERVERS',
				filter: [
					class: 'application',
					dependency: [ 
						class: 'device',
						mode: 'supports',
						type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
					],
				],
			],
			[
				name: 'APP_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_VMWARE_SERVERS',
				filter: [
					class: 'device',
					include: 'VMWARE_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_LPARS',
				filter: [
					class: 'device',
					include: 'LPARS_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_PHYSICALS',
				filter: [
					class: 'device',
					include: 'PHYSICAL_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
						[
				name: 'APP_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'P2V_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_NON_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'APP_SERVERS',
					exclude: 'P2V_SERVERS',
				],
			],			
			[
				name: 'DB_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'P2V_SERVERS',
					exclude: 'APP_SERVERS',
				],
			],
			[
				name: 'DB_NON_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'DB_SERVERS',
					exclude: 'P2V_SERVERS',
				],
			],

			// VLANs

			[
				name: 'VLANS',
				filter: [
					class: 'device',
					asset: [
						assetName: '%VLAN%'
					],				
				],
			],
		],			
		
tasks:
		[						
			[
				id: 1000,
				title: 'Start move event backouts',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
			[
				id: 1700,
				title: '${it.assetName}: Confirm that backout of migrated servers is required',
				team: 'PROJ_MGR',
				duration: 1,
				filter: [
					group: 'ALL_APPS',
				],
            ],
          	[
            	id: 2400,
            	title: '${it.assetName}: Bring down target VM',
            	team: 'SYS_ADMIN',
            	duration: 10,
            	filter: [
           			group: 'VMWARE_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            	],
          	],         	
          	[
            	id: 2420,
            	title: '${it.assetName}: Bring up original VM',
            	team: 'SYS_ADMIN',
            	duration: 10,
            	filter: [
           			group: 'VMWARE_SERVERS',
            	],
          	], 
/*          [
            	id: 2450,
            	title: '${it.assetName}: Bring up databases on original physical server',
            	team: 'DB_ADMIN',
            	duration: 20,
            	filter: [
            		group: 'DB_SERVERS',
            	],
          	],        	        	          
 */                   	
          	[
				id: 2800,
				title: '${it.assetName}: Re-enable auto-start mechanisms and start up application',
				whom: '#startupBy',
				team: '',
				duration: '#startupDuration,7',	
//				duration: '#custom36,27', //P2V SU duration	
				category: 'startup',
				filter: [
					group: 'ALL_APPS',
				],
				predecessor: [
            		classification: 'device',
            		mode: 'supports',
//            		taskSpec: [ 2600, 2700 ],
            	],
            ],
            [
				id: 4600,
				title: '${it.assetName}: Conduct application testing and record results',
				whom: '#testingBy',
				team: '',
				duration: '#testingDuration,27',				
				category: 'startup',
				filter: [
					class: 'application',
					group: 'ALL_APPS',
				],          
            ],          
          	[
				id: 4900,
				title: '${it.assetName}: All backout tasks, testing complete',
				team: 'AUTO',
				duration: 1,				
				filter: [
					group: 'ALL_APPS',
				],
            ],
			[
				id: 5000,
				title: 'Resume backups',
				team: 'BACKUP_ADMIN',
//				team: 'DC_OPS',				
				duration: 7,
				type: 'general',
				category: 'moveday',					
			],
			[
				id: 5100,
				title: 'Unmute monitoring alerts',
				team: 'MONITORING_ADMIN',
//				team: 'DC_OPS',				
				duration: 7,
				type: 'general',
				category: 'moveday',
				predecessor: [
            		taskSpec: 5000,
            	]					
			],			                        
          	[
				id: 10000,
				title: 'P2V backout complete complete',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
		]
/* tasks: 
		[
          	[
            	id: 90,
            	title: '${it.assetName}: Physical server in move event!',
            	team: 'MOVE_TECH',
            	duration: 7,
            	filter: [
            		class: 'device',
            		group: 'PHYSICAL_SERVERS',
            	],
          	],			
          	[
				id: 100,
				title: 'Start Roll call',
				type: 'milestone',
				team: 'PROJ_MGR',
			],			
			[
				id: 200,
				action: 'rollcall',
				category: 'premove',
			],
			[
				id: 300,
				title: 'Roll call complete',
				type: 'milestone',
				team: 'AUTO',
			],		
			[
				id: 400,
				title: 'Confirm T- tasks complete',
				team: 'PROJ_MGR',
				type: 'milestone',
				category: 'moveday',
			],
			[
				id: 405,
				title: 'Begin prep tasks',
				team: 'AUTO',
				type: 'general',
				duration: 7,
				category: 'moveday',			
			],
			[
				id: 410,
				title: 'Auto-milestone',
				type: 'milestone',
				team: 'AUTO',
			],			
			[
				id: 420,
				title: 'Confirm backups for moving servers',
				team: 'BACKUP_ADMIN',
				type: 'milestone',
				duration: 7,
				category: 'moveday',			
			],			
			[
				id: 700,
				title: 'Pause backups for moving servers',
				team: 'BACKUP_ADMIN',
				duration: 7,
				type: 'general',
				category: 'moveday',
       			predecessor: [
            		taskSpec: 410,
            	]					
			],
			[
				id: 750,
				title: 'Mute monitoring alerts for moving servers',
				team: 'MONITORING_ADMIN',
//				team: 'DC_OPS',				
				duration: 7,
				type: 'general',				
				category: 'moveday',
				predecessor: [
            		taskSpec: 410,
            	]				
			],			
			[
                id: 800,
                title: 'Confirm JOC (804 416 7952 / vitajoc@vita.virginia.gov) notified of event start, change record marked as started',
                team: 'PROJ_MGR',
                duration: 7,
                type: 'general',                
                category: 'moveday',
                predecessor: [
                    taskSpec: 410,
                ]               
            ],          
			[
				id: 1000,
				title: 'Start move event',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
/*          	[
            	id: 1600,
            	title: '${it.assetName}: Disable auto-start mechanisms for app components and DBs',
				team: 'SYS_ADMIN',
				duration: 7,				
            	filter: [
            		class: 'device',
            		group: 'ALL_SERVERS',
            	],
          	],
*/
/*
			[
				id: 1600,
				title: '${it.assetName}: Disable auto-start mechanisms for app components and DBs',
				team: 'SYS_ADMIN',
				duration: 7,				
				category: 'shutdown',
				filter: [
					class: 'device',
					group: 'ALL_SERVERS',
				],
            ],
*//*
			[
				id: 1700,
				title: '${it.assetName}: Disable auto-start mechanisms and shut down application',
				whom: '#shutdownBy',
				team: '',
                sendNotification: true,
				duration: '#shutdownDuration,7',				
				category: 'shutdown',
				filter: [
					class: 'application',
					group: 'ALL_APPS',
				],
// 				predecessor: [
//            		classification: 'device',
//            		mode: 'supports',
//            	],           
            ],
            [
            	id: 1900,
            	title: '${it.assetName}: Shut down app server',
            	team: 'SYS_ADMIN',
            	duration: 7,
            	filter: [
            		group: 'APP_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            	]
          	],
          	[
            	id: 2200,
            	title: '${it.assetName}: App servers are shut down',
            	team: 'AUTO',
            	filter: [ 
					class: 'application',
            		group: 'APPS_W_DB_AND_RUNS_ON',
            	],
            	predecessor: [
            		classification: 'device',
            		mode: 'supports',
            		type: 'Runs On',
            	],
            ],
        	[
            	id: 2250,
            	title: '${it.assetName}: App servers are shut down (DB-only apps)',
            	team: 'AUTO',
            	filter: [ 
					class: 'application',
            		group: 'APPS_WO_RUNS_ON',
            	],
            ],
 
            [
            	id: 2300,
            	title: '${it.assetName}: Shut down DB server',
            	team: 'SYS_ADMIN',
            	duration: 7,
            	filter: [
            		class: 'device',
            		group: 'DB_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            	]
          	],

// VMs (HCX) moves
          
           [
            	id: 3400,
            	title: '${it.assetName}: Monitor until HCX job is protected [TMD]',
            	team: 'SYS_ADMIN',
            	filter: [ 
             		class: 'device',
           			group: 'VMWARE_SERVERS',
            	],
            ],
            [
            	id: 3500,
            	title: '${it.assetName}: Invoke failover',
            	team: 'SYS_ADMIN',
            	filter: [ 
            		class: 'device',
            		group: 'ALL_SERVERS',
            	],
            ],
            [
            	id: 3600,
            	title: '${it.assetName}: Monitor until failover is done [TMD]',
            	team: 'SYS_ADMIN',
                sendNotification: true,
            	filter: [ 
            		class: 'device',
            		group: 'ALL_SERVERS',
            	],
            ],
            [
            	id: 3700,
            	title: '${it.assetName}: Validate server in QTS [TMD]',
            	team: 'SYS_ADMIN',
                sendNotification: true,
	           	filter: [ 
            		class: 'device',
            		group: 'ALL_SERVERS',
            	],
            ],         	
			[
            	id: 4000,
            	title: '${it.assetName}: Restart DB server',
            	team: 'SYS_ADMIN',
            	duration: 7,
            	filter: [
            		class: 'device',
            		group: 'DB_SERVERS',
            	],
          	],

          	[
            	id: 4100,
            	title: '${it.assetName}: DB servers are started',
            	team: 'AUTO',
            	filter: [ 
					class: 'application',
            		group: 'APPS_W_DB',
            	],
            	predecessor: [
            		classification: 'device',
            		mode: 'supports',
						type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
            	],
            ],           	

            [
            	id: 4300,
            	title: '${it.assetName}: DB servers are started (no DB-apps)',
            	team: 'AUTO',
            	filter: [ 
					class: 'application',
            		group: 'APPS_WO_DB',
            	],
            ],
            [
            	id: 4400,
            	title: '${it.assetName}: Restart app server',
            	team: 'SYS_ADMIN',
            	duration: 7,
            	filter: [
            		class: 'device',
            		group: 'APP_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            		taskSpec: 3700,
            	]
          	],
           	[
            	id: 4450,
            	title: '${it.assetName}: App servers are started (no App-apps)',
            	team: 'AUTO',
            	filter: [ 
					class: 'application',
            		group: 'APPS_WO_RUNS_ON',
            	],
            ],         	
            [
				id: 4500,
				title: '${it.assetName}: Re-enable auto-start mechanisms and start up application',
				whom: '#startupBy',
				team: '',
				duration: '#startupDuration,7',				
                sendNotification: true,
				category: 'startup',
				filter: [
					class: 'application',
					group: 'ALL_APPS',
				],
 				predecessor: [
            		classification: 'device',
            		mode: 'supports',
					taskSpec: [ 4300, 4450 ],
            	],           
            ],
            [
				id: 4600,
				title: '${it.assetName}: Conduct application testing and record results',
				whom: '#testingBy',
				team: '',
				duration: '#testingDuration,7',				
                sendNotification: true,
				category: 'startup',
				filter: [
					class: 'application',
					group: 'ALL_APPS',
				],          
            ],
          	[ 			
            	id: 4700,
            	title: '${it.assetName}: Unmute monitoring alerts',
            	team: 'MONITORING_ADMIN',
            	duration: 17,
                sendNotification: true,
            	filter: [
            		group: 'ALL_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            	],
          	],           
         	[
				id: 4800,
				title: '${it.assetName}: All server tasks, testing complete',
				team: 'AUTO',
				duration: 1,				
				filter: [
					group: 'ALL_APPS',
				],
				predecessor: [
            		classification: 'device',
            		mode: 'supports',
            	],
            ],
			[
				id: 5000,
				title: 'Resume backups',
				type: 'action',
				action: 'set',
				setOn: 'assetType',
				team: 'BACKUP_ADMIN',
//				team: 'DC_OPS',				
                sendNotification: true,
				duration: 1,				
				filter: [
					group: 'ALL_APPS',
				],

			],            

			[
				id: 10000,
				title: 'Move event complete',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
        ],
*/


