/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "rvTools",
  "Description": "",
  "ProviderName": "VMware",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/**
  		TransitionManager ETL Script
 		Provider: RV Tools
 		Script Name: RV Tools - Import 
 		Script Version: v3.4

		Compatibility Notes:
			- as of version 3.2 of this script, the Minimum TM Version is 4.5.1


	Description:
 		This ETL DataScript will process the RVTools Extract spreadsheet to create/update VM devices and the clusters as Applications
 	that the represent the cluster. The final phase of the script will create/update the dependency between the VM and the Cluster.
 
 */

	enable lookup

//************************************
// Config Switches 		true | false
//***********************************/
def configProcessDatastores = 'false'
def configProcessvDisks = 'false'
def configProcessvPartitions = 'false'
def configProcessvTools = 'true'
def matchVMOnNameAloneVar = 'true'
def matchHostOnNameAloneVar = 'true'



//************************************
// Script Settings
//***********************************/
def templateBundleNameVar = 'VM Template Device'
def clusterBundleNameVar = 'VM Clusters'
def newDeviceBundleNameVar = "New Devices from RVTools"
def vmWareMfgVar = "VMware"
def vmWareModelVar = "VM"



//
// Process the Clusters first
//
sheet 'vCluster'
read labels
iterate {
	
	// Set the domain
	domain Application

	extract 'Name' transform with prepend('VM Cluster: ') set clusterNameVar load 'Name'

	// Build up the Cluster description
	extract 'numEffectiveHosts' set numEffectiveHostsVar
	extract 'Effective Cpu' set effectiveCpuVar
	extract 'Effective Memory' set effectiveMemoryVar
	extract 'Num VMotions' set numVMotionsVar
	
	set clusterDescVar with \
		"VMware Cluster (# effect hosts: ${numEffectiveHostsVar}, effective CPU: ${effectiveCpuVar}, " + \
		"effective Memory: ${effectiveMemoryVar}MB, # of vMotions: ${numVMotionsVar}"

	load 'Description' with clusterDescVar
	load 'Vendor' with vmWareMfgVar
	load 'Bundle' with clusterBundleNameVar
	load 'Validation' with 'Validated'
    load 'Migration Method' with 'V2V'

	load 'DSLastSeen-RVTools' with NOW

	// Find the Cluster
	find Application by \
		'Vendor' eq vmWareMfgVar \
		and 'Name' eq clusterNameVar \
		into 'id'
	
	elseFind Application by \
		'Name' eq clusterNameVar \
		into 'id'

}
	 


// Process the Hosts and create/update dependency to the Clusters appropriately
sheet 'vHost'
read labels
iterate {

	domain Device

	// Basic Values
	extract 'Host' transform with replaceAll('.company.pvt', '') set hostNameVar load 'Name'
	extract 'Object ID' set objectIdVar
	extract 'Vendor' set mfgVar
	extract 'Model' set modelVar
	load 'IsVirtual' with 'No'
	load 'External Ref Id' with objectIdVar
	load 'Manufacturer' with mfgVar
	load 'Model' with modelVar
	load 'VM ID' with objectIdVar
	extract '# Cores' load 'Processor - Core Count'
	extract '# Memory' load 'Memory'
	extract 'Service tag' load 'assetTag'
	extract 'ESX Version' load 'os' set esxVersionVar
	extract 'Datacenter' set datacenterVar
	find Room by "roomName" eq "TBD" and "location" eq datacenterVar into 'roomSource'
	whenNotFound 'roomSource' create{
		"location" datacenterVar
		"roomName" "TBD"
	}
	
	
	// Set Cluster Name
	extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameVar load 'ClusterName'
	
	// CPU Model contains a string which is split on @.  Before the @ is the Model, after is the Speed.  Available in TM v4.5
	extract 'CPU Model' set cpuModelVar
	// def cpuModelPartsVar = cpuModelVar.split("@") 
	// load 'ProcessorModel' with cpuModelPartsVar.getAt(0)
	// load 'ProcessorSpeed' with cpuModelPartsVar.getAt(1)
	
	// Create Description
	extract '# NICs' load 'NICS' set numNicsVar
	extract '# VMs' set numVMsVar
	extract '# vCPUs' set numVCpusVar
	extract 'vRAM' set vRamVar
	set hostDescVar with "Cluster Host (Nics:${numNicsVar}, # of VMs:${numVMsVar}, # of vCPUs:${numVCpusVar}, RAM:${vRamVar}MB)"
	load 'Description' with hostDescVar
	load 'DSLastSeen-RVTools' with NOW

	// Find the Asset
	find Device by \
		'Name' eq hostNameVar \
		and 'External Ref Id' eq objectIdVar \
		into 'id'
		
	elseFind Device by \
		'Name' eq hostNameVar \
		into 'id'
	
	elseFind Device by \
		'Name' eq hostNameVar \
		into 'id'
	if (matchHostOnNameAloneVar == 'true'){
		elseFind Device by \
			'Name' eq hostNameVar \
			into 'id'
	
	}

	domain Dependency
	// Only create a Dependency if the ClusterName is specified for the VM Device loaded above
	if (clusterNameVar != 'VM Cluster: ') {
		
		load 'id' with '1' // 4.5.1 bug

		// Find the "Top" Asset
		load 'asset' with clusterNameVar
		// find Application by 'Name' eq clusterNameVar and 'Vendor' eq vmWareVar into 'asset'
		find Application by 'Name' eq clusterNameVar into 'asset'

		whenNotFound 'asset' create {
			'Name' clusterNameVar
			'Vendor' vmWareMfgVar
		}

		// Find the "Bottom" Asset
		load 'dependent' with hostNameVar
		find Device by  \
			'Name' eq hostNameVar \
			and 'Manufacturer' eq mfgVar \
			and 'Model' eq modelVar \
			and 'External Ref Id' eq objectIdVar \
			into 'dependent'
		
		elseFind Device by \
			'Name' eq hostNameVar \
			and 'Manufacturer' eq mfgVar \
			and 'External Ref Id' eq objectIdVar \
			into 'dependent'

		elseFind Device by \
			'Name' eq hostNameVar \
			and 'External Ref Id' eq objectIdVar \
			into 'dependent'

		elseFind Device by  \
			'Name' eq hostNameVar \
			and 'Manufacturer' eq mfgVar \
			and 'Model' eq modelVar \
			into 'dependent'

		elseFind Device by  \
			'Name' eq hostNameVar \
			and 'Manufacturer' eq mfgVar \
			into 'dependent'
		
		whenNotFound 'dependent' create {
			'Name' hostNameVar
			'Manufacturer' mfgVar
			'Model' modelVar
			'External Ref Id' objectIdVar
		}

		// Dependency Properties
		load 'type' with 'Cluster Runs On'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		// Comment
		load 'comment' with 'From RV Tools: ' + NOW 
	}

}

// Process Tab: vSC_VMK
// 		This tab is where the IP address details for the Hosts are stored.
sheet 'vSC_VMK'
read labels
iterate {

	// Set the domain
	domain Device
	

	extract 'Host' set hostNameVar
	lookup 'Name' with hostNameVar
	if (LOOKUP.found()) {	
		extract 'Mac Address' set macAddrVar
		extract 'IP Address' set ipAddrVar
		if (ipAddrVar.length() < 255){
			load 'IP Address' transform with append(', ', ipAddrVar)
		}else{
			extract 'IP Address' transform with left(240) set ipL4Var load 'IP Address' transform with append(', ', ipL4Var)
			extract 'IP Address' transform with right(240) set ipR4Var load 'IP Address2' transform with append(', ', ipR4Var)
		}
		load 'MACaddress' transform with append(', ',macAddrVar)
	}
}

/*******
//
// Process Tab: vPort
// 		This tab contains a list of the Physical Hosts ans the Physical ports on them, in addition to the virtual swithes
//


sheet 'vPort'
read labels
iterate {

	// Set the domain
	domain Device
	
	extract 'Host' set hostNameVar
	lookup 'assetName' with hostNameVar
	if (LOOKUP.found()) {	
		extract 'VLAN' transform with left(255) set sourceVLANVar
		load 'Source VLAN'  with  sourceVLANVar
	}
}
******/

// Time to Process the Virtual Machines in the vInfo tab*/
sheet 'vInfo'
read labels
iterate {
	// Set the domain
	domain Device

	// Basic Values
	extract 'VM' load 'Name' set vmNameVar 
	extract 'VM ID' set objectIdVar load 'VM ID'
	extract 'Template' set templateVar 
	extract 'DNS Name' load 'Alternate Name' set dnsNameVar 
	extract 'Powerstate' load 'VM powered'
	extract 'CPUs' load 'Processor - Core Count' set cpuVar
	extract 'Memory' load 'Memory' set memoryVar
	extract 'NICs' load 'NICS'
	extract 'Disks' load 'Disks'
	extract 'Provisioned MB' load 'VMSize'
	extract 'Datacenter' set datacenterVar 
	extract 'OS according to the VMware Tools' load 'OS' set osVar
	extract 'VM UUID' load 'Serial #' set vmUUIDVar
	extract 'HW version' load 'HW version'
    extract 'Network #1' load 'VM Network1'

	extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameVar load 'ClusterName'
	extract 'Host' set hostVar

	load 'Manufacturer' with 'VMware'
	load 'DNSName' with dnsNameVar
	load 'Model' with 'VM'
	load 'Device Type' with 'VM'
	load 'VMware UUID' with vmUUIDVar
	load 'IsVirtual' with 'Yes'
    
    load 'Migration Method' with 'V2V'
	
	extract 'Connection state' load 'Connection State'
	extract 'Guest state' load 'Guest State'
	extract 'In Use MB' load 'Disk Used'
	extract 'VI SDK Server' load 'vCenter Information' set vCenterServerVar
	extract 'VM ID' load 'VM ID' set vmIDVar
	extract 'Resource pool' load 'Resource Pool'
	extract 'Provisioned MB' load 'Disk Provisioned'

    extract 'Folder' set fullFolderPath
    load 'Target Folder' with fullFolderPath
    //if(fullFolderPath){
    //    folderName = fullFolderPath.tokenize('/')[-1].trim()
    //    load 'Target Folder' with folderName
    //}

	load 'Validation' with 'Validated'
	load 'DSLastSeen-RVTools' with NOW

	find Room by "roomName" eq "TBD" and "location" eq datacenterVar into 'roomSource'
	whenNotFound 'roomSource' create{
		"location" datacenterVar
		"roomName" "TBD"
	}


	


	// Find the asset
	find Device by \
		'Name' eq vmNameVar \
		and 'Alternate Name' eq dnsNameVar \
		and 'VMware UUID' eq vmUUIDVar \
		and 'VM ID' eq objectIdVar \
		and 'vCenter Information' eq vCenterServerVar \
		into 'id' 
	
	elseFind Device by \
		'Name' eq vmNameVar \
		and 'Alternate Name' eq dnsNameVar \
		and 'VM ID' eq objectIdVar \
		and 'vCenter Information' eq vCenterServerVar \
		into 'id' 
	
	elseFind Device by \
		'Name' eq vmNameVar \
		and 'Alternate Name' eq dnsNameVar \
		and 'VMware UUID' eq vmUUIDVar \
		and 'vCenter Information' eq vCenterServerVar \
		into 'id'
	
	elseFind Device by \
		'Name' eq vmNameVar \
		and 'VM ID' eq objectIdVar \
		and 'VMware UUID' eq vmUUIDVar \
		into 'id'
	
	elseFind Device by \
		'Name' eq vmNameVar \
		and 'VMware UUID' eq vmUUIDVar \
		into 'id'

	if (matchVMOnNameAloneVar == 'true'){
		elseFind Device by \
			'Name' eq vmNameVar \
			into 'id'
	
	}

	if (FINDINGS.size() == 0) {init 'moveBundle' with newDeviceBundleNameVar}  
	if (templateVar == 'True') {load 'moveBundle' with templateBundleNameVar}


	domain Dependency
	if (clusterNameVar != 'VM Cluster: ') {

		load 'id' with '1' // 4.5.1 bug

		// Find the "Top" Asset
		load 'asset' with vmNameVar
		
		find Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			and 'vCenter Information' eq vCenterServerVar \
			into 'asset'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			into 'asset'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VM ID' eq objectIdVar \
			into 'asset'
		
		elseFind Device by \
			'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			into 'asset'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			into 'asset'
		
		whenNotFound 'asset' create {
			'Name' vmNameVar
			'Alternate Name' dnsNameVar
			'VMware UUID' vmUUIDVar
			'VM ID' objectIdVar 
			'vCenter Information' vCenterServerVar 
			
		}

		// Find the "Bottom" Asset
		load 'dependent' with clusterNameVar
		find Application by \
			'Name' eq clusterNameVar \
			and 'Vendor' eq vmWareMfgVar \
			into 'dependent'
		
		elseFind Application by 'Name' eq clusterNameVar into 'dependent'

		whenNotFound 'dependent' create {
			'Name' clusterNameVar
			'Vendor' vmWareMfgVar
		}


		// Dependency Properties
		load 'type' with 'VM Runs On'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'
		
		// Comment
		load 'comment' with 'From RV Tools' + NOW
	} else {
		
		load 'id' with '1' // 4.5.1 bug

		// Find the "Top" Asset
		load 'asset' with vmNameVar
		
		find Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			and 'vCenter Information' eq vCenterServerVar \
			into 'id'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			into 'id'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'Alternate Name' eq dnsNameVar \
			and 'VM ID' eq objectIdVar \
			into 'id'
		
		elseFind Device by \
			'VMware UUID' eq vmUUIDVar \
			and 'VM ID' eq objectIdVar \
			into 'id'
		
		elseFind Device by \
			'Name' eq vmNameVar \
			and 'VMware UUID' eq vmUUIDVar \
			into 'id'
		
		whenNotFound 'asset' create {
			'Name' vmNameVar
			'Alternate Name' dnsNameVar
			'VMware UUID' vmUUIDVar
			'VM ID' objectIdVar 
			'vCenter Information' vCenterServerVar 
			
		}

		// Find the "Bottom" Asset
		load 'dependent' with hostVar
		find Device by \
			'Name' eq hostVar \
			into 'dependent'
		
		whenNotFound 'dependent' create {
			'Name' hostVar
		}


		// Dependency Properties
		load 'type' with 'VM Runs On'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'
		
		// Comment
		load 'comment' with 'From RV Tools' + NOW
		
	}
}

// Tab: vCPU - VM Guest Related CPU info
sheet 'vCPU'
        read labels
        iterate {

            // Set the domain
            domain Device

            extract 'VM' set vmNameVar
            extract 'VM ID' set vmIDVar
            lookup 'VM ID' with vmIDVar
            if (LOOKUP.found()) {   
                
                extract 'CPUs' load 'Processor - Core Count'
                extract 'Cores p/s' load 'Cores Per Processor'
            }
        }

// Tab: vNetwork - VM Guest Related IP and Mac address info
sheet 'vNetwork'
read labels
iterate {

	// Set the domain
	domain Device

	extract 'VM' set vmNameVar
	extract 'VM ID' set vmIDVar
    lookup 'VM ID' with vmIDVar
    if (LOOKUP.found()) {   
		extract 'Adapter' set adaptorVar
		extract 'Network' set networkVar
		extract 'Mac Address' set macAddressVar
		extract 'IP Address' set ipAddrVar
		
		load 'NetworkAdapter' transform with append(', ',adaptorVar)
		load 'Network' transform with append(', ',networkVar)
		load 'MACaddress' transform with append(', ',macAddressVar)
		if (ipAddrVar != 'unknown') {
			if (ipAddrVar.length() < 255){
				load 'IP Address' transform with append(', ', ipAddrVar)
			}else{
				extract 'IP Address' transform with left(240) set ipL4Var load 'IP Address' transform with append(', ', ipL4Var)
//				extract 'IP Address' transform with right(240) set ipR4Var load 'IP Address2' transform with append(', ', ipR4Var)
			}
        }
	}
}

if (configProcessvTools == "true"){
	// Tab: vTools - VM Tools Data for VM Record
	sheet 'vTools'
	read labels
	iterate {
	
		// Set the domain
		domain Device
	
		extract 'VM' set vmNameVar
		extract 'VM ID' set vmIDVar
		lookup 'VM ID' with vmIDVar
		if (LOOKUP.found()) {    
			extract 'Tools' load 'Tools Status'
			extract 'Tools Version' load 'Tools Version'
	
		}
	}
}


if(configProcessDatastores == "true"){
	// Process Tab: vDatastore
	// 		This tab is where the Data Stores are listed
	sheet 'vDatastore'
	read labels
	iterate {

		// Set the domain
		domain Storage
		
		extract 'Name' load 'Name' set datastoreNameVar
		extract 'Capacity MB' load 'Size' set datastoreSizeVar
		extract 'Hosts' set hostsVar

		extract 'In Use MB' transform with toInteger() set inUseSpaceVar
		
		load 'UsedSizeGB' with inUseSpaceVar / 1024
		load 'Scale' with 'MB'
		load 'FSType' with 'Datastore'

		load 'DSLastSeen-RVTools' with NOW



		// Find Storage Asset
		find Storage by \
			'Name' eq datastoreNameVar \
			and 'Capacity MB' eq datastoreSizeVar \
			and 'FSType' eq 'Datastore' \
			into 'id'
		
		elseFind Storage by \
			'Name' eq datastoreNameVar \
			and 'FSType' eq 'Datastore' \
			into 'id'
        
		elseFind Storage by \
			'Name' eq datastoreNameVar \
			and 'Capacity MB' eq datastoreSizeVar \
			into 'id'
        


		// There is a string or comma separated list of servers in the vDatastore tab.  Collect this and build it as a list. 
		
		// If there is a list, or just a single value
		if (hostsVar.contains(',')){
			def hostListVar = hostsVar.split(',')
			for (host in hostListVar){
				String hostVar = host.trim()
				domain Dependency

				load 'id' with '1' // 4.5.1 bug

				load 'asset' with hostVar
				find Device by 'Name' eq hostVar into 'asset'
				whenNotFound 'asset' create {
					'Name' hostVar
				}

				load 'dependent' with datastoreNameVar
				find Storage by 'Name' eq datastoreNameVar into 'dependent'
				whenNotFound 'dependent' create {
					'Name' datastoreNameVar
					'FSType' 'Datastore'
				}


				load 'type' with 'Storage'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
				load 'comment' with 'From RV Tools: ' + NOW
			}

		}else{
			// Single Server Name
			domain Dependency

			load 'id' with '1' // 4.5.1 bug


			load 'asset' with hostsVar
			find Device by 'Name' eq hostsVar into 'asset'
			whenNotFound 'asset' create {
				'Name' hostsVar
			}

			load 'dependent' with datastoreNameVar
			find Storage by 'Name' eq datastoreNameVar into 'dependent'
			
			whenNotFound 'dependent' create {
				'Name' datastoreNameVar
				'FSType' 'Datastore'

			}
			
			load 'type' with 'Storage'
			load 'status' with 'Validated'
			load 'dataFlowFreq' with 'constant'
			load 'comment' with 'From RV Tools: ' + NOW

		}
	}
}

if(configProcessvPartitions == "true"){
	// Process Tab: vPartition
	// 		This tab is where the VM and the associated vDisk details are reported
	sheet 'vPartition'
	read labels
	iterate {

		// Set the domain
		domain Storage
		
		extract 'VM' set vmNameVar
		extract 'VM' set thisVmNameVar
		extract 'Disk' set diskNameVar
		extract 'Capacity MB' transform with toInteger() set diskCapacityVar load 'Size'
		extract 'Free MB' transform with toInteger() set diskFreeVar

		set uniqueDiskNameVar with vmNameVar + '-' + diskNameVar

		load 'Name' with uniqueDiskNameVar
		load 'Scale' with 'MB'
		load 'FSType' with 'VMware vPartition'

		load 'UsedSizeGB' with ((diskCapacityVar - diskFreeVar) / 1024)

		load 'DSLastSeen-RVTools' with NOW


		// Find the Asset
		find Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'Size' eq diskCapacityVar \
			and 'FSType' eq 'VMware vPartition' \
			into 'id'
		
		elseFind Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'FSType' eq 'VMware vPartition' \
			into 'id'
		
		elseFind Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'Size' eq diskCapacityVar \
			into 'id'
		
		elseFind Storage by 'Name' eq uniqueDiskNameVar into 'id'

		// Create Dependency
		domain Dependency
		
		// Find "Top" Asset
		load 'id' with '1' // 4.5.1 bug
		load 'asset' with thisVmNameVar
		find Device by 'Name' eq thisVmNameVar into 'asset'   // Minimal VM details in this tab to use
		whenNotFound 'asset' create {
			'Name' thisVmNameVar
		}

		// Find "Bottom" Asset
		load 'dependent' with uniqueDiskNameVar
		find Storage by 'Name' eq uniqueDiskNameVar into 'dependent'
		whenNotFound 'dependent' create{
			'Name' uniqueDiskNameVar
		}
		load 'type' with 'vPartition'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		load 'comment' with 'From RV Tools: ' + NOW

	}
}

if(configProcessvDisks == "true"){
	// Process Tab: vPartition
	// 		This tab is where the VM and the associated vDisk details are reported
	sheet 'vDisk'
	read labels
	iterate {

		// Set the domain
		domain Storage
		
		extract 'VM' set vmNameVar
		extract 'Disk' set diskNameVar
		extract 'Capacity MB' transform with toInteger() set diskCapacityVar load 'Size'
		extract 'VM ID' set vmIDVar
		extract 'VM UUID' set vmUUIDVar
		extract 'Path' set pathVar

		set dataStoreVar with pathVar.substring(1,pathVar.indexOf("]"))
		set uniqueDiskNameVar with vmNameVar + '-' + diskNameVar

		load 'Name' with uniqueDiskNameVar
		load 'Scale' with 'MB'
		load 'FSType' with 'VMware vDisk'

		load 'DSLastSeen-RVTools' with NOW

		// Find the Asset
		find Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'Size' eq diskCapacityVar \
			and 'FSType' eq 'VMware vDisk' \
			into 'id'
		elseFind Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'FSType' eq 'VMware vDisk' \
			into 'id'
		elseFind Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'Size' eq diskCapacityVar \
			into 'id'
		elseFind Storage by 'Name' eq uniqueDiskNameVar into 'id'




		// Create Dependency   vDisk to VM
		domain Dependency
		
		// Find "Top" Asset
		load 'id' with '1' // 4.5.1 bug
		load 'asset' with vmNameVar
		find Device by \
			'Name' eq vmNameVar \
			and 'VM ID' eq vmIDVar \
			and 'VMware UUID' eq vmUUIDVar \
			into 'asset'
			

		// Find "Bottom" Asset
		load 'dependent' with uniqueDiskNameVar
		find Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'FSType' eq 'VMware vDisk' \
			into 'dependent'
		
		whenNotFound 'dependent' create{
			'Name' uniqueDiskNameVar
			'FSType' 'VMware vDisk'
		}

		load 'type' with 'vDisk'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		load 'comment' with 'From RV Tools: ' + NOW




		// Create Dependency   vDisk to vDatastore
		domain Dependency
		load 'id' with '1' // 4.5.1 bug
		
		// Find "Top" Asset
		load 'asset' with uniqueDiskNameVar
		find Storage by \
			'Name' eq uniqueDiskNameVar \
			and 'FSType' eq 'vDisk' \
			into 'asset'
		whenNotFound 'asset' create{
			'Name' uniqueDiskNameVar
		}
		
		// Find "Bottom" Asset
		load 'dependent' with dataStoreVar
		//find Storage by \

		find Storage by \
			'Name' eq dataStoreVar \
			and 'FSType' eq 'Datastore' \
			into 'dependent'
		whenNotFound 'dependent' create {
			'Name' dataStoreVar
		}


		load 'type' with 'vDisk'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		load 'comment' with 'From RV Tools: ' + NOW

	}
}



