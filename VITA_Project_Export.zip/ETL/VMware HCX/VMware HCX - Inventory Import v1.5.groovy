/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "VMware HCX - Inventory Import (v1.5)",
  "Description": "",
  "ProviderName": "VMware HCX",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*
	ETL Script: HCX Inventory Import
	Version: 1.5 - Reference Design
	Notes:	
		TODO  This version is starting by prep for VITA. The following configurations are in place but need to be removed prior to release:

			DSLS- loads are disabled.

*/
//////////////////////////////
// ETL Config Switches
//////////////////////////////
enable lookup
def config = [
	processData: [
		containers: 	false,
		sites: 			true,
		vms: 			false
	],
	matchOnNameAlone: [
		cluster: 		false,
		host: 			false,
		vm: 			false
	],
	trimFromName: [
		vm: 			'.tdsops.net',
		host: 			'.tdsops.net'
	],
	defaultBundle: 'HCX Infrastructure',
	hcxTypeToDSOT: [
		vcenter: 'vCenter',
		datacenter: 'Datacenter',
		cluster: 'ClusterComputeResource',
		host: 'HostSystem',
		resourcePool: 'ResourcePool',
		folder: 'Folder',
		computeResource: 'ComputeResource',
		'VmwareDistributedVirtualSwitch': 'VmwareDistributedVirtualSwitch',
		network: 'DistributedVirtualPortgroup'
	]
]
def etlModels =  [
	vmwareCommon: {object ->
		init 'Name' with assetNameVar
		
		// Asset ID Details - HCX
		load 'DSID-VMwwareHCX' with assetIdVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
	},
	cluster: { cluster ->
		domain Application
	
		//Load Asset Property Details
		init 'Name' with assetNameVar
		init 'Bundle' with config.defaultBundle
		load 'DSOT-vCenter' with typeVar

		// VMware vCenter details
		load 'DSID-vCenter' with assetIdVar
		load 'DSEP-vCenter' with siteVar.'Name'

		// VMware HCX details
		load 'DSID-VMwareHCX-UID' with assetUidVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
		// // load 'DSLS-VMwareHCX' with NOW
		// load 'HCX-SourceSite' with siteVar.Name
		// load 'HCX-SourceNetwork' with networkVar.Name.join(',')

	}
]


//////////////////////////////
// Define import order
//////////////////////////////
domain Application
domain Device
domain Storage
domain Dependency

//////////////////////////////
// Script Functions
//////////////////////////////

// Construct a nodeExists function
def ensureArray = { data ->
	if(!data){
		return []
	}
	if (data.getClass().getName() == 'java.util.ArrayList') {
		return data
	} else {
		dataArray = new ArrayList()
		dataArray.add(data)
		return dataArray
	}
}

//////////////////////////////
//  Metadata
//////////////////////////////
def reportingHcxServerVar
rootNode 'Metadata'
read labels
iterate {
	extract 'HCXServer' set metareportingHcxServerVar
	reportingHcxServerVar = metareportingHcxServerVar 
}

//////////////////////////////
//  HCX Sites
//////////////////////////////
if (config.processData.sites){
	
	// Process Sites node - For Source Sites
	rootNode 'Sites.SourceSites'
	read labels
	iterate {
	
		// Create the Site
		//////////////////////////////

		set typeVar with 'HCX Source Site'

		// Set the domain and Class Type
		domain Application

		// Asset ID and Name and Asset Required Details
		extract 'Id' set hcxSiteIdVar
		extract 'Uid' set hcxSiteUidVar
		extract 'Name' set hcxSiteNameVar
		extract 'Name' set vCenterHostnameVar
		extract 'EndpointId' set hcxServerEndpointIdVar
		extract 'EndpointName' set hcxServerHostnameVar
		
		// Create initial names for the assets
		set initHCXServerNameVar with 'HCX Server: ' + hcxServerHostnameVar
		set initSiteNameVar with 'HCX Site: ' + hcxSiteNameVar
		set initvCenterNameVar with 'vCenter: ' + hcxSiteNameVar

		// Some fields only get initialized, not loaded.
		init 'Name' with initSiteNameVar
		init 'moveBundle' with config.defaultBundle
		init 'Vendor' with 'VMware'

		// DataSource Loading:
		//  	DataSource IDs 			(DSID)
		// 		DataSource Object Types (DSOT)
		//		DataSource Endpoints 	(DSEP) 
		//		DataSource Last Seen 	(DSLS) 
		load 'DSID-VMwareHCX' with hcxSiteIdVar
		load 'DSID-VMwareHCX-UID' with hcxSiteUidVar
		load 'DSID-VMwareHCX-EndpointID' with hcxServerEndpointIdVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
		// load 'DSLS-VMwareHCX' with NOW
		
		load 'DSOT-vCenter' with typeVar
		
		// Find the Asset
		find Application by \
			'DSID-VMwareHCX' eq hcxSiteIdVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'

		elseFind Application by \
			'DSID-VMwareHCX-UID' eq hcxSiteUidVar \
			and 'DSEP-VMwareHCX' eq reportingHcxServerVar \
			into 'id'
		elseFind Application by \
			'Name' eq hcxSiteUidVar \
			and 'DSEP-VMwareHCX' eq reportingHcxServerVar \
			into 'id'

		set hcxSiteObjectVar with DOMAIN
		
		
		// Destination HCX Server
		domain Application
		
		lookup 'DSID-VMwareHCX-EndpointID','DSOT-vCenter' \
			with hcxServerEndpointIdVar, 'HCX Server'
		if (LOOKUP.notFound()){
			
			init 'Name' with initHCXServerNameVar
			init 'Bundle' with config.defaultBundle
			
			load 'DSID-VMwareHCX' with hcxServerEndpointIdVar
			load 'DSEP-VMwareHCX' with reportingHcxServerVar
			load 'DSOT-vCenter' with 'HCX Server'
			// load 'DSLS-VMwareHCX' with NOW
			
			load 'Vendor' with 'VMware'
			load 'URL' with hcxServerHostnameVar


			// Dependent: HCX Server
			find Application by \
				'DSID-VMwareHCX' eq hcxServerEndpointIdVar \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// The HCX Server should already exist.
			// Try looking by (1)URL and (2)Name
			// There are 2 references we can use to find the right HCX server, 
			//		(a)hcxServerHostnameVar, from the reported data
			// 		(b)reportingHcxServerVar, the HCX server name in the Metadata from the collection action
			
			// 1a. with the hcxServerHostnameVar in the data
			elseFind Application by \
				'URL' like '%'+hcxServerHostnameVar+'%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// 1b. with the HCX Server in the Metadata
			elseFind Application by \
				'URL' like '%'+reportingHcxServerVar+'%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// 2a. with the hcxServerHostnameVar in the data
			elseFind Application by \
				'Name' like '%' + hcxServerHostnameVar + '%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// 2b. with the HCX Server in the Metadata
			elseFind Application by \
				'Name' like '%' + reportingHcxServerVar + '%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'

		}	
		set hcxServerObjectVar with DOMAIN



		// Destination vCenter
		domain Application

		init 'Name' with initvCenterNameVar
		load 'Bundle' with 'VMware Discovery'
		
		load 'DSID-VMwareHCX-EndpointID' with hcxServerEndpointIdVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
		load 'DSOT-vCenter' with 'vCenter'
		// load 'DSLS-VMwareHCX' with NOW
		
		load 'Vendor' with 'VMware'
		load 'URL' with vCenterHostnameVar

		// FIND Overview - Readme:
		// The vCenter vcenter should already exist.
		// Try looking by (1)URL and (2)Name
		// There are 2 references we can use to find the right HCX server, 
		
		// 0. Use the PK we assign to the vCenter cluster
		find Application by \
			'DSID-VMwareHCX-EndpointID' eq hcxServerEndpointIdVar \
			and 'DSOT-vCenter' eq 'vCenter' \
			into 'id'
		
		// 1a. with the vCenterHostnameVar in the data
		elseFind Application by \
			'DSOT-vCenter' eq 'vCenter' \
			and 'URL' like '%'+vCenterHostnameVar+'%' \
			into 'id'
		
		// 2a. with the vCenterHostnameVar in the data
		elseFind Application by \
			'DSOT-vCenter' eq 'vCenter' \
			and 'Name' like '%' + vCenterHostnameVar \
			into 'id'
		
		set vCenterObjectVar with DOMAIN


		// DEPENDENCIES Dependency Creation
		//////////////////////////////////////
		
		domain Dependency with hcxSiteObjectVar 'HCX Source' hcxServerObjectVar

		load 'c1' with 'HCX Site is run by an HCX Server'
		load 'c4' with NOW
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		domain Dependency with vCenterObjectVar 'HCX Source' hcxSiteObjectVar
		load 'c1' with 'HCX Site contains a vCenter'
		load 'type' with 'HCX Source'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

	}
	
	// Process Sites node - for Destination Sites
	rootNode 'Sites.DestSites'
	read labels
	iterate{
			
		// Create the Site
		//////////////////////////////
		set typeVar with 'HCX Destination Site'

		// Set the domain and Class Type
		domain Application

		// Asset ID and Name and Asset Required Details
		extract 'Id' set hcxSiteIdVar
		extract 'Uid' set hcxSiteUidVar
		extract 'Name' set hcxSiteNameVar
		extract 'Name' set vCenterHostnameVar
		extract 'EndpointId' set hcxServerEndpointIdVar
		extract 'EndpointName' set hcxServerHostnameVar
		// set hcxSiteIdVar with destSite.Id
		// set hcxSiteUidVar with destSite.Uid
		// set hcxSiteNameVar with destSite.Name
		// set vCenterHostnameVar with destSite.Name
		// set hcxServerEndpointIdVar with destSite.EndpointId
		// set hcxServerHostnameVar with destSite.EndpointName

		// Create initial names for the assets
		set initHCXServerNameVar with 'HCX Server: ' + hcxServerHostnameVar
		set initSiteNameVar with 'HCX Site: ' + hcxSiteNameVar
		set initvCenterNameVar with 'vCenter: ' + hcxSiteNameVar

		// Some fields only get initialized, not loaded.
		init 'Name' with initSiteNameVar
		init 'moveBundle' with config.defaultBundle
		init 'Vendor' with 'VMware'

		// DataSource Loading:
		//  	DataSource IDs 			(DSID)
		// 		DataSource Object Types (DSOT)
		//		DataSource Endpoints 	(DSEP) 
		//		DataSource Last Seen 	(DSLS) 
		load 'DSID-VMwareHCX' with hcxSiteIdVar
		load 'DSID-VMwareHCX-UID' with hcxSiteUidVar
		load 'DSID-VMwareHCX-EndpointID' with hcxServerEndpointIdVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
		// load 'DSLS-VMwareHCX' with NOW
		
		load 'DSOT-vCenter' with typeVar
		
		// Find the Asset
		find Application by \
			'DSID-VMwareHCX' eq hcxSiteIdVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'

		elseFind Application by \
			'DSID-VMwareHCX-UID' eq hcxSiteUidVar \
			and 'DSEP-VMwareHCX' eq reportingHcxServerVar \
			into 'id'
		elseFind Application by \
			'Name' eq initSiteNameVar \
			and 'DSEP-VMwareHCX' eq reportingHcxServerVar \
			into 'id'

		set hcxSiteObjectVar with DOMAIN
		
		
		// DEPENDENCIES Asset Collection
		//////////////////////////////////////
		
		// Destination HCX Server
		domain Application
		
		lookup 'DSID-VMwareHCX-EndpointID','DSOT-vCenter' \
			with hcxServerEndpointIdVar, 'HCX Server'
		if (LOOKUP.notFound()){
			
			init 'Name' with initHCXServerNameVar
			init 'Bundle' with config.defaultBundle
			
			load 'DSID-VMwareHCX' with hcxServerEndpointIdVar
			load 'DSEP-VMwareHCX' with reportingHcxServerVar
			load 'DSOT-vCenter' with 'HCX Server'
			// load 'DSLS-VMwareHCX' with NOW
			
			load 'Vendor' with 'VMware'
			load 'URL' with hcxServerHostnameVar


			// Dependent: HCX Server
			find Application by \
				'DSID-VMwareHCX' eq hcxServerEndpointIdVar \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// The HCX Server should already exist.
			// Try looking by (1)URL and (2)Name
			// There are 2 references we can use to find the right HCX server, 
			//		(a)hcxServerHostnameVar, from the reported data
			// 		(b)reportingHcxServerVar, the HCX server name in the Metadata from the collection action
			
			// 1a. with the hcxServerHostnameVar in the data
			elseFind Application by \
				'URL' like '%'+hcxServerHostnameVar+'%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// 1b. with the HCX Server in the Metadata
			// elseFind Application by \
			// 	'URL' like '%'+reportingHcxServerVar+'%' \
			// 	and 'DSOT-vCenter' eq 'HCX Server' \
			// 	into 'id'
			
			// 2a. with the hcxServerHostnameVar in the data
			elseFind Application by \
				'Name' like '%' + hcxServerHostnameVar + '%' \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'
			
			// // 2b. with the HCX Server in the Metadata
			elseFind Application by \
				'Name' like '%' + reportingHcxServerVar \
				and 'DSOT-vCenter' eq 'HCX Server' \
				into 'id'

		}	
		set hcxServerObjectVar with DOMAIN

		// Destination vCenter Cluster
		domain Application

		init 'Name' with initvCenterNameVar
		load 'Bundle' with 'VMware Discovery'
		
		load 'DSID-VMwareHCX-EndpointID' with hcxServerEndpointIdVar
		load 'DSEP-VMwareHCX' with reportingHcxServerVar
		load 'DSOT-vCenter' with 'vCenter'
		// load 'DSLS-VMwareHCX' with NOW
		
		load 'Vendor' with 'VMware'
		load 'URL' with vCenterHostnameVar

		// FIND Overview - Readme:
		// The vCenter vcenter should already exist.
		// Try looking by (1)URL and (2)Name
		// There are 2 references we can use to find the right HCX server, 
		
		// 0. Use the PK we assign to the vCenter cluster
		find Application by \
			'DSID-VMwareHCX-EndpointID' eq hcxServerEndpointIdVar \
			and 'DSOT-vCenter' eq 'vCenter' \
			into 'id'
		
		// 1a. with the vCenterHostnameVar in the data
		elseFind Application by \
			'DSOT-vCenter' eq 'vCenter' \
			and 'URL' like '%'+vCenterHostnameVar+'%' \
			into 'id'
		
		// 2a. with the vCenterHostnameVar in the data
		elseFind Application by \
			'DSOT-vCenter' eq 'vCenter' \
			and 'Name' like '%' + vCenterHostnameVar + '%' \
			into 'id'
		
		set vCenterObjectVar with DOMAIN

		// DEPENDENCIES Dependency Creation
		//////////////////////////////////////
		
		domain Dependency with hcxSiteObjectVar 'HCX Destination' hcxServerObjectVar
		load 'c1' with 'HCX Site is run by an HCX Server'
		load 'c4' with NOW
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		domain Dependency with vCenterObjectVar 'HCX Destination' hcxSiteObjectVar
		load 'c1' with 'HCX Site contains a vCenter'
		load 'type' with 'HCX Source'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'
	}

	// Process Sites node - for Site Pairings
	rootNode 'Sites.SitePairing'
	read labels
	iterate {
		// Site Pairings is basically a list of destination sites that the source site is connected to.
		// Use the existing reportingHcxServerVar var (from the metadata) to identify the 'source' site.		
		
		// Asset Lookup: Destination Site
		domain Application
		extract 'Id' set hcxSitePairingIdVar
		extract 'Name' set hcxSiteNameVar
		extract 'Url' set hcxDestinationSiteUrlVar
		// set hcxSitePairingIdVar with sitePair.Id
		// set hcxSiteNameVar with sitePair.Name
		// set hcxDestinationSiteUrlVar with sitePair.Url

		init 'Name' with 'HCX Site: ' + hcxSiteNameVar
		find Application by \
			'DSID-VMwareHCX-EndpointID' eq hcxSitePairingIdVar \
			and 'DSOT-vCenter' eq 'HCX Destination Site' \
			into 'id'

		set destinationHcxSiteObjectVar with DOMAIN
		ignore record
		
		// Asset Lookup: Source HCX Site
		domain Application
		init 'Name' with 'HCX Site: ' + reportingHcxServerVar
		find Application by \
			'DSEP-VMwareHCX' eq reportingHcxServerVar \
			and 'DSOT-vCenter' eq 'HCX Source Site' \
			into 'id'
		set sourceHcxSiteObjectVar with DOMAIN
		ignore record
		
		// Asset Lookup: Destination HCX Server
		domain Application
		init 'Name' with 'HCX Server: ' + hcxSiteNameVar
		find Application by \
			'DSID-VMwareHCX' eq hcxSitePairingIdVar \
			and 'DSOT-vCenter' eq 'HCX Server' \
			into 'id'
		set destinationHcxServerObjectVar with DOMAIN
		ignore record
		
		// Asset Lookup: Source HCX Server
		domain Application
		init 'Name' with 'HCX Server: ' + hcxSiteNameVar
		find Application by \
			'DSEP-VMwareHCX' eq reportingHcxServerVar \
			and 'URL' eq reportingHcxServerVar \
			and 'DSOT-vCenter' eq 'HCX Server' \
			into 'id'
		set sourceHcxServerObjectVar with DOMAIN
		ignore record
		
		// Asset Lookup: Destination vCenter
		domain Application
		// load 'DSLS-VMwareHCX' with NOW
		find Application by \
			'DSEP-vCenter' eq hcxSiteNameVar \
			and 'DSOT-vCenter' eq 'vCenter' \
			and 'url' like '%' + hcxSiteNameVar + '%' \
			into 'id'
		set destinationVCenterObjectVar with DOMAIN
		ignore record

		// // Asset Lookup: Source vCenter
		// domain Application
		// find Application by \
		// 	'DSEP-vCenter' eq hcxSiteNameVar \
		// 	and 'DSOT-vCenter' eq 'vCenter' \
		// 	and 'url' like '%' + hcxSiteNameVar + '%' \
		// 	into 'id'
		// set sourceVCenterObjectVar with DOMAIN
		// ignore record


		// Create Dependencies
		// 1. HCX Site to HCX Site
		domain Dependency with sourceHcxSiteObjectVar 'HCX Paired Site' destinationHcxSiteObjectVar
		load 'c1' with 'Source HCX Site is paired with a Destination Site'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'

		// 2. HCX Server to HCX Server - The target site reference doesn't specify the server.  Try to find it by
		domain Dependency with sourceHcxServerObjectVar 'HCX Paired Site' destinationHcxServerObjectVar
		load 'c1' with 'Source HCX Server is paired with a Destination Server'
		load 'status' with 'Validated'
		load 'dataFlowFreq' with 'constant'
		
		// 3. vCenter to vCenter
		//  This, and the above vCenter asset lookups are pending Dependency Fetching.  The Target vCenter can only be known 
		//  by looking up using a dependency.  The Site is linked, but the destination site has a depeendency supporting the actual vCenter cluster object.  That's what I need to connect it to.
	}
}

//////////////////////////////
//  VMs
//////////////////////////////
if (config.processData.vms){
	// // Get the VMs from the Inventory Node
	// rootNode 'Inventory.HCXVMs'
	// read labels
	// iterate {
	// 	console on

	// 	// Set the domain
	// 	domain Device
	// 	set typeVar with "VM"

	// 	// Extract details
	// 	extract 'Id' set assetIdVar
	// 	extract 'Uid' set assetUidVar
	// 	extract 'Name' set assetNameVar
	// 	extract 'Site' set siteVar
	// 	extract 'Network' set networkVar
		
	// 	// Load Asset Property Details
	// 	init 'Name' with assetNameVar
	// 	init 'Bundle' with config.defaultBundle
	// 	load 'DSOT-vCenter' with typeVar


	// 	// VMware vCenter details
	// 	load 'DSID-vCenter' with assetIdVar
	// 	load 'DSEP-vCenter' with siteVar.'Name'

	// 	// VMware HCX details
	// 	load 'DSID-VMwareHCX-UID' with assetUidVar
	// 	load 'DSEP-VMwareHCX' with reportingHcxServerVar
	// 	// load 'DSLS-VMwareHCX' with NOW
	// 	load 'HCX-SourceSite' with siteVar.Name
	// 	load 'HCX-SourceNetwork' with networkVar.Name.join(',')


		
	// 	// Find the Asset
	// 	find Device by \
	// 		'DSID-vCenter' eq assetIdVar \
	// 		and 'DSEP-vCenter' eq siteVar.'Name' \
	// 		and 'DSOT-vCenter' eq typeVar \
	// 		into 'id'
		

	// 	// Dependencies
	// 	// find Device by \
	// 	console off
	// }
}

//////////////////////////////
//  Containers
//////////////////////////////
if (config.processData.containers){
	// Get the Containers Node
	rootNode 'Containers.DestContainer'
	read labels
	iterate {
		
		// Extract details
		extract 'Id' set assetIdVar
		extract 'Uid' set assetUidVar
		extract 'Name' set assetNameVar
		extract 'Site' set siteVar
		
		extract 'Type' set hcxTypeVar transform with substitute(config.hcxTypeToDSOT) set typeVar
		
		// There are a few types of objects here
		switch(hcxTypeVar) {
			case 'cluster':
				etlModels.cluster();
				break
			
			case ['cluster','computeResource','vcenter']:
				// domain Application
				break
			case ['host']:
				// domain Device
				break
			case ['datacenter','folder','resourcePool']:
				// domain Storage
				break
				
			default: 
				console on
				log 'hcx type is ' + hcxTypeVar
				console off
				break
		}
	

		// domain Device
		// Load Asset Property Details
		// init 'Name' with assetNameVar
		// init 'Bundle' with config.defaultBundle
		// load 'DSOT-vCenter' with typeVar


		// // VMware vCenter details
		// load 'DSID-vCenter' with assetIdVar
		// load 'DSEP-vCenter' with siteVar.'Name'

		// // VMware HCX details
		// load 'DSID-VMwareHCX-UID' with assetUidVar
		// load 'DSEP-VMwareHCX' with reportingHcxServerVar 
		// // load 'DSLS-VMwareHCX' with NOW
		// load 'HCX-SourceSite' with siteVar.Name
		// load 'HCX-SourceNetwork' with networkVar.Name.join(',')


		
		// // Find the Asset
		// find Device by \
		// 	'DSID-vCenter' eq assetIdVar \
		// 	and 'DSEP-vCenter' eq siteVar.'Name' \
		// 	and 'DSOT-vCenter' eq typeVar \
		// 	into 'id'
		
		// console on
		// // log DOMAIN
		// console off
		// // Dependencies
		// // find Device by \
	}
}



