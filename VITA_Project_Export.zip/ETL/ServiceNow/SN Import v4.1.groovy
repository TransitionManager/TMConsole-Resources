/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "SN Import v4.1",
  "Description": "",
  "ProviderName": "ServiceNow",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*-------------------------------------
-
-	ServiceNow v4.1 - VITA Customized
-
--------------------------------------*/
def config = [
	matching: [
		allowNameOnly: true
	],
	defaults: [
		bundles: [
			allOthers: 			"ServiceNow",
			clusters: 			"VM Clusters",
			vmTemplates: 		"VM Templates",
		]
	],
	substitutions: [
		environment: [
			'Disaster recovery': 'DR'
		]
	],
	process: [
		applications:		 	false,
		
		servers: 				true,
		serversAix: 			false,
		serversApp: 			false,
		serversEsx: 			false,
		serversLinux: 			false,
		serversTomcat: 			false,
		serversWebLogic: 		false,
		serversWebSphere: 		false,
		serversWeb: 			false,
		serversWinclusters: 	false,
		
		vCenters: 				false,
		vCenterClusters: 		false,
		vCenterDatastores: 		false,
		vCenterServerObjects: 	false,
		vCenterDVS: 			false,
		vCenterInstance: 		false,
		vCenterTemplate: 		false,
		
		networkIPSwitches: 		false,
		networkLoadBalancers: 	false,
		networkNetGear:			false,
		
		dbInstances: 			false,
		dbDB2Instances: 		false,
		dbOracleInstances: 		false,
		dbPostresInstances: 	false,
		
		storageDevices: 		false,
		storageHBAs: 			false,
		storagePools: 			false,
		storagePoolMembers: 	false,
		storageVolume: 			false,
	]
]

// Store Cost Center names with the sys_ids
Map costCenterNames = [:]
rootNode 'cmn_cost_center'
read labels
iterate {
	extract 'sys_id' set sysIdVar
	extract 'name' set nameVar 
	set nameLabelVar with nameVar.split('-')[0].trim()
	console on
	console off
	costCenterNames.put(sysIdVar, nameLabelVar)
}

def processConfigurationItem = { assetClass, sysIdVar -> 

	// Load Fields
    load 'DSID-ServiceNow' with sysIdVar
	
	// Extract, Set
	extract 'name' transform with defaultValue('ServiceNow CI: ' + sysIdVar) set nameVar load 'Name'
	
	//Extract, Set, Load
	extract 'subcategory' set subcategoryVar load 'ServiceNow: SubClass'
	extract 'sys_class_name' set sysClassNameVar load 'ServiceNow: Sys Class'
	extract 'short_description' transform with left(255) set shortDescriptionVar load 'Description'
	extract 'discovery_source' set discoverySourceVar load 'ServiceNow: Discovery Sources'
	extract 'fqdn' set fqdnVar load 'URL'
	extract 'sys_created_by' set sysCreatedByVar load 'ServiceNow: Created By'
	extract 'sys_created_on' set sysCreatedOnVar load 'ServiceNow: Created On'
	extract 'sys_tags' set sysTagsVar load 'ServiceNow: Tags'
	extract 'sys_updated_by' set sysUpdatedByVar load 'ServiceNow: Updated By'
	extract 'sys_updated_on' set sysUpdatedOnVar load 'ServiceNow: Updated On'
	
	// Load Reference Fields
	extract 'cost_center' set costCenterDataVar
	if(costCenterDataVar != '') {
		set costCenterValueVar with costCenterDataVar.value 
		set costCenterNameVar with costCenterNames.getAt(costCenterValueVar)
		console on
		log 'THIS ASSET Raw: ' + costCenterDataVar
		log 'THIS ASSET Value: ' + costCenterValueVar
		log 'THIS ASSET Name: ' + costCenterNameVar
		console off
		load 'Cost Center' with costCenterNameVar
	}
	// Initial Find
	find assetClass by 'DSID-ServiceNow' with sysIdVar into 'id'
	elseFind assetClass by 'DSID-ServiceNow', 'Name' with \
		sysIdVar, nameVar \
		into 'id'

	if(config.matching.allowNameOnly){
		elseFind assetClass by 'Name' eq nameVar  into 'id'

	}

	// Defines Bundle
	if (FINDINGS.size() == 0) {
		find Bundle by 'name' with config.defaults.bundles.allOthers into 'moveBundle'
		whenNotFound 'moveBundle' create{
			'name' config.defaults.bundles.allOthers
		}
	}
	
	load 'DSLastSeen-ServiceNow' with NOW
}
def processComputer = {

	extract 'asset_tag' set assetTagVar load 'Asset Tag'
	extract 'cpu_core_count' set cpuCoreCountVar load 'Processor - Core Count'
	extract 'cpu_core_thread' set cpuCoreThreadVar load 'Processor - Thread Count'
	extract 'cpu_count' set cpuCountVar load 'Processor - Count'
	extract 'cpu_name' set cpuNameVar load 'Processor - Name'
	extract 'cpu_speed' set cpuSpeedVar load 'Processor - Speed'
	extract 'cpu_type' set cpuTypeVar load 'Processor - Model'
	extract 'dns_domain' set dnsDomainVar load 'Network - Hostname'
	extract 'disk_space' set diskSpaceVar load 'Disks - Total Provisioned'
	extract 'ip_address' set ipAddressVar
	extract 'os_domain' set osDomainVar load 'Network - OS Domain'
	extract 'ram' set ramVar load 'Memory - Total'
	extract 'serial_number' set serialNumberVar load 'Serial #'
	// extract 'warranty_expiration' set warrantyExpirationVar load 'Maint Expiration'
	// Todo - this must be converted to the right date format: Value must be a Date or in ISO-8601 format (yyyy-MM-dd | yyyy-MM-ddTHH:mm:ssZ)
	
	// extract 'cpu_manufacturer' set cpumanufacturerNameVar 
	// if(cpumanufacturerNameVar !=''){load 'Processor - Manufacturer' with cpumanufacturerNameVar}

	extract 'os' set osVar 
	extract 'os_address_width' set osAddressWidthVar
	extract 'os_service_pack' set osServicePackVar
	extract 'os_version' set osVersionVar
	extract 'virtual' set virtualVar

	set osStringVar with osVar + " " + osAddressWidthVar + " "+ osServicePackVar + " " + osVersionVar

	load 'OS' with osStringVar

	// Find/Create Location 
	// extract 'location' set locationVar
	// if(locationVar?){load 'Source Room' with locationVar + " / TBD"}
	// find Room by 'location' with locationVar into 'roomSource'
	// whenNotFound 'Source Room' create{
	// 	'roomName' 'TBD'
	// 	'location' locationVar
	// }



	// // Find/Create Manufacturer
	// extract 'manufacturer' set manufacturerNameVar
	// if(manufacturerNameVar == "" || manufacturerNameVar == null || manufacturerNameVar == "Unknown"){
	// 	load 'Manufacturer' with 'Unknown'
	// }else{
	// 	load 'manufacturer' with manufacturerNameVar.value
	// 	find Manufacturer by 'name' eq manufacturerNameVar.value into 'manufacturer'
	// 	whenNotFound 'manufacturer' create{
	// 		'name' manufacturerNameVar.value
	// 	}
	// }
	

	// // // Find/Create Model
	// extract 'model_id' set modelIdVar
	// if(modelIdVar == "" || modelIdVar == null || modelIdVar == "Unknown"){
	// 	load 'Model' with 'Unknown'
	// 	load 'Device Type' with 'Server'
	// }else{
	// 	load 'model' with modelIdVar.value

	// // 	// TODO: Model finding is not working properly.  See ticket TM-9839

	// // 	find Model by 'modelName' eq modelIdVar and 'manufacturer' eq 'VMware' into 'model'
	// // 	elseFind Model by 'modelName' eq modelIdVar into 'model'
	// // 	// // find Model by 'modelName' eq modelIdVar into 'model'
	// // 	whenNotFound 'model' create{
	// // 		'modelName' modelIdVar
	// // 		'manufacturer' manufacturerNameVar
	// 	// }
	// }

	// Loads IP Address
	load 'IP Address' transform with append(",",ipAddressVar)
	

}	
def processServer = {

	extract 'host_name' set hostNameVar load 'Network - Hostname'
	extract 'used_for'  transform with substitute(config.substitutions.environment, '') set usedForVar load 'Environment'

}
def processVMObject = {

	// extract 'object_id' set objectIdVar load 'DSID-ServiceNow'


}
def processVMInstance = {

	extract 'cpus' set cpusVar load 'Processor - Count'
	extract 'memory' set memoryVar load 'Memory - Total'
	extract 'state' set stateVar load 'Virtual - Guest State'
	extract 'disks' set disksVar
	extract 'disks_size' set disksSizeVar
	extract 'nics' set nicsVar
	extract 'vm_inst_id' set vmInstIdVar

	set descriptionVar with 'CPUs: ' + cpusVar + \
		', Disks: ' + disksVar + \
		', Size: ' + diskSizeVar + \
		', Memory: ' + memoryVar + \
		', Nics: ' + nicsVar
	
	load 'Description' with descriptionVar


}
def processVMTemlate = {

	extract 'cpus' set cpusVar load 'Processor - Count'
	extract 'memory' set memoryVar load 'Memory - Total'
	extract 'disks' set disksVar
	extract 'disks_size' set disksSizeVar
	extract 'nics' set nicsVar
	extract 'vm_instance_uuid' set vmInstIdVar load 'DSID-VMwareUUID'

	set descriptionVar with 'CPUs: ' + cpusVar + \
		', Disks: ' + disksVar + \
		', Size: ' + diskSizeVar + \
		', Memory: ' + memoryVar + \
		', Nics: ' + nicsVar
	
	load 'Description' with descriptionVar
	find Bundle by 'name' with config.defaults.bundles.vmTemplates into 'moveBundle'
	whenNotFound 'moveBundle' create{
		'name' config.defaults.bundles.vmTemplates
		'useForPlanning' 'false'
	}


}
def processvCenterServerObject = {
	extract 'vcenter_uuid' load 'DSID-VMwareUUID'
}
def processvCenterObject = {
	extract 'vcenter_uuid' load 'DSID-VMwareUUID'
}
def processHostCluster = {

	extract 'effectivecpu' set effectivecpuVar
	extract 'effectivehosts' set effectivehostsVar
	extract 'effectivememory' set effectivememoryVar
	extract 'numcpucores' set numcpucoresVar
	extract 'numcputhreads' set numcputhreadsVar
	extract 'numhosts' set numhostsVar
	extract 'totalcpu' set totalcpuVar
	extract 'totalmemory' set totalmemoryVar

	set descriptionVar with "Effective CPU: " + effectivecpuVar + \
		", Hosts: " + effectivehostsVar + \
		", Memory: " + effectivememoryVar + \
		", Cores: " + numcpucoresVar + \
		", Threads: " + numcputhreadsVar + \
		", Total Hosts: " + numhostsVar + \
		", CPU: " + totalcpuVar + \
		", Memory: " + totalmemoryVar
	
	load 'Description' with descriptionVar

}
def processApplication = {

	extract 'config_directory' load 'App Config Directory' 
	extract 'config_file'  load 'App Config File'
	extract 'edition'  load 'App Edition'
	extract 'install_directory' load 'App Install Directory' 
	extract 'is_clustered'  load 'App Clustered'
	extract 'running_process'  transform with left(255) load 'App Running Process'
	extract 'running_process_command'  transform with left(255) load 'App Running Process Command'
	extract 'running_process_key_parameters' transform with left(255)  load 'App Running Process Key Parameters'
	extract 'tcp_port'  load 'App TCP Port'
	extract 'used_for'  transform with substitute(config.substitutions.environment, '') set usedForVar load 'Environment'

}
def processApplicationServer = {
	extract 'container' set containerVar load 'ServiceNow: Container'
}
def processDatastore = {

	extract 'capacity' load 'Size'
	load 'Scale' with 'GB'
	extract 'freespace' load 'Free Space (GB)'


}
def processCloudNetwork = {

	extract 'domain_name' set domainNameVar

}
def processStorageDevice = {

	extract 'device_id' set deviceIdVar
	extract 'device_lun' set deviceLunVar
	extract 'size' set sizeVar
	extract 'storage_type' set storageTypeVar


}

domain Device  // Necessary for ensureNameExists function
read labels
def ensureNameExists = {
	if (DOMAIN.assetName == ""){
		load 'Name' with 'sys_id: ' + sysIdVar
	}
}
ignore record  // Removes domain created to instance the closure for ensureNameExists


if(config.process.servers){
	rootNode 'cmdb_ci_server'
	read labels
	iterate{
		domain Device

		extract 'sys_id' set sysIdVar
		lookup 'DSID-ServiceNow' with sysIdVar
		if (LOOKUP.notFound()){
			// Process ServiceNow Hierarchy
			processConfigurationItem(Device, sysIdVar)
			processComputer()
			processServer()

		}
		ensureNameExists()
	}
}


