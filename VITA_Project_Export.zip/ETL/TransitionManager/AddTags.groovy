/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "AddTags",
  "Description": "",
  "ProviderName": "TransitionManager",
  "IsAutoProcess": true,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

 
//************************************
// Config Switches         true | false
//***********************************/
 
//************************************
// Script Settings
//***********************************/
 
//////////////////////////////
//  Adding a Tag
//////////////////////////////
 
     sheet 'Devices'
     read labels
     iterate {
          
           // Set the domain
           domain Device
 
           extract 'Id' set id
        extract 'Tags' set tagVar
        find Device by 'id' eq id into 'id'
        tagAdd tagVar
 
     }


