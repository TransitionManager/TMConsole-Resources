/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "Add Tags from vCenter Lookup",
  "Description": "",
  "ProviderName": "VMware vCenter",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

// Imports DR tags from VITA environment to assign to the Device 'DR Sub?' field

console off

read labels
iterate {

    // Get the Tag data and organize it better
	extract 'Tag' set tagData
    tag = tagData.toString().tokenize('//')
    tagName = tag[0]
    tagValue = tag[1]
    
    // If the tag is a DR tag
    if(tagName == 'DR'){
    	
        log 'DR Tag Found!'

        // Get the VM name
        extract 'Entity' set vmName
        log 'vmName: ' + vmName


        // Decide if this is a live machine and should be updated.
        updateVMRecord = true

        // Check if the machine name contains 
        if(vmName.indexOf('-') > -1){

            log 'VM name contains a dash'    
            
            // Get the last part of the name, following the last dash
            vmLastNamePart = vmName.tokenize('-')[-1]
            
            // Retired VMs will have <name>-1********* numbers, with 159 to 160 in the present data.
            log 'the last part after the dash is ' + vmLastNamePart

            // If the last part has at at least 3 characters, test to see if those 3 characters are 159 or 160
            if(vmLastNamePart.size() > 2 && ['159','160'].contains(vmLastNamePart.substring(0,3))) { 
                log 'the last part of the vm look to indicate a retired vm.'
            
                // We have met the criteria to exclude this data update.  Disable updating the VM record
                updateVMRecord = false
            }



        }


        if (updateVMRecord){

         	domain Device
            load 'Name' with vmName
            find Device by 'Name' eq vmName into 'id'
            load 'DR sub?' with tagValue
        }
    }
}


