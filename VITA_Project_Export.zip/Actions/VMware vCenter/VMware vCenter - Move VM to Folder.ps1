<####### TransitionManager Action Script ######

	ActionName			= VMware vCenter - Move VM to Folder 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	vCenterServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target vCenter'
	}
	Folder = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Compute Container'
	}
}
## End of TM Configuration, Begin Script

## Progress - Start Task
Write-Progress -Id 1 -ParentId 0 -Activity 'Logging into vCenter' -PercentComplete 5
Write-Host "Connecting to " -NoNewline
Write-Host $Params.'vCenter Server' -NoNewline -ForegroundColor Blue
Write-Host " as " -NoNewline
Write-Host $Credential.UserName -ForegroundColor Yellow

Connect-VIServer -Server $Params.'vCenter Server' -Credential $Credential | Out-Null

## Getting Metadata
Write-Progress -Id 1  -ParentId 0 -Activity 'Collecting VM Data' -PercentComplete 25

$VM = Get-VM -Name $Params.'VM Name'
$VMFolder = Get-Folder -Name $Params.Folder -Type VM

## Getting Metadata
Write-Progress -Id 1  -ParentId 0 -Activity 'Moving VM' -PercentComplete 75
Write-Host "Moving VM " -NoNewline
Write-Host $Params.'VM Name' -NoNewline -ForegroundColor Blue
Write-Host " to Folder:  " -NoNewline
Write-Host $Params.Folder -ForegroundColor Yellow
Move-VM -VM $VM -Destination $VM.VMHost -InventoryLocation $VMFolder | Out-Null

Write-Progress -Id 1  -ParentId 0 -Activity 'VM Moved' -PercentComplete 100 -Completed


