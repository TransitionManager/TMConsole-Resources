<####### TransitionManager Action Script ######

	ActionName			= VMware vCenter - Take Snapshot of VM 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= Perform a Snapshot of a VM
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	vCenterServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target vCenter'
	}
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Device Admin Credential'
	}
	Bundle = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Bundle'
	}
}
## End of TM Configuration, Begin Script

Connect-VIServer -Server $Params.'vCenter Server' -Credential $Params.'Device Admin Credential' | Out-Null
New-Snapshot `
    -VM $Params.'VM Name' `
    -Server $Params.'vCenter Server' `
    -Name ('Post Move (' + $Params.Bundle + ') Snapshot of ' + $Params.'VM Name')


