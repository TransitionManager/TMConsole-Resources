<####### TransitionManager Action Script ######

	ActionName			= VMware vCenter - Run Discovery 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	vCenterServer = @{
		Description		= ''
		Context			= 'APPLICATION'
		FieldLabel		= 'URL'
	}
	get_credential_vCenterCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vCenter Username and Password'
	}
}
## End of TM Configuration, Begin Script

##
## Import Configuration from Provider and User
##
Import-DefaultConfig "VMware-vCenter"
Import-UserConfig "VMware-vCenter"

##
## Create Discovery Progress Indicators
##
$ProgressIndicators = @(
    @{ Id = 100; Activity = 'VMware vCenter Discovery' },
    @{ Id = 101; Activity = 'Discover vCenter Servers'; ParentId = 100 },
    @{ Id = 102; Activity = 'Discover VMware Extensions'; ParentId = 100 },
    @{ Id = 103; Activity = 'Discover Clusters'; ParentId = 100 },
    @{ Id = 104; Activity = 'Discover VM Hosts'; ParentId = 100 },
    @{ Id = 105; Activity = 'Discover VMs'; ParentId = 100 },
    @{ Id = 106; Activity = 'Discover VM Hard Disks'; ParentId = 100 },
    @{ Id = 107; Activity = 'Discover Virtual Datacenters'; ParentId = 100 },
    @{ Id = 108; Activity = 'Discover Datastores'; ParentId = 100 },
    @{ Id = 109; Activity = 'Discover Virtual Networks'; ParentId = 100 },
    @{ Id = 110; Activity = 'Discover Virtual Switches'; ParentId = 100 },
    @{ Id = 111; Activity = 'Discover Folders'; ParentId = 100 },
    @{ Id = 112; Activity = 'Discover Resource Pools'; ParentId = 100 }
)


## Add Conditional Steps based on Parameters
if ( ConvertTo-Boolean $Params.WriteJSONFile ) {
    $ProgressIndicators += @{ Id = 113; Activity = 'Save Discovery Data'; ParentId = 100 }
}
if ( ConvertTo-Boolean $Params.ProcessWithETL ) {

    $ProgressIndicators += @{ Id = 1000; Activity = 'TransitionManager Data Import'; ParentId = 0 }
    $ProgressIndicators += @{ Id = 1001; Activity = 'ETL Data Transformation'; ParentId = 1000 }
    $ProgressIndicators += @{ Id = 1002; Activity = 'Manage Batches'; ParentId = 1000 }
} 

#Write Progress Indicators for each in the Array
$ProgressIndicators | ForEach-Object {
    Write-Progress @_ -CurrentOperation 'Queued' -PercentComplete 0
}

# Determine how many steps each section has so the progress can be updated by percentage
$TaskStepCount = $ProgressIndicators.Count
$TaskStepCounter = 0

# 
# Authenticate to vCenter
#      Read the credential first so the username is available to display in the progress
#
$vCenterCredential = $Credential
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Authenticating' `
    -Status ('Logging into [' + $Params.vCenterServer + '] as [' + $vCenterCredential.username + ']') `
    -PercentComplete 5

## VITA has an invalid SSL cert 
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
Connect-VIServer -Server $params.vCenterServer -Credential $vCenterCredential -Protocol https | Out-Null
  
##
## VMware vCenter Servers
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Performing Discovery' `
    -Status 'Discovering vCenter Servers' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)
    
Write-Progress -Id 101 -Activity 'Discovering vCenter Servers' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$vCenterServer = Get-VIServer -Server $params.vCenterServer -Credential $vCenterCredential | Optimize-DataObject -ProcessingMap $VMwareMaps.vCenter
Write-Progress -Id 101 -Activity 'Discovered vCenter Servers' -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++

 
##
## VMware Extensions
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering VMware Extensions' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 102 -Activity 'Discovering VMware Extensions' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$vCenterExtensions = (Get-View ExtensionManager).ExtensionList
Write-Progress -Id 102 -Activity 'Discovered VMware Extensions'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


##
## VMware Clusters
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Clusters' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 103 -Activity 'Discovering Clusters' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$Clusters = Get-Cluster | Optimize-DataObject -StartLabel "Discover Clusters" -ProcessingMap $VMwareMaps.Cluster
Write-Progress -Id 103 -Activity 'Discovered Clusters'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


##
## VMware VM Hosts
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering VM Hosts' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 104 -Activity 'Discovering VM Hosts' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$VMHostsLive = Get-VMHost

Write-Host "Performing Inventory for"$VMHostsLive.Count"VM Hosts."
$i = 0
$PerHostPercentage = (100 / $VMHostsLive.Count)
# $VMHosts = $VMHostsLive | ForEach-Object {
$VMHosts = [System.Collections.ArrayList]@()
foreach ($VMHostLive in $VMHostsLive) {
    
    Write-Progress -Activity ('Compiling Inventory for VM Host: (' + ($i + 1) + ' of ' + $VMHostsLive.Count + ')') -PercentComplete ([Math]::floor($i * $PerHostPercentage)) -Id 104 -ParentId 100
    $VMHost = $VMHostLive | Optimize-DataObject -ProcessingMap $VMwareMaps.VMHost
    $i++ | Out-Null
    $VMHosts.Add($VMHost) | Out-Null
}
Write-Progress -Id 104 -Activity 'Discovered VM Hosts'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++

##
## VMware VMs
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering VMs' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)
Write-Progress -Id 105 -Activity 'Discovering VMs' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$VMsLive = Get-VM 
Write-Host "Performing Inventory for"$VMsLive.Count"VMs."
$i = 0
$PerVMPercentage = 100 / $VMsLive.Count
$VMs = [System.Collections.ArrayList]@()
foreach ($VMLive in $VMsLive) {
    
    Write-Progress -Activity ('Compiling Inventory for VMs : (' + ($i + 1) + ' of ' + $VMsLive.Count + ')') -PercentComplete ([Math]::floor($i * $PerVMPercentage)) -Id 105 -ParentId 100
    $VM = $VMLive | Optimize-DataObject -ProcessingMap $VMwareMaps.VM
    $i++ | Out-Null
    $VMs.Add($VM) | Out-Null
}
Write-Progress -Id 105 -Activity 'Discovered VMs'  -PercentComplete 100 -ParentId 100 -Completed
$TaskStepCounter++

##
## VMware VM Hard Disks
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering VM Hard Disks' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)
Write-Progress -Id 106 -Activity 'Discovering VM Hard Disks'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Discovering Hard Drives'
$i = 0
$HardDisks = [System.Collections.ArrayList]@()
foreach ($VM in $VMs) {
    Write-Progress -Activity ('Compiling Inventory for VM Hard Disks : (' + ($i + 1) + ' of ' + $VMs.Count + ')') -PercentComplete ([Math]::floor($i * $PerVMPercentage)) -Id 106 -ParentId 100
    $i++ | Out-Null
    $HDs = Get-HardDisk -VM $VM.Name
    foreach($Item in $HDs){
        $HardDisks.Add((Optimize-DataObject -ProcessingMap $VMwareMaps.HardDisk)) | Out-Null
    }
    
}
Write-Progress -Id 106 -Activity 'Discovered VM Hard Disks'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++
    
##
## VMware Virtual Datacenters
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Virtual Datacenters' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 107 -Activity 'Discovering Virtual Datacenters' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$Datacenters = Get-Datacenter | Optimize-DataObject -ProcessingMap $VMwareMaps.Datacenter
Write-Progress -Id 107 -Activity 'Discovered Virtual Datacenters'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++

##
## VMware Datastores
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Datastores' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 108 -Activity 'Discovering Datastores' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$Datastores = Get-Datastore | Optimize-DataObject -ProcessingMap $VMwareMaps.Datastore
Write-Progress -Id 108 -Activity 'Discovered Datastores'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


##
## VMware Virtual Networks
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Virtual Networks' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 109 -Activity 'Discovering Virtual Networks' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$VirtualNetworks = Get-VirtualNetwork | Optimize-DataObject -ProcessingMap $VMwareMaps.VirtualNetwork
Write-Progress -Id 109 -Activity 'Discovered Virtual Networks'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


#
# VMware Virtual Switches
#
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Virtual Switches' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 110 -Activity 'Discovering Virtual Switches' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$VirtualSwitches = Get-VirtualSwitch | Optimize-DataObject -ProcessingMap $VMwareMaps.VirtualSwitch
Write-Progress -Id 110 -Activity 'Discovered Virtual Switches'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


##
## VMware Folders
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Folders' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 111 -Activity 'Discovering Folders' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$Folders = Get-Folder | Optimize-DataObject -ProcessingMap $VMwareMaps.Folder
Write-Progress -Id 111 -Activity 'Discovered Folders'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++


##
## VMware Resource Pools
##
Write-Progress `
    -Id 100 `
    -ParentId 0 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Running Discovery' `
    -Status 'Discovering Resource Pools' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 112 -Activity 'Discovering Resource Pools' -PercentComplete 5 -ParentId 100 -CurrentOperation 'Running Discovery'
$ResourcePools = Get-ResourcePool | Optimize-DataObject -ProcessingMap $VMwareMaps.ResourcePool
Write-Progress -Id 112 -Activity 'Discovered Resource Pools'  -PercentComplete 100 -ParentId 100 -CurrentOperation 'Done' -Completed
$TaskStepCounter++



##
## Write File to Output
##
Write-Progress `
    -Id 100 `
    -Activity 'VMware vCenter Discovery' `
    -CurrentOperation 'Saving Discovery Data' `
    -Status 'Saving JSON Data' `
    -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)

Write-Progress -Id 113 -Activity 'Saving Discovery Data' -PercentComplete 5 -ParentId 100

$Inventory = @{
    Metadata          = @{
        DateCollected = Get-Date -Format FileDateTime
        Server        = $params.vCenterServer
        LocationType  = $params.LocationType
    }
    vcenterExtensions = $vCenterExtensions
    vCenterServers    = $vCenterServer
    clusters          = $Clusters
    vmHosts           = $VMHosts
    vms               = $VMs
    hardDisks         = $HardDisks
    datacenters       = $Datacenters
    datastores        = $Datastores
    virtualNetworks   = $VirtualNetworks
    virtualSwitches   = $VirtualSwitches
    folders           = $Folders
    resourcePools     = $ResourcePools
}
$FilePrefix = 'vCenterInventory_' + $params.vCenterServer
Write-DataToJSON -Data $Inventory -BaseFileName $FilePrefix
Write-Progress -Id 113 -Activity 'Saved Discovery Data' -PercentComplete 100 -ParentId 100 -CurrentOperation 'Saved' -Completed



# ## Process the file with ETL
if ( ConvertTo-Boolean $Params.ProcessWithETL ) {
    Import-Module TransitionManager
    $TMCredential = Get-StoredCredential -CredentialName $params.TMCredentialName
    
    Write-Progress `
        -Id 0 `
        -Activity 'Action Script' `
        -CurrentOperation 'TransitionManager Data Import' `
        -Status 'Authenticating' `
        -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)
    Write-Progress `
        -Id 1000 `
        -Activity 'TransitionManager Data Import' `
        -CurrentOperation 'Authenticating' `
        -Status ('Logging into [' + $Params.TMServer + '] as [' + $TMCredential.username + ']') `
        -PercentComplete (($TaskStepCounter / $TaskStepCount) * 100)
        
    New-TMSession -TMServer $Params.TMServer -Credential $TMCredential -AllowInsecureSSL (ConvertTo-Boolean $params.AllowInsecureSSL)
        
    $BatchPostingOptions = @{
        QueueBatches   = (ConvertTo-Boolean $params.QueueBatches)
        MonitorBatches = (ConvertTo-Boolean $params.MonitorBatches)
    }
    Invoke-TMETLScript -DataType 'JSON' -Data $Inventory -ETLScriptName "VMware vCenter Inventory" @BatchPostingOptions  -ActivityId 1000 -FileName ($FilePrefix + '_' + (Get-Date -Format FileDateTimeUniversal) + '.json') -Server $Params.TMServer
    
    ## Complete Activity
    Write-Progress `
        -Id 1000 `
        -Activity 'TransitionManager Data Import Complete' `
        -PercentComplete 100 -Completed -ParentId 0
            
}

Write-Progress -Id 100 -Activity 'VMware vCenter Discovery' -CurrentOperation 'Discovery Complete' -Status 'Discovery Complete'  -PercentComplete 100 -ParentId 0 -Completed


