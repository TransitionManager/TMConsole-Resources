<####### TransitionManager Action Script ######

	ActionName			= Test VMware Module Load 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	get_credential_TMUserAccount = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM Username and password'
	}
	TMServerName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
}
## End of TM Configuration, Begin Script

Get-Module


