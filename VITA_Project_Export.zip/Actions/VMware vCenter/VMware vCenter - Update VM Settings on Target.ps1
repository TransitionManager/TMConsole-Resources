<####### TransitionManager Action Script ######

	ActionName			= VMware vCenter - Update VM Settings on Target 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= Used to update the Folder and network of HCX machines launched. This also performs a reboot of the guest OS.
#>

## Parameter Configuration
$Params = @{
	TargetvCenter = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr02-w01vc01.cov.virginia.gov'
	}
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	Network = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'VM Network1'
	}
	get_credential_TMUserAccount = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM Username and Password'
	}
	TMServer = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	FolderName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Target Folder'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.'Target vCenter' } | Select-Object -ExpandProperty Name)

## Create Progress Items
Write-Progress -Id 0 -Activity 'Connect to vCenter' -PercentComplete 0 -CurrentOperation 'Pending'
# Write-Progress -Id 20 -ParentId 0 -Activity 'Move to Folder' -PercentComplete 0 -CurrentOperation 'Pending'
# Write-Progress -Id 30 -ParentId 0 -Activity 'Connect to Network' -PercentComplete 0 -CurrentOperation 'Pending'
# Write-Progress -Id 40 -ParentId 0 -Activity 'Reboot VM' -PercentComplete 0 -CurrentOperation 'Pending'

## Progress - Start Task
Write-Progress -Id 0 -Activity 'Logging into vCenter' -PercentComplete 5
Write-Host "Connecting to " -NoNewline
Write-Host $Params.'Target vCenter' -NoNewline -ForegroundColor Cyan
Write-Host " as " -NoNewline
Write-Host $vCenterCredential.Username -ForegroundColor Yellow

## Allow Insecure SSL
if ($Params.AllowInsecureSSL) {
	Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

#$TMCredential = $Params.'TM User Account'
#Import-Module TransitionManager
#New-TMSession -Server $Params.TMServer -Credential $TMCredential -AllowInsecureSSL $True

Connect-VIServer -Server $Params.'Target vCenter' -Credential $vCenterCredential | Out-Null

## Move VM
Write-Progress -Id 0 -Activity 'Move VM' -PercentComplete  25

Write-Host "Moving VM " -NoNewline
Write-Host $Params.'VM Name' -NoNewline -ForegroundColor Blue
Write-Host " to Folder:  " -NoNewline
Write-Host $Params.Folder -ForegroundColor Yellow

$VM = Get-VM -Name $Params.VMName
## Get Target Folder (Via a Path lookup using vCenter)
if ($Params.FolderName -like '*/*') {
    
    ## Get the Root Server Instance and folder
    $ServiceInstance = Get-View ServiceInstance -Server $DestvCenter
    $RootFolderId = Get-View -Server $DestvCenter -Id $ServiceInstance.Content.RootFolder -Property Value | Select-Object -ExpandProperty MoRef | Select-Object -ExpandProperty Value
   
    ## Walk up the tree from the root folder
    $RootFolder = Get-Folder -Id $RootFolderId -Server $DestvCenter -ErrorAction SilentlyContinue
    
    ## Split the /folder/path/into an array
    $TargetFolderPath = $Params.FolderName -split ('/')
    
    ## Walk up the Folder Path tree to get the end folder
    foreach ($FolderName in $TargetFolderPath) {
        
        ## If the string is empty, skip the loop (This allows for a leading or trailing /)
        if ($FolderName -eq '') {
            continue
        }

        $RootFolder = Get-Inventory -Name $FolderName -Location $RootFolder -Server $DestvCenter -ErrorAction SilentlyContinue
        if ((Get-Inventory -Location $RootFolder -NoRecursion | Select-Object -ExpandProperty Name) -contains "vm") {
            $RootFolder = Get-Inventory -Name "vm" -Location $RootFolder -Server $DestvCenter -NoRecursion
        }
    }

    ## Get the last folder that was used
    $RootFolder | Where-Object { $_ -is [VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl] } | Where-Object {
        $DestinationFolder = Get-Folder -Name $_.Name -Location $RootFolder.Parent -NoRecursion -Server $DestvCenter
    }
    
    # ## Trim the ID down to a string that HCX can use to find the folder by ID
    # $DestFoldervCenterId = $DestinationFolder.Id.Replace('Folder-group-', '*')

    # ## Get the Container Folder object
    # $DestFolder = Get-HCXContainer | Where-Object { $_.Id -like $DestFoldervCenterId }
} else {
    
    ## Get the Container Folder  By Name only
    $DestinationFolder = Get-Folder -Type Folder -Name $Params.FolderName
}

$ProgressPreference = 'SilentlyContinue'

Move-VM -VM $VM -Destination $VM.VMHost -InventoryLocation $DestinationFolder | Out-Null
$ProgressPreference = 'Continue'

# ## Change Network
# Write-Progress -Id 0 -Activity 'Update Network' -PercentComplete 50
# Write-Host "Updating Network to" -NoNewline
# Write-Host $Params.'Network' -NoNewline -ForegroundColor Blue

# $ProgressPreference = 'SilentlyContinue'
# Get-NetworkAdapter -VM $Params.VMName -Server $Params.'Target vCenter' -name 'Network adapter 1' | Set-NetworkAdapter -NetworkName $Params.Network -StartConnected:$true -confirm:$false | Out-Null
# $ProgressPreference = 'Continue'


# ## Reboot VM
# Write-Progress -Id 0 -Activity 'Reboot VM' -PercentComplete 75
# Write-Host "Rebooting " -NoNewline
# Write-Host $Params.VMName -NoNewline -ForegroundColor Blue
# $ProgressPreference = 'SilentlyContinue'
# Restart-VMGuest -VM $Params.VMName | Out-Null
# $ProgressPreference = 'Continue'

# Write-Progress -Id 0 -Activity 'VM Rebooted' -PercentComplete 100 -Completed


