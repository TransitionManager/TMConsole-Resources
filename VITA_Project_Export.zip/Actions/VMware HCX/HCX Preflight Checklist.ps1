<####### TransitionManager Action Script ######

	ActionName			= HCX Preflight Checklist 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
	}
	vCenterServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-vCenter'
	}
	Folder = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Target Folder'
	}
	Network = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Yes'
	}
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
}
## End of TM Configuration, Begin Script

<# Run a preflight check for this VM, Ensuring:
    Valid vCenter Server
    Valid HCX Server
    Valid Agency/Folder
    Valid Network
    ? Valid Tags
    ? Valid VMware Tools
    ? Others?
#>

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$HcxCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.HCXServer } | Select-Object -ExpandProperty Name)
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.vCenterServer } | Select-Object -ExpandProperty Name)

## Create Progress Items
Write-Progress -Id 0 -Activity 'Validating VM Migration Readiness' -PercentComplete 5 -CurrentOperation 'Running'
Write-Progress -Id 10 -ParentId 0 -Activity 'Validate vCenter Server' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 20 -ParentId 0 -Activity 'Validate HCX Server' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 30 -ParentId 0 -Activity 'Validate HCX Destination Network' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 40 -ParentId 0 -Activity 'Validate HCX Destination Folder' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 50 -ParentId 0 -Activity 'Validate Source VMWare Tools' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 60 -ParentId 0 -Activity 'Validate Source VMware Hardware Version' -PercentComplete 0 -CurrentOperation 'Pending'


## Honor SSL Security Settings
if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Validate VMware vCenter Connection
Write-Progress -Id 10 -ParentId 0 -Activity 'Authenticating to vCenter' -PercentComplete 5
Connect-VIServer -Server $Params.vCenterServer -Credential $vCenterCredential | Out-Null
$VM = Get-VM -Name $Params.VMName -Server $Params.vCenterServer
if (-not $VM) {
    throw 'Unable to validate vCenter Server Connection, could not get VM'
}
Write-Progress -Id 10 -ParentId 0 -Activity 'Validated vCenter Server' -PercentComplete 100 -Completed

## Validate VMware HCX Connection
Write-Progress -Id 20 -ParentId 0 -Activity 'Validating HCX Server' -PercentComplete 5
Connect-HCXServer -Server $Params.HCXServer -Credential $HcxCredential | Out-Null
$HCXVM = Get-HCXVM -Name $Params.VMName -Server $Params.HCXServer
if (-not $HCXVM) {
    throw 'Unable to validate HCX Server Connection, could not get VM'
}
Write-Progress -Id 20 -ParentId 0 -Activity 'Validated HCX Server' -PercentComplete 100 -Completed


## Get the Source and Destination Sites to confirm Network and Folders
$HCXDestinationSite = Get-HCXSite -Destination -Server $Params.HCXServer

## Validate VMware Target Network
Write-Progress -Id 30 -ParentId 0 -Activity 'Validating Destination Network' -PercentComplete 5
$DestinationNetwork = Get-HCXNetwork -Site $HcxDestinationSite | Where-Object { $_.Name -eq $Params.Network }
if (-not $DestinationNetwork) {
    throw ("Unable to create get Destination Network " + $Params.Network + ". Confirm that it exists")
}
Write-Progress -Id 30 -ParentId 0 -Activity 'Validated Destination Network' -PercentComplete 100 -Completed


## Validate VMware Target Folder
Write-Progress -Id 40 -ParentId 0 -Activity 'Validating Destination Folder' -PercentComplete 0
$FolderName = $Params.Folder.Split('/')[-1]
$DestinationFolder = Get-HCXContainer -Name $FolderName -Site $HCXDestinationSite -Type Folder
if (-not $DestinationFolder) {
    throw ("Unable to create get Destination Folder " + $FolderName + ". Confirm that it exists")
}
Write-Progress -Id 40 -ParentId 0 -Activity 'Validated Destination Folder' -PercentComplete 100 -Completed

## Validate VMware Tools
Write-Progress -Id 50 -ParentId 0 -Activity 'Validating Source VMware Tools' -PercentComplete 5
# if($VM.Guest.ToolsVersion -ne ''){
#     Write-Host 'VMware tools is out of date.  Current Version: ' -NoNewline
#     Write-Host $VM.Guest.ToolsVersion -ForegroundColor Red
#     Write-Host 'Minimum version is: 11.1'
# }
# if ($VM.Guest.ExtensionData.ToolsStatus -eq 'toolsOld') {
#     throw 'VMware tools is too old, please upgrade.'
# }
if (($VM.Guest.ExtensionData.ToolsStatus -ne 'toolsOk') -and ($VM.Guest.ExtensionData.ToolsStatus -ne 'toolsOld')) {
    throw 'VMware tools is not running. Tools must be running to successfully migrate.'
}
Write-Progress -Id 50 -ParentId 0 -Activity 'Validated Source VMware Tools' -PercentComplete 100 -Completed

## Validate VMware Hardware Version
Write-Progress -Id 60 -ParentId 0 -Activity 'Validating Source Hardware Version' -PercentComplete 5
if (-not @('vmx-15', 'vmx-14', 'vmx-11', 'vmx-09', 'vmx-08', 'vmx-07').contains($VM.HardwareVersion)) {
    throw 'VMware VM Hardware Version is unsupported,  Please upgrade.'
}
Write-Progress -Id 60 -ParentId 0 -Activity 'Validated Source Hardware Version' -PercentComplete 100 -Completed

## Complete 0 task
Write-Progress -Id 0 -Activity 'Validated HCX Readiness' -PercentComplete 100 -Completed


