<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Jobs - Confirm all jobs exist for event 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	get_credential_TMUserAccount = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Your TM Username and password'
	}
	TMServerName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
}
## End of TM Configuration, Begin Script

## Define the HCX Servers to connect to for Job Lookup
$HcxServers = @('vpr01-hcxmgr01.cov.virginia.gov', 'vc02-hcxmgr01.cov.virginia.gov' )


## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$HcxCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $HcxServers[0] } | Select-Object -ExpandProperty Name)

if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Write Initial Progress Indicators 
Write-Progress -Id 0 -Activity 'Validate HCX Jobs for this event' -PercentComplete 0

## Authenticate to TM and HCX
Write-Progress -Id  0 -Activity 'Getting HCX Jobs' -PercentComplete 5

## All HCX Jobs
$AllHCXJobs = [System.Collections.ArrayList]@()

## Get the HCX Jobs from all of the Servers
foreach ($HCXServer in $HcxServers) {
    
    $uri = 'https://' + $HCXServer + '/hybridity/api/sessions'
    $JSONBody = [ordered]@{
        username = $HcxCredential.username
        password = $HcxCredential.GetNetworkCredential().Password
    } | ConvertTo-Json -Depth 2
    $XMLResponse = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -SkipCertificateCheck -Body $JSONBody -ContentType 'application/json;charset=UTF-8' -SessionVariable HCX
    # $response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
    $Response = $XMLResponse | ConvertFrom-XML
    $UUID = $Response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
    
    ##   
    ## Get the Migrations
    ## 
    $JSONBody = @{
        filter  = @{
            skipDrafts      = $True 
            createTimeEpoch = 1597723200000
        }
        options = @{
            resultLevel = "MOBILITYGROUP_ITEMS"
            compat      = "2.1"
        }
    } | ConvertTo-JSON -Compress -Depth 2
    $uri = 'https://' + $HCXServer + '/hybridity/api/migrations?action=query&hcspUUID=' + $UUID[0]
    $MigrationJobs = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -Body $JSONBody -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX
    
    ## Add these jobs to the total list
    if ($MigrationJobs.data.items.Count -gt 0) {
        $AllHCXJobs.AddRange($MigrationJobs.data.items) | Out-Null
    }
}

## Get the List of Devices from TM for this event
Write-Progress -Id 0 -Activity 'Getting TM Server List' -PercentComplete 50
Import-Module TransitionManager
New-TMSession -Server $Params.TMServerName -Credential $Params.'TM User Account' -AllowInsecureSSL $True

## Get all the Devices in this event
$TMDevices = [System.Collections.ArrayList] @()

## Collect all of the Assets
$Done = $False
while (-Not $Done) {
    
    ## Handle Pagination
    $PaginationSettings = @{
        Name   = 'HCX - Confirm Jobs Exist'
        Limit  = 1000
        Offset = 0
    }
    
    ## Get a Batch of Data
    $DeviceBatch = Get-TMAssetView @PaginationSettings | Select-Object -ExpandProperty 'common_assetName'
    if ($DeviceBatch.Count -gt 0) {
        $TMDevices.AddRange($DeviceBatch) | Out-Null
    }
    ## If the Batch is less than the limit asked for, Collection is done
    if ($DeviceBatch.Count -lt $PaginationSettings.Limit) {
        $Done = $true
    }
    
    ## Increase the Pagination Offset
    $PaginationSettings.Offset++

}

##
## Start Comparing the TM Devices to the HCX Jobs
##

Write-Progress -Id 0 -Activity 'Checking Jobs for TM Servers' -PercentComplete 100 -Completed

# ## Create a progress output for each of the Servers
# $ActivityNumber = 100
# foreach ($TMDevice in $TMDevices) {
    
#     ## Write a Progress for the Job Lookup
#     Write-Progress -Id $ActivityNumber -ParentId 0 -Activity "Confirm Job for: $TMDevice" -CurrentOperation 'Queued' -PercentComplete 0
#     $ActivityNumber++
# }

## Get Each Job's progress

$DevicesWithProperJobs = [System.Collections.ArrayList] @()
$DevicesWithFailedJobs = [System.Collections.ArrayList] @()
$DevicesMissingJobs = [System.Collections.ArrayList] @()

$ActivityNumber = 100
foreach ($TMDevice in $TMDevices) {
    
    ## Find the migration for this machine
    $VMMigration = $AllHCXJobs | Where-Object { $_.entity.entityName -eq $TMDevice } | Sort-Object -Property 'creationDate' -Descending | Select-Object -First 1
    if ($VMMigration) {
        
        if ($VMMigration.state -in @('TRANSFER_FAILED')) {
            $DevicesWithFailedJobs.Add($TMDevice) | Out-Null
        }
        else {
            $DevicesWithProperJobs.Add($TMDevice) | Out-Null

        }
    }
    else {
        # Write-Progress  -Id $ActivityNumber -ParentId 0 -Activity ('NO Job for: ' + $TMDevice) -CurrentOperation 'Job NOT Found' -PercentComplete 50
        Write-Host ('Unable to find a migration Job for ' + $TMDevice) -ForegroundColor Cyan
        $DevicesMissingJobs.Add($TMDevice) | Out-Null
        
        ## Start Sleep for a better console experience in TMD
        Start-Sleep -Milliseconds 50
    }
    
    ## Increment the Activity Counter
    $ActivityNumber++
}

## Output Statistics on the Jobs
Write-Host "Total Devices in this event: " -NoNewline
Write-Host $TMDevices.Count -ForegroundColor Cyan

## With Good Jobs
$PercentageWithJob = [Math]::Round(($DevicesWithProperJobs.Count / $TMDevices.Count) * 100)
Write-Host "Devices with Valid Jobs: " -NoNewline
Write-Host $DevicesWithProperJobs.Count -ForegroundColor Magenta -NoNewline
Write-Host (' of ' + [String]$TMDevices.Count + ': ' + [string]$PercentageWithJob + '%')

## With Failed Jobs
$PercentageWithFailedJob = [Math]::Round(($DevicesWithFailedJobs.Count / $TMDevices.Count) * 100)
Write-Host "Devices with Failed Jobs: " -NoNewline
Write-Host $DevicesWithFailedJobs.Count -ForegroundColor Magenta -NoNewline
Write-Host (' of ' + [String]$TMDevices.Count + ': ' + [string]$PercentageWithFailedJob + '%')

## With Missing Jobs
$PercentageMissingJob = [Math]::Round(($DevicesMissingJobs.Count / $TMDevices.Count) * 100)
Write-Host "Devices Missing Jobs: " -NoNewline
Write-Host $DevicesMissingJobs.Count -ForegroundColor Yellow -NoNewline
Write-Host (' of ' + [string]$TMDevices.Count + ': ' + [string]$PercentageMissingJob + '%')

## List the Machines with Job related issues
Write-Host "Devices with Failed Jobs: " -ForegroundColor Cyan
$DevicesWithFailedJobs | ForEach-Object { Write-Host "   $_" }

Write-Host "Devices with Missing Jobs: " -ForegroundColor Cyan
$DevicesMissingJobs  | ForEach-Object { Write-Host "   $_" }


Write-Progress  -Id 0 -Activity 'HCX Job Lookup Complete' -PercentComplete 100 -Completed


