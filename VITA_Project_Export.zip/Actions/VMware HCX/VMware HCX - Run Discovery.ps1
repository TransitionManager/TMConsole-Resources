<####### TransitionManager Action Script ######

	ActionName			= VMware HCX - Run Discovery 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	HCXServer = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr01-hcxmgr01.cov.virginia.gov'
	}
	TMServer = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
	TMCredentialName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM-VITA-tbaker-tdsi.com'
	}
	WriteJSONFile = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'yes'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'yes'
	}
	ImportBatches = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'No'
	}
	PostBatches = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'No'
	}
	LocationType = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Source'
	}
	ProcessWithETL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'false'
	}
}
## End of TM Configuration, Begin Script

# Authenticate to the server

if ($Params.AllowInsecureSSL) {
	Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

# # Update-TMTaskProgress -Progress 1 -Message ("Logging into HCX Server [" + $params.HCXServer + "] as " + $Credential.Username)
Connect-HCXServer -Server $params.HCXServer -Credential $Credential | Out-Null

# # Update-TMTaskProgress -Progress 30 -Message "Starting Data Collection"


# Collect Site Data
$HCXSourceSites = Get-HCXSite -Source
$HCXDestSites = Get-HCXSite -Destination
$HCXGateway = foreach ($DestinationSite in $HCXDestSites) {
    Get-HCXGateway -DestinationSite $DestinationSite
}

# Site Connections
$HCXSitePairing = Get-HCXSitePairing
$HCXInterconnectStatus = Get-HCXInterconnectStatus

## Appliance
$HCXAppliance = Get-HCXAppliance
# $HCXComputeProfile = Get-HCXComputeProfile

# $HCXSourceContainer = Get-HCXContainer
$HCXSourceContainer = $HCXSourceSites | ForEach-Object { Get-HCXContainer -Site $_ }
$HCXDestContainer = $HCXDestSites | ForEach-Object { Get-HCXContainer -Site $_ }
$HCXDestComputeContainer = $HCXDestSites | ForEach-Object { Get-HCXContainer -Type 'ComputeContainer' -Site $_ }
$HCXDestFolders = $HCXDestSites | ForEach-Object { Get-HCXContainer -Type 'Folder' -Site $_ }

# $HCXDatastore = Get-HCXDatastore
$HCXSourceDatastore = $HCXSourceSites | ForEach-Object { Get-HCXDatastore -Site $_ }
$HCXDestDatastore = $HCXDestSites | ForEach-Object { Get-HCXDatastore -Site $_ }

## HCX Service Layer
$HCXService = Get-HCXService
$HCXServiceMesh = Get-HCXServiceMesh
$HCXStorageProfile = Get-HCXStorageProfile

## Collect Network Data
$HCXSourceNetwork = $HCXSourceSites | ForEach-Object { Get-HCXNetwork -Site $_ }
$HCXDestNetwork = $HCXDestSites | ForEach-Object { Get-HCXNetwork -Site $_ }

$HCXNetworkBacking = Get-HCXNetworkBacking
$HCXNetworkExtension = Get-HCXNetworkExtension
# $HCXReplication = Get-HCXReplication 

# Assets to protect
$HCXVMs = Get-HCXVM
# $HCXInventoryCompute = Get-HCXInventoryCompute
# $HCXInventoryDatastore = Get-HCXInventoryDatastore
$HCXInventoryDVS = Get-HCXInventoryDVS
$HCXInventoryNetwork = Get-HCXInventoryNetwork


## Create the consolidated $Inventory
$Inventory = @{
    Metadata   = @{
        DateCollected = Get-Date -Format FileDateTime
        HCXServer     = $params.HCXServer
        LocationType  = $params.LocationType
    }
    
    ## Sites
    Sites      = @{
        SourceSites        = $HCXSourceSites
        DestSites          = $HCXDestSites
        SitePairing        = $HCXSitePairing
        Gateway            = $HCXGateway
        Appliance          = $HCXAppliance
        InterconnectStatus = $HCXInterconnectStatus
    }

    ## Service Mesh
    Service    = @{
        Service             = $HCXService
        ServiceMesh         = $HCXServiceMesh
        ComputeProfile      = $HCXComputeProfile
        StorageProfile      = $HCXStorageProfile
        HCXNetworkBacking   = $HCXNetworkBacking
        HCXNetworkExtension = $HCXNetworkExtension
    }

    ## Containers 
    Containers = @{
        SourceContainer = $HCXSourceContainer
        DestContainer   = $HCXDestContainer
    }
    
    ## Datastores
    Datastores = @{
        SourceDatastore = $HCXSourceDatastore
        DestDatastore   = $HCXDestDatastore
    }
    
    ## Networks
    Networks   = @{
        SourceNetwork = $HCXSourceNetwork
        DestNetwork   = $HCXDestNetwork
    }
    
    ## Inventory
    Inventory  = @{
        HCXVMs                = $HCXVMs
        HCXInventoryCompute   = $HCXInventoryCompute
        HCXInventoryDatastore = $HCXInventoryDatastore
        HCXInventoryDVS       = $HCXInventoryDVS
        HCXInventoryNetwork   = $HCXInventoryNetwork
        HCXFolders            = $HCXDestFolders
    }

}


# Update-TMTaskProgress -Progress 50 -Message "Adding HCX Settings to TM Field Lists"

## Update Target Field Selections
$HCXDestSitesList = $HCXDestSites | ForEach-Object { $_.Name }
$HCXDestDatastoreList = $HCXDestDatastore | ForEach-Object { $_.Name }
$HCXDestComputeContainerList = $HCXDestComputeContainer | ForEach-Object { $_.Name }
$HCXDestFoldersList = $HCXDestFolders | ForEach-Object { $_.Name }

# ## Update TransitionManager
# $TMCredential = Get-StoredCredential -CredentialName $params.TMCredentialName
# New-TMSession -TMServer $Params.TMServer -Credential $TMCredential -AllowInsecureSSL (ConvertTo-Boolean $params.AllowInsecureSSL)

# #Shared Fields - Add to each class
# Add-TMFieldListValues -Domain 'Device' -FieldLabel 'DSEP-VMwareHCX' -Values $params.HCXServer.toLower()
# Add-TMFieldListValues -Domain 'Application' -FieldLabel 'DSEP-VMwareHCX' -Values $params.HCXServer.toLower()
# Add-TMFieldListValues -Domain 'Database' -FieldLabel 'DSEP-VMwareHCX' -Values $params.HCXServer.toLower()
# Add-TMFieldListValues -Domain 'Storage' -FieldLabel 'DSEP-VMwareHCX' -Values $params.HCXServer.toLower()

# # Add Device Specific Class Fields
# Add-TMFieldListValues -Domain 'Device' -FieldLabel 'HCX-DestSite' -Values $HCXDestSitesList
# Add-TMFieldListValues -Domain 'Device' -FieldLabel 'HCX-DestContainer' -Values $HCXDestComputeContainerList
# Add-TMFieldListValues -Domain 'Device' -FieldLabel 'HCX-DestDatastore' -Values $HCXDestDatastoreList
# Add-TMFieldListValues -Domain 'Device' -FieldLabel 'HCX-DestFolder' -Values $HCXDestFoldersList

# Write File to JSONOutput
# Update-TMTaskProgress -Progress 60 -Message "Saving JSON File"
if ( ConvertTo-Boolean $Params.WriteJSONFile ) {
    Write-DataToJSON -Data $Inventory -BaseFileName ('HCXInventory_' + $params.HCXServer) -Open
}

# ## Process the file with ETL
# if ( ConvertTo-Boolean $Params.ProcessWithETL ) {
    
#     $BatchPostingOptions = @{
#         ImportBatches = if ($params.ImportBatches) { $true } else { $false }
#         PostBatches   = if ($params.PostBatches) { $true } else { $false }
#     }
    
#     # Update-TMTaskProgress -Progress 90 -Message "Starting ETL Script: VMware HCX Inventory" 
#     Invoke-TMETLScript -DataType 'JSON' -Data $Inventory -ETLScriptName "VMware HCX Inventory" @BatchPostingOptions
# }

Write-Host 'Task Complete!'


