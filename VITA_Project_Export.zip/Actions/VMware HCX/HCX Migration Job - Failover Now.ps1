<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Job - Failover Now 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
	}
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$HcxCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.HCXServer } | Select-Object -ExpandProperty Name)

if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}
## Connect to the server
Connect-HCXServer -Server $Params.HCXServer -Credential $HcxCredential | Out-Null

$HCXVM = Get-HCXVM -Name $Params.VMName

## Get the Migration Job
$VMMigration = Get-HCXMigration -EntityId $HCXVM.id -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'MIGRATE_CANCELLED' }

## Create Updated Timestamps for the Job
$StartTime = (Get-Date ).AddSeconds(10)
$EndTime = (Get-Date).AddMinutes(60)


## Check the number of VM migrations found
if ($VMMigration.Count -ne 1) {
    throw 'There is more than one HCX Job for this server.  Check the HCX console, archive old jobs and try again.'
}


## Set the new schedules
Set-HCXMigration -Migration $VMMigration -Server $Params.HCXServer -ScheduleStartTime $StartTime -ScheduleEndTime $EndTime


