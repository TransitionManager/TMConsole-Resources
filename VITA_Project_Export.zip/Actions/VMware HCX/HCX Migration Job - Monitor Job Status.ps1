<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Job - Monitor Job Status 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
		Value			= 'vpr01-hcxmgr01.cov.virginia.gov'
	}
	VMName = @{
		Description		= ''
		Context			= 'ASSET'
		FieldLabel		= ''
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	TaskTitle = @{
		Description		= ''
		Context			= 'TASK'
		FieldLabel		= ''
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$HcxCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.HCXServer } | Select-Object -ExpandProperty Name)

## Allow SSL Certificates that don't have a trusted root
if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Change the CompletionStatus for 'WAITING_FOR_MAINT_WINDOW' status
if($Params.TaskTitle -like '*Monitor until failover is done*'){
	$WaitForWindowEqComplete = $False
} else {
	$WaitForWindowEqComplete = $True
}

## Connect to the server
Connect-HCXServer -Server $Params.HCXServer -Credential $HcxCredential | Out-Null

# Authenticate to the API
$uri = 'https://' + $params.HCXServer + '/hybridity/api/sessions'
$JSONBody = [ordered]@{
    username = $HCXCredential.username
    password = $HcxCredential.GetNetworkCredential().Password
} | ConvertTo-Json -Depth 2
$XMLResponse = Invoke-RestMethod -Uri $uri -Method Post -Credential $HcxCredential -SkipCertificateCheck -Body $JSONBody -ContentType 'application/json;charset=UTF-8' -SessionVariable HCX
# $response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
$Response = $XMLResponse | ConvertFrom-XML
$UUID = $Response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values

## Get the Status of the Migrations
$JSONBody = @{
    filter  = @{
        skipDrafts      = $True 
        createTimeEpoch = 1597723200000
    }
    options = @{
        resultLevel = "MOBILITYGROUP_ITEMS"
        compat      = "2.1"
    }
} | ConvertTo-JSON -Compress -Depth 2
$uri = 'https://' + $params.HCXServer + '/hybridity/api/migrations?action=query&hcspUUID=' + $UUID[0]
$MigrationJobs = Invoke-RestMethod -Uri $uri -Method Post -Credential $HcxCredential -Body $JSONBody -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX
$VMMigration = $MigrationJobs.data.items | Where-Object { $_.entity.entityName -eq $Params.VMName } | Sort-Object -Property 'creationDate' -Descending | Select-Object -First 1

$JSONQueryFilter = @{
    filter  = @{
        migrationId = $VMMigration.Id
    }
    options = @{
        resultLevel = "MOBILITYGROUP_ITEMS"
        compat      = "2.1"
    }
} | ConvertTo-Json -Depth 3

## Get the Status of the Job
$LastReported = @{
    CheckpointLabel    = ''
    ProgressMessage    = ''
    ProgressPercentage = 0
}
Write-Progress -Id 1 -Activity 'Monitoring Job' -PercentComplete 0
$MigrationComplete = $false
while (-not $MigrationComplete) {

    ## Get the Migration Job 
    $VMMigration = (Invoke-RestMethod -Uri $uri -Method Post -Credential $HcxCredential -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX -Body $JSONQueryFilter).data.items[0]
    
    ## Report New Progress Labels
    $CheckpointLabel = ''
    if (($VMMigration.progress.log.Count -gt 0) -and (-not $VMMigration.progress.didFail)) {
            
        ## HCX Flags Checkpoints in their migration status  Concat them to give a nice breadcrumb.

        $CurrentCheckpoints = $VMMigration.progress.log
        $CheckpointLabel = 'MIGRATION PROGRESS'
        $CheckpointLabel += $CurrentCheckpoints | ForEach-Object { ' > ' + $_.message }
        
        ## Maintain the 'Last Reported' checkpoint.  Only report new ones.
        if ($LastReported.CheckpointLabel -ne $CheckpointLabel) {
            Write-Host $CheckpointLabel
            $LastReported.CheckpointLabel = $CheckpointLabel
        }
    }

    ## Handle the status based on the state
    switch ($VMMigration.State) {
        'SWITCHOVER_STARTED' {
            ## Report Progress output
            $CurrentPercentComplete = (($VMMigration.progress.transfer.value / $VMMigration.progress.total.value ) * 100)
            $ProgressMessage = $VMMigration.progress.message.trim()
            $RoundedPercentageComplete = [Math]::Round($CurrentPercentComplete, 1)
            if ($LastReported.ProgressPercentage -ne $RoundedPercentageComplete) {
                 
                ## Update the cache
                $LastReported.ProgressMessage = $ProgressMessage
                $LastReported.ProgressPercentage = $RoundedPercentageComplete
                Write-Progress -Id 1 -parentId 0 -PercentComplete $RoundedPercentageComplete -Activity $ProgressMessage
                if ($ProgressMessage -ne $LastReported.ProgressMessage) {
                    Write-Host $LastReported.ProgressMessage
                }
            }
            Start-Sleep -Seconds 2
            break
        }
        'MIGRATION_COMPLETE' {
            $MigrationComplete = $true
            Write-Progress -Id 1 -parentId 0 -PercentComplete 100 -Activity 'Migration Complete' -Completed
            break
        }
        'TRANSFER_STARTED' { 

            ## Report Progress output
            $CurrentPercentComplete = (($VMMigration.progress.transfer.value / $VMMigration.progress.total.value ) * 100)
            $RoundedPercentageComplete = [Math]::Round($CurrentPercentComplete, 1)
            $ProgressMessage = $VMMigration.progress.message.trim()
            if ($LastReported.ProgressPercentage -ne $RoundedPercentageComplete) {
                 
                ## Update the cache
                $LastReported.ProgressMessage = $ProgressMessage
                $LastReported.ProgressPercentage = $RoundedPercentageComplete
                Write-Progress -Id 1 -parentId 0 -PercentComplete $RoundedPercentageComplete -Activity $ProgressMessage
                if ($ProgressMessage -ne $LastReported.ProgressMessage) {
                    Write-Host $LastReported.ProgressMessage
                }
            }
            Start-Sleep -Seconds 2
            break
        }
        'CANCELED' { 
            $MigrationComplete = $true
            Write-Host "VM Migration has been canceled"
            Throw "VM Migration has been canceled"
        }
        'TRANSFER_FAILED' { 
            $MigrationComplete = $true
            Write-Host $VMMigration.progress.message
            Throw $VMMigration.progress.message
        }
        'WAITING_FOR_MAINT_WINDOW' { 
            $MigrationComplete = $WaitForWindowEqComplete
            Write-Progress -Id 1 -PercentComplete 100 -Completed -Activity 'Replication Complete, Waiting for Cutover'
            break
        }
        Default {
            $MigrationComplete = $true
            Write-Host $VMMigration.progress.message
            Throw "VM Migration had an unknown state"
        }
    }
}
Write-Progress -Id 0 -Activity 'Job Complete' -PercentComplete 100 -Completed


