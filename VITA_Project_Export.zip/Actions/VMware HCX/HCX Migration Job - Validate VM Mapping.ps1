<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Job - Validate VM Mapping 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	TMAssetId = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Id'
	}
	TMServerName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
	TMSavedCredentialName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM-VITA-tbaker-tdsi.com'
	}
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
		Value			= 'vpr01-hcxmgr01.cov.virginia.gov'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Yes'
	}
}
## End of TM Configuration, Begin Script

if ($Params.AllowInsecureSSL) {
	Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Write Initial Progress Indicators 
Write-Progress -Id 0 -Activity 'Validate HCX Migration Job Readiness' -PercentComplete 0
Write-Progress -Id 1 -ParentId 0 -Activity 'Validate Job Configuration' -PercentComplete 0



## Authenticate to TM and HCX
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 5 -CurrentOperation 'Authenitcating'
$TMCredential = Get-StoredCredential -CredentialName $Params.TMSavedCredentialName
Import-Module TransitionManager
New-TMSession -Server $Params.TMServerName -Credential $TMCredential -AllowInsecureSSL $True
Connect-HCXServer -Server $Params.HCXServer -Credential $Credential | Out-Null

## Get the VM reference
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 10 -CurrentOperation 'Getting HCX Data'
$HcxSourceSite = Get-HCXSite -Source -Server $Params.HCXServer
$HCXDestinationSite = Get-HCXSite -Destination -Server $Params.HCXServer
$HcxVM = Get-HCXVM -Name $Params.VMName -Server $Params.HCXServer -Site $HcxSourceSite

## Create Replacement Maps
$MapNetworks = @()
$DestinationDatastoreName = ''
$DestinationFolderName = ''
$DestinationComputeContainerName = ''

## Get all of the Dependencies at once.
$AssetDeps = Get-TMDependency -AssetName $Params.VMName -AssetId $Params.TMAssetId


Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 25 -CurrentOperation 'Identifying Destination Network'
$NetworkDeps = $AssetDeps | Where-Object { $_.type -eq 'Network' }
foreach ($Dep in $NetworkDeps) {
    
    $SourceNetworkName = $Dep.dependentName -replace 'VirtualNetwork: ', ''

    ## Find the network we are connected to
    $SourceNetwork = @{ }
    # $SourceNetworkDVP = Get-HCXNetwork -Site $HcxSourceSite -Type 'DistributedVirtualPortgroup' | Where-Object { $_.Name -eq $NetworkName }
    # $SourceNetworkVN = Get-HCXNetwork -Site $HcxSourceSite -Type 'VirtualNetwork' | Where-Object { $_.Name -eq  $NetworkName }
    # $SourceNetworkN = Get-HCXNetwork -Site $HcxSourceSite -Type 'Network' | Where-Object { $_.Name -eq $NetworkName }
    # $SourceNetworkVW = Get-HCXNetwork -Site $HcxSourceSite -Type 'VirtualWire' | Where-Object { $_.Name -eq $NetworkName }
    $SourceNetwork = Get-HCXNetwork -Site $HcxSourceSite  | Where-Object { $_.Name -eq $SourceNetworkName }
    
    # ## Find the right network endpoint ID.  We prefer DVP > VN > N > VW
    # ## Is it a Distributed Port Group?
    # if ($SourceNetworkDVP) {
    #     $SourceNetwork = $SourceNetworkDVP
    # }
    # ## Is it a Virtual Network?
    # elseif ($SourceNetworkVN) {
    #     $SourceNetwork = $SourceNetworkVN
    # }
    # ## Is it a Network?
    # elseif ($SourceNetworkN) {
    #     $SourceNetwork = $SourceNetworkN
    # }
    # ## Is it a Virtual Wire?
    # elseif ($SourceNetworkVW) {
    #     $SourceNetwork = $SourceNetworkVW
    # }
    if(-not $SourceNetwork) {
        
        
        ## No Networks matched what we were looking for.
        continue
     
    }
    
    
    
    $HCXReplacement = Get-TMDependency -AssetName $Dep.dependentName -AssetId $Dep.dependentId -DependencyType 'HCX Replacement'
    
    $DestinationNetworkName = $HCXReplacement.dependentName -replace 'VirtualNetwork: ', ''

    ## Find the network we are connected to
    # $DestinationNetwork = @{ }
    # $DestinationNetworkDVP = Get-HCXNetwork -Site $HcxDestinationSite -Type 'DistributedVirtualPortgroup' | Where-Object { $_.Name -eq $HCXReplacement.dependentName }
    # $DestinationNetworkVN = Get-HCXNetwork -Site $HcxDestinationSite -Type 'VirtualNetwork' | Where-Object { $_.Name -eq $HCXReplacement.dependentName }
    # $DestinationNetworkN = Get-HCXNetwork -Site $HcxDestinationSite -Type 'Network' | Where-Object { $_.Name -eq $HCXReplacement.dependentName }
    # $DestinationNetworkVW = Get-HCXNetwork -Site $HcxDestinationSite -Type 'VirtualWire' | Where-Object { $_.Name -eq $HCXReplacement.dependentName }
    $DestinationNetwork = Get-HCXNetwork -Site $HcxDestinationSite  | Where-Object { $_.Name -eq $DestinationNetworkName}
    
    # ## Find the right network endpoint ID.  We prefer DVP > VN > N > VW
    # ## Is it a Distributed Port Group?
    # if ($DestinationNetworkDVP) {
    #     $DestinationNetwork = $DestinationNetworkDVP
        
    # }
    # ## Is it a Virtual Network?
    # elseif ($DestinationNetworkVN) {
    #     $DestinationNetwork = $DestinationNetworkVN
    # }
    # ## Is it a Network?
    # elseif ($DestinationNetworkN) {
    #     $DestinationNetwork = $DestinationNetworkN
    # }
    # ## Is it a Virtual Wire?
    # elseif ($DestinationNetworkVW) {
    #     $DestinationNetwork = $DestinationNetworkVW
    # }
    ## No Networks matched what we were looking for.
    if(-not $DestinationNetwork ) {
        $DestinationNetworkName = '887-NGIS-TST-SEC-CESC'
        
    }
    
    ## If the Networks were found, add them to the network map
    $MapNetworks += @{
        SourceNetwork      = $SourceNetwork
        DestinationNetwork = $DestinationNetwork
    }
}
## Ensure we have a network map
if($MapNetworks.Count -gt 0){
    $NetworkMapping = $MapNetworks | ForEach-Object { New-HCXNetworkMapping -SourceNetwork $_.SourceNetwork -DestinationNetwork $_.DestinationNetwork }
} else {
    Throw "Unable to locate Target Network."
}


## Get the Destination Folder
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 40 -CurrentOperation 'Identifying Destination Folder'
$FolderDeps = $AssetDeps | Where-Object { $_.type -eq 'Logical Organization' }
foreach ($Dep in $FolderDeps) {
    $HCXFolderReplacement = Get-TMDependency -AssetName $Dep.dependentName -AssetId $Dep.dependentId -DependencyType 'HCX Replacement'
    $DestinationFolderName = $HCXFolderReplacement[0].dependentName
}
## Ensure we have a Folder
if($DestinationFolderName){
    $DestinationFolder = Get-HCXContainer -Name $DestinationFolderName -Site $HCXDestinationSite
} else {
    $DestinationFolder = Get-HCXContainer -Name 'Discovered Virtual Machines' -Site $HCXDestinationSite
}

## Ensure we have a target datastore
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 60 -CurrentOperation 'Identifying Destination Datastore'
$DatastoreDep = $AssetDeps | Where-Object { $_.type -eq 'Datastore' }
$HCXDatastoreReplacement = Get-TMDependency -AssetName $DatastoreDep.dependentName -AssetId $DatastoreDep.dependentId -DependencyType 'HCX Replacement'

$DestinationDatastoreName = $HCXDatastoreReplacement.dependentName
## Ensure we have a datastore
if($DestinationDatastoreName){
    $DestinationDatastore = Get-HCXDatastore -Name $DestinationDatastoreName -Site $HCXDestinationSite
} else {
    $DestinationDatastore = Get-HCXDatastore -Name 'T1-1102-F-0044-Build-a' -Site $HCXDestinationSite
}

Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 70 -CurrentOperation 'Identifying Destination Compute Container'
$ClusterDeps = $AssetDeps | Where-Object { $_.type -eq 'VM Runs On' }
foreach ($Dep in $ClusterDeps) {
    $HCXClusterReplacement = Get-TMDependency -AssetName $Dep.dependentName -AssetId $Dep.dependentId -DependencyType 'HCX Replacement'
    
    $DestinationComputeContainerName = $HCXClusterReplacement.dependentName -Replace 'ClusterComputeResource: ', ''
}
## Ensure we have a Compute Container
if($DestinationComputeContainerName){
    $DestinationComputeContainer = Get-HCXContainer -Name $DestinationComputeContainerName.Replace('Cluster: ', '') -Site $HCXDestinationSite -Type 'ComputeContainer'
} else {
    $DestinationComputeContainer = Get-HCXContainer -Name 'vpr02-w01-comp01' -Site $HCXDestinationSite -Type 'ComputeContainer'
    # Throw "Unable to locate Target Compute Container."
}
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 80 -CurrentOperation 'Validating HCX Job'


# ## Create the Migration Job
# $NewMigration = New-HCXMigration `
#     -VM $HcxVM `
#     -MigrationType 'Bulk' `
#     -SourceSite $HcxSourceSite `
#     -DestinationSite $HCXDestinationSite `
#     -Folder $DestinationFolder `
#     -TargetComputeContainer $DestinationComputeContainer `
#     -TargetDatastore $DestinationDatastore `
#     -NetworkMapping $NetworkMapping `
#     -DiskProvisionType 'Thick' `
#     -UpgradeVMTools $false `
#     -RemoveISOs $false `
#     -ForcePowerOffVm $false `
#     -RetainMac $True `
#     -UpgradeHardware $False `
#     -RemoveSnapshots $False `
#     -ScheduleStartTime ((Get-Date).AddDays(365)) `
#     -ScheduleEndTime ((Get-Date).AddDays(366))
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 100 -CurrentOperation 'HCX Job Validated' -Completed
    
# $TestedMigrationJob = Test-HCXMigration -Migration $NewMigration -ErrorAction 'SilentlyContinue' -ErrorVariable HCXSetupErrors -WarningVariable HcxSetupWarnings -OutVariable HCXMigrationJobValidation *>&1

# if ($HCXSetupErrors) {
#     $HCXSetupErrors | ForEach-Object {
#         $_.Exception.InnerException.Message
#     }
# }
            
            
# ## start the migration job
# if($NewMigration){
#     Write-Progress -Id 2 -ParentId 0 -Activity 'Submit and Start Job' -PercentComplete 5
#     $MigrationJob = Start-HCXMigration -Migration $NewMigration -Confirm:$false
#     Write-Host 'Started Migration Job: '$MigrationJob.Id
#     Write-Progress -Id 2 -ParentId 0 -Activity 'Submit and Start Job' -PercentComplete 100 -Completed
#     Write-Progress -Id 0 -Activity 'HCX Job Started' -PercentComplete 100 -Completed
    
# }


