<####### TransitionManager Action Script ######

	ActionName			= Get Windows System Info 
	ProviderName		= TransitionManager 
	CredentialName 		= 

	Description			= Get a listing of pertinent OS configuration Settings from a Remote Windows Computer.
#>

## Parameter Configuration
$Params = @{
	ComputerName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Provide an Admin level account to retrieve data from the remote computer.'
	}
}
## End of TM Configuration, Begin Script

$NFOOutputPath = Join-Path $userPaths.output 'NFOs' ($Params.ComputerName + ".nfo")
Start-Process `
	-FilePath 'C:\Windows\System32\msinfo32.exe' `
    -ArgumentList "/computer $Params.ComputerName /nfo $NFOOutputPath" `
    -NoNewWindow `
    -Wait `
    -WindowStyle Hidden


