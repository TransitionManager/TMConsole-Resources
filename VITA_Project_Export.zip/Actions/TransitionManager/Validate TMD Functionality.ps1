<####### TransitionManager Action Script ######

	ActionName			= Validate TMD Functionality 
	ProviderName		= TransitionManager 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	CredentialName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'COV-DOMAIN-ADMIN'
	}
	ComputerName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
}
## End of TM Configuration, Begin Script

Write-Host "Hello, World!"


