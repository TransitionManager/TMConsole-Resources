<####### TransitionManager Action Script ######

	ActionName			= TM - Validate Required Credentials 
	ProviderName		= TransitionManager 
	CredentialName 		= 

	Description			= Credentials are collected via the 'Collect Required Credentials' Action, and can be tested/validated with this action.
#>

## Parameter Configuration
$Params = @{
	CredentialName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'COV-DOMAIN-ADMIN'
	}
	ComputerName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
  ## vCenter Servers
  @{
    Id                 = 11
    Name               = 'VITA-vCenter-CESC-VPR01'
    URL                = 'vpr01-w01vc01.cov.virginia.gov'
    AuthenticationTest = [scriptblock] {
      Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
    }
  }
  @{
    Id                 = 12
    Name               = 'VITA-vCenter-CESCVI-VC02'
    URL                = 'cescvi-vc02.cov.virginia.gov'
    AuthenticationTest = [scriptblock] {
      Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
    }
    
  }
  @{
    Id                 = 13
    Name               = 'VITA-vCenter-QTS-VPR02'
    URL                = 'vpr02-w01vc01.cov.virginia.gov'
    AuthenticationTest = [scriptblock] {
      Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
    }
  }
  
  ## HCX Servers
  @{
    Id                 = 14
    Name               = 'VITA-HCX-HCX01'
    URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
    AuthenticationTest = [scriptblock] {
      Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
    }
  }
)

## Calculate Credential Count and Percentage
$CredentialCount = $RequiredCredentials.Count
$PerCredentialPercent = [Math]::round((90 / $CredentialCount))

## Initialize Progress Indicators
Write-Progress -Id 1 -ParentId 0 -PercentComplete 0 -Activity 'Import Modules'
Write-Progress -Id 9 -ParentId 0 -PercentComplete 0 -Activity 'Testing Credentials'

## Create a Progress Indicator for each of the Credentials
ForEach ($Credential in $RequiredCredentials) {

  ## Create a Progress Bar for the Testing of the Credential
  # Write-Host 'Test Credential:'$Credential.Name
  Write-Progress -Id $Credential.Id -ParentId 9 -Activity ('Test Credential: ' + $Credential.Name) -PercentComplete 0
}


## Import Vendor Modules and adjust for Authentication
Write-Progress -Id 1 -ParentId 0 -Activity 'Importing Modules' -PercentComplete 5
$ErrorActionPreference = 'SilentlyContinue'
Import-Module 'VMware.VimAutomation.Core', 'VMware.VimAutomation.Hcx' | Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
$ErrorActionPreference = 'Stop'
Write-Progress -Id 1 -ParentId 0 -Activity 'Modules Imported' -PercentComplete 100 -Completed

## Loop through each required credential
$CredentialTestingPercentage = 5
ForEach ($Credential in $RequiredCredentials) {
  
  ## Write Progress, Starting the test for the cred
  Write-Progress -Id 9 -ParentId 0 -Activity 'Testing Credentials' -PercentComplete $CredentialTestingPercentage
  Write-Progress -Id $Credential.Id -ParentId 9 -Activity ('Validating Credential: ' + $Credential.Name) -PercentComplete 15
  
  ## Assign Credentials for convenient processing
  $SuppliedCredential = Get-StoredCredential -CredentialName $Credential.Name
  $URL = $Credential.URL

  ## Record Credential Collection and Login Test details
  Write-Host 'Attempting to Login to: ' -NoNewline
  Write-Host $Credential.URL -ForegroundColor Cyan -NoNewline
  Write-Host ' as ' -NoNewline
  Write-Host $SuppliedCredential.Username -ForegroundColor Yellow -NoNewLine
  Write-Host '... ' -NoNewline

  ## Try to Login using the Authentication Test script
  try {
    
    ## Test the Credential
    Invoke-Command -ScriptBlock $Credential.AuthenticationTest -NoNewScope
    
  }
  catch {
    Write-Host 'Error!' -ForegroundColor Red
    Write-Progress -Id $Credential.Id -ParentId 9 -Activity ('Credential Validated: ' + $Credential.Name) -PercentComplete 75 -Completed
  } 

  ## Notify the User, Test was successful
  Write-Host 'Successful' -ForegroundColor Cyan
  
  ## Increment the Credential counter for the next one
  $CredentialTestingPercentage = $CredentialTestingPercentage + $PerCredentialPercent

  ## Write Progress, Starting the test for the cred
  Write-Progress -Id 9 -ParentId 0 -Activity 'Testing Credentials' -PercentComplete $CredentialTestingPercentage
  Write-Progress -Id $Credential.Id -ParentId 9 -Activity ('Credential Validated: ' + $Credential.Name) -PercentComplete 100 -Completed

}
Write-Progress -Id 9 -ParentId 0 -PercentComplete 100 -Activity 'Credentials Tested' -Completed


