<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 4. Get Recommended Job Options 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Get Recommended Job Options from VRA for Workload
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Field'
	}
	JobType = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-WorkloadType'
		Value			= 'Workload Field'
	}
	TargetvCenter = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target vCenter'
		Value			= 'CM Target vCenter Field'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.TargetvCenter } | Select-Object -ExpandProperty Name)

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

Write-Progress -Id 0 -Activity "Getting Recommended Job Options" -PercentComplete 5
$ScriptBlock = [scriptblock ] { param($params, $vCenterCredential, $DomainAdminCredential)
    
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'

    ## Temporary workaround Can be removed once VRA727 DNS has properly propogated after name chanage 2020-10-06
    if ($Params.VRA -eq 'VRA727') { $Params.VRA = '10.192.85.250' }
    
    ## Create a Server Object
    $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $DomainAdminCredential
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $DomainAdminCredential
    $TargetvCenter = New-DtServer -Name $params.TargetvCenter -Credential $vCenterCredential -Role "TargetVimServer"
    $OtherServers = @($TargetvCenter)
 
    ## Get Available Workloads from Server
    Write-Progress -Id 0 -Activity 'Validating Licensing for Workload Type' -PercentComplete 33
    $AvailableWorkloadTypes = Get-DtWorkloadType -ServiceHost $DTServer | Where-Object { $_.IsPresent -eq $True }

    ## Only continue if the job type is supported by the endpoint
    if ($params.JobType -in $AvailableWorkloadTypes.Name) {
        
        ## Start by building a workload profile for the server
        Write-Progress -Id 0 -Activity 'Getting Recommended Job Options' -PercentComplete 66
        $workloadGUID = New-DtWorkload -ServiceHost $DTServer -WorkloadTypeName $params.JobType 
        $Workload = Get-DtWorkload -ServiceHost $DTServer -WorkloadId $workloadGUID 
        $DtServerInfo = Get-DtServerInfo -ServiceHost $DTServer
        # $RecommendedJobOptions = Get-DtRecommendedJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $params.JobType -Workload $Workload

    }
    else {
        throw ($params.JobType + ' is not available on this server. Valid types available on this server include ' + [string]($AvailableWorkloadTypes.Name | Out-String))
    }
    
    Write-Progress -Id 0 -Activity 'Recommended Job Options Received' -PercentComplete 100

    ## Return a few objects for the Pwsh shell to receive as $Result
    @{

        DtServerInfo = $DtServerInfo
        # RecommendedJobOptions = $RecommendedJobOptions
    } | ConvertTo-Json -Depth 100 -Compress
    
} 
Invoke-WindowsPowerShell -Params @($params, $vCenterCredential, $DomainAdminCredential) -ScriptBlock $ScriptBlock

## Provide Updates to TM
Update-TMTaskAsset -Field 'CM-ReplicaSettings-Cpus' -Value $DtServerInfo.ProcessorCount
Update-TMTaskAsset -Field 'CM-ReplicaSettings-Memory' -Value  $DtServerInfo.MemorySize
Write-Progress -Id 0 -Activity "Getting Recommended Job Options" -PercentComplete 100 -Completed


