<####### TransitionManager Action Script ######

	ActionName			= Test Carbonite Credentials 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Device Admin Credential'
	}
	DeviceHostName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
		Value			= 'hostn'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'


$ScriptBlock = [scriptblock ] { param($params)

    ## Setup Carbonite
    Write-Host "TMD-Update:Progress: 10"
    Set-Location $params.TmdPsRoot
    . .\App\Providers\Carbonite.ps1
    
    ## Create a Server Object
    Write-Host "TMD-Update:Progress: 30"
    Write-Host "Validating Server Connections"
    $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $params.DeviceAdminCred
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $params.DeviceAdminCred
    $TargetvCenter = New-DtServer -Name $params.TargetvCenter -Credential $params.VCACredential -Role "TargetVimServer"
    $OtherServers = @($TargetvCenter)
    
    
    Write-Host "TMD-Update:Progress: 45"
    Write-Host "Validating Selected Workload/Job Type:"$params.JobType
    $AvailableWorkloadTypes = Get-DtWorkloadType -ServiceHost $DTServer | Where-Object { $_.IsPresent -eq $True }
    
    ## Only continue if the job type is supported by the endpoint
    if ($params.JobType -notin $AvailableWorkloadTypes.Name) {
        throw ($params.JobType + ' is not available on this server. Valid types available on this server include ' + [string]($AvailableWorkloadTypes.Name | Out-String))
    }
        
    ## Job Type is Valid.  Report Progress
    Write-Host "TMD-Update:Progress: 60"
    Write-Host "JobType is valid, Getting Recommended JobOptions"
        
    ## Start by building a workload profile for the server
    $workloadGUID = New-DtWorkload -ServiceHost $DTServer -WorkloadTypeName $params.JobType 
    $Workload = Get-DtWorkload -ServiceHost $DTServer -WorkloadId $workloadGUID 
    $JobOptions = Get-DtRecommendedJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $params.JobType -Workload $Workload
        
    ## Job Type is Valid.  Report Progress
    Write-Host "TMD-Update:Progress: 65"
    Write-Host "Updating  JobOptions with TransitionManager Configurations:"

    ## Supply Standard Job Options
    Write-Host "Updating JobOptions Parameter: JobOptions.Name="($params.Bundle + ' - ' + $params.DeviceName)
    $JobOptions.JobOptions.Name = ($params.Bundle + ' - ' + $params.DeviceName)
        
    Write-Host "Updating JobOptions Parameter: JobOptions.CoreMonitorOptions.MonitorConfiguration.Scripts.PostFailoverScript="$params.PostFailoverScript
    $JobOptions.JobOptions.CoreMonitorOptions.MonitorConfiguration.Scripts.PostFailoverScript = $params.PostFailoverScript
        
    Write-Host "Updating JobOptions Parameter: JobOptions.VRAOptions.VirtualSwitchMapping.TargetVirtualSwitch.Label="$params.TargetNetwork
    $JobOptions.JobOptions.VRAOptions.VirtualSwitchMapping.TargetVirtualSwitch.Label = $params.TargetNetwork
        
    Write-Host "Updating JobOptions Parameter: JobOptions.VRAOptions.ReplicaVMInfo.Path="$params.TargetDatastore
    $JobOptions.JobOptions.VRAOptions.ReplicaVMInfo.Path = $params.TargetDatastore

    # $JobOptions.JobOptions.VraOptions.ReplicaNetworkInterfaceInfo[0].VirtualNicType = "E1000"


    ## Update the path for each Volumes (Windows AND Linux)
    foreach ($Volume in $JobOptions.JobOptions.VRAOptions.Volumes) {
        Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.Volumes['$Volume.Name'].VirtualDiskPath='$params.TargetDatastore
        $Volume.VirtualDiskPath = $params.TargetDatastore

        Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.Volumes['$Volume.Name'].DiskProvisioningType='$params.DiskType
        $Volume.DiskProvisioningType = $params.DiskType
    }
    
    ## Update the path for each Volumes (Linux)
    foreach ($VolumeGroup in $JobOptions.JobOptions.VRAOptions.LVMOptions.VolumeGroups) {
        
        ## Update The Physical Volumes
        foreach ($PhysicalVolume in $VolumeGroup.PhysicalVolume) {
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].PhysicalVolume.VirtualDiskPath='$params.TargetDatastore
            $VolumeGroup.PhysicalVolume.VirtualDiskPath = $params.TargetDatastore
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].PhysicalVolume.DiskProvisioningType='$params.DiskType
            $VolumeGroup.PhysicalVolume.DiskProvisioningType = "Flat Disk"
        }
        ## Update The Logical Volumes
        foreach ($LogicalVolume in $VolumeGroup.LogicalVolume) {
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].LogicalVolume['$LogicalVolume.Name'].VirtualDiskPath='$params.TargetDatastore
            $VolumeGroup.LogicalVolume[$LogicalVolume.Name].VirtualDiskPath = $params.TargetDatastore
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].LogicalVolume['$LogicalVolume.Name'].DiskProvisioningType='$params.DiskType
            $VolumeGroup.LogicalVolume[$LogicalVolume.Name].DiskProvisioningType = "Flat Disk"
        }
    }
      
      
    ## Apply Parameter based Job Options Updates
    $JobOptionsUpdates = $params.PSObject.Properties | Where-Object { $_.Name -like "JobOptions.*" }
    $JobOptionsUpdates | ForEach-Object {
        Write-Host "Updating JobOptions Parameter: "$_.Name"="$_.Value
        Set-Value -object $JobOptions -key $_.Name -Value $_.Value
    }   
    
    ## Verify the Job Options Configuration
    Write-Host "TMD-Update:Progress: 75"
    Write-Host 'Validating JobOptions with VRA ['$params.VRA']' 
    $JobValidationToken = Confirm-DtJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $params.JobType -JobOptions $JobOptions.JobOptions
        
    ## Wait for the job to reach a known status 
    $JobValidationResults = Get-DtVerificationStatus -ServiceHost $DTVRA -Token $JobValidationToken
    while ($JobValidationResults.Task.Status -notin @("Completed", "Faulted", "Canceled")) {
        $JobValidationResults = Get-DtVerificationStatus -ServiceHost $DTVRA -Token $JobValidationToken
        Start-Sleep -Seconds 2
    }

    ## Check the Steps for errors and report them.
    $Errors = $false
    for ($i = 0; $i -lt $JobValidationResults.Steps.Count; $i++) {
        $ValidationStepResult = ($JobValidationResults.Steps[$i].TitleKey + ': ' + $JobValidationResults.Steps[$i].MessageKey)
        if ($JobValidationResults.Steps[$i].Status -eq "Error") {
            
            if ($JobValidationResults.Steps[$i].CanFix) {
                Write-Host 'Warning - Correctible warning:' $ValidationStepResult -ForegroundColor Yellow

            }
            else {
                Write-Host 'Error: '$ValidationStepResult -ForegroundColor Red
                $Errors = $True
            }
        }
        Write-Host $ValidationStepResult -ForegroundColor Gray
    }
    
    if ($Errors) {
        Write-Host "Verification Failed, Job not created."
    }
    else {

        ## Job Is valid and will be accepted
        Write-Host "TMD-Update:Progress: 95"
        Write-Host 'Submitting Job to VRA ['$params.VRA']' 
        $DTJob = New-DTJob -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $params.JobType -JobOptions $JobOptions.JobOptions
    
    }
    ## Return a few objects for the Pwsh shell to receive as $ReturnObject = $Result | Select-Object -Last 1
    return @{
        DTJob                = $DTJob
        JobOptions           = $JobOptions
        JobValidation        = $JobValidation
        JobValidationResults = $JobValidationResults
    } | ConvertTo-Json -Depth 100 -Compress  
} 
Invoke-WindowsPowerShell -Params $params -ScriptBlock $ScriptBlock


