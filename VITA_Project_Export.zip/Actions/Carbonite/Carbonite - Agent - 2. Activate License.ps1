<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 2. Activate License 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Activate Carbonite Agent
#>

## Parameter Configuration
$Params = @{
	ActivationCode = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Activation Code'
	}
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

$ScriptBlock = [scriptblock ] { param($params, $DomainAdminCredential)
    
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Host "Connecting to ["$params.DeviceHostname"] as ["$DomainAdminCredential.Username"]"
    $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $DomainAdminCredential
    
    ## Get the Resulting DT Server Activation Status, look for a DoubleTake Source
    Write-Host "Checking Activation Status"
    $ActivationStatus = Get-DtActivationStatus -ServiceHost $DTServer
    $ServerAsDTSourceActivationStatus = $ActivationStatus.Codes | Where-Object { $_.ProductName = "DoubleTake Source" }
    
    if ($ServerAsDTSourceActivationStatus -and ($ServerAsDTSourceActivationStatus.isValid)) {
        Write-Host "Server is already activated."
        @{
            ActivationStatus = $ActivationStatus
        } | ConvertTo-Json -Depth 100 -Compress
    }
    else {
        Write-Host "Not Activated - Applying Activation Code: "$params.ActivationCode
        Set-DTActivationCode -ServiceHost $DTServer -Code $params.ActivationCode

        Get-DtOnlineActivationRequest -ServiceHost $DTServer `
        | Request-DtOnlineActivation -Code $params.ActivationCode `
        | Set-DtActivationCode 
       
        ## Check the activation status
        
        $ActivationStatus = Get-DtActivationStatus -ServiceHost $DTServer
        ## Return a few objects for the Pwsh shell to receive as $Result
        @{
            ActivationStatus = $ActivationStatus
        } | ConvertTo-Json -Depth 100 -Compress
        
    }
   
}
Invoke-WindowsPowerShell -Params $($Params, $DomainAdminCredential) -ScriptBlock $ScriptBlock

if($ActivationStatus){

    Update-TMTaskAsset -Field 'CM-Activation Code' -Value $ActivationStatus.Codes[0].Code
    Update-TMTaskAsset -Field 'CM-License Status' -Value $ActivationStatus.Codes[0].IsValid
} else {
    throw "Unable to activate Carbonite Agent"
}


