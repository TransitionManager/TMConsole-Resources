<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 1. Push Installation - Via SDK Push 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Push Installation of the Carbonite Agent
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	ActivationCode = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Activation Code'
	}
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Please provide a user account that has Admin permission.'
	}
}
## End of TM Configuration, Begin Script

# $ScriptBlock = [scriptblock ] { param($params)
 
    ## Setup Carbonite
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1
    
    $DTSetup = @"
[Config]
DTSETUPTYPE=DTSO
DTACTIVATIONCODE={0}
DOUBLETAKEFOLDER="C:\Program Files\Carbonite\Replication"
QMEMORYBUFFERMAX=1024
DISKQUEUEFOLDER="C:\Program Files\Carbonite\Replication"
DISKQUEUEMAXSIZE=UNLIMITED
DISKFREESPACEMIN=50
PORT=6320
WINFW_CONFIG_OPTION=ALL
LICENSE_ACTIVATION_OPTION=0
"@ -f $Params.ActivationCode

    $DTSetup  -replace '\n', "`r`n" | Out-File -FilePath ('\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\8.3.1.14 Carbonite Migrate\Extracted\DTSetup_' + $Params.DeviceHostname + '.ini') -Force -Encoding ASCII

    ## Create a Server Object
    # Write-Host "Establishing Server Connections"
    # $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $params.'Device Admin Credential'
    # $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $params.Credential
    
    Write-Host "Performing Installation"
    # Install-DoubleTake -ActivationCode $params.ActivationCode -NoReboot -RemoteServer $DTServer -Schedule (Get-Date) -DotNetPackagePath "\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\Microsoft\dotnetfx35setup.exe"
    # Install-DoubleTake -ActivationCode $params.ActivationCode -NoReboot -RemoteServer $DTServer -Schedule (Get-Date) -x64PackageFolder "\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\8.3.1.14 Carbonite Migrate\Extracted\setup.exe"
    # $Output = Install-DoubleTake -ActivationCode $params.ActivationCode -NoReboot -RemoteServer $DTServer -Schedule (Get-Date) -x64PackageFolder "C:\Program Files\Carbonite\Replication\X64\setup.exe"
    # $Output | ConvertTo-Json -Compress -Depth 100 | Out-String
    
    ## Move the Installer file to the temp folder
    Copy-Item `
        -Path '\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\Microsoft\dotnetfx35setup.exe' `
        -Destination ('\\' + $Params.DeviceHostName + '\c$\temp') `
        -Force
    Copy-Item `
        -Path '\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\8.3.1.14 Carbonite Migrate\Extracted\setup.exe' `
        -Destination ('\\' + $Params.DeviceHostName + '\c$\temp') `
        -Force
    
    Copy-Item `
        -Path ('\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\8.3.1.14 Carbonite Migrate\Extracted\DTSetup_' + $Params.DeviceHostname + '.ini') `
        -Destination ('\\' + $Params.DeviceHostName + '\c$\temp\DTSetup.ini') `
        -Force

    ## Invoke PSExec
    $PsExec = Join-Path $appPaths.winExes 'PsExec.exe'

    # $InstallCommand = 'c:\temp\setup.exe /s /v\"DTSETUPINI=\\""c:\temp\DTSetup_' + $Params.DeviceHostname + '.ini\\"" /n\"'
    # $InstallCommand = 'c:\temp\setup.exe /s /v\"DTSETUPINI=\\""C:\Temp\DTSetup.ini\\"" /qn\"'
    # &($PsExec) ('\\' + $Params.DeviceHostName) -nobanner -accepteula $InstallCommand
    $InstallCommand = @"
    cd c:\temp
    msiexec /i c:\Temp\Double-Take.msi /qn /norestart /lx dtinstalllog.txt DTSETUPINI=c:\temp\DTSetup.ini
"@
    
    # $InstallCommand = 'c:\temp\dotnetfx35setup.exe'
    &($PsExec) ('\\' + $Params.DeviceHostName) -nobanner -accepteula $InstallCommand
    
    # Invoke-Command -ComputerName $Params.DeviceHostname -ScriptBlock {
    #     Write-Host "C:\Program Files\Carbonite\Replication\X64\setup.exe" 

    # }
    
    # Start-Sleep -Seconds 10
    
    ## Get the server details to confirm installation
#     Write-Host 'Getting server info'
#     $DTServerInfo = Get-DtServerInfo -ServiceHost $DTServer
#     if (-not $DTServerInfo) {
#         Write-Host 'Carbonite Double-Take DID NOT install properly.'
#         Throw 'Carbonite Double-Take DID NOT install properly.'
#     }
#     else {
#         Write-Host 'Installation Complete.'
#         @{ 
#             DTServerInfo = $DTServerInfo
#         } | ConvertTo-Json -Compress
#     }
# }
# Invoke-WindowsPowerShell -Params $params -ScriptBlock $ScriptBlock



# [xml]$SystemStateXml = $DTServerInfo.SystemStateDefinition
# $SystemState = $SystemStateXml | ConvertFrom-Xml
# Update-TMTaskAsset -Field 'DSID-Carbonite' -Value $DTServerInfo.NodeLockedServerInfo
# Update-TMTaskAsset -Field 'CM-Activation Code' -Value $SystemState.Configuration.ServiceInfo.ActivationCode.Value
# Update-TMTaskAsset -Field 'CM-Installed Version' -Value $SystemState.Configuration.ServiceInfo.ProductVersion.Value


