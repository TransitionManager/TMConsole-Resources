<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 9. Remote Uninstall 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Uninstall Carbonite Agent from machine
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'


$ScriptBlock = [scriptblock ] { param($params)

    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Progress -Activity "Connecting to Server" -PercentComplete 20
    $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $params.'Device Admin Credential'
    
    Write-Progress -Activity "Uninstalling Carbonite Replication" -PercentComplete 25
    Uninstall-DoubleTake -RemoteServer $DTServer
    
    ## Report Completion
    Write-Progress -Activity "Carbonite Replication has been Uninstalled" -PercentComplete 100 -Completed

    ## Always return an object as JSON in the pipeline so
    ## the Pwsh shell to receive as $ReturnObject = $Result | Select-Object -Last 1
    @{
    } | ConvertTo-Json -Depth 100 -Compress
}
Invoke-WindowsPowerShell -Params $params -ScriptBlock $ScriptBlock


