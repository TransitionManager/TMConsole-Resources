<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Replication Job - 1. Create Job 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Create Replication Job
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	LicenseKey = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Activation Code'
	}
	JobType = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-WorkloadType'
		Value			= 'Workload Type Column'
	}
	DiskType = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Flat Disk'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Custom Field'
	}
	Bundle = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Bundle'
	}
	DeviceName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	TargetvCenter = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target vCenter'
		Value			= 'Target vCenter Custom Field'
	}
	'JobOptions.ManagementServiceTargetPort' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '6325'
	}
	'JobOptions.BandwidthOptions.Mode' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '0'
	}
	'JobOptions.CoreConnectionOptions.TargetEnginePort' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '6320'
	}
	'JobOptions.BandwidthOptions.Limit' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '0'
	}
	'JobOptions.VRAOptions.ReplicaVMInfo.DisplayName' = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	'JobOptions.VRAOptions.ReplicaVMInfo.Cpus' = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-ReplicaSettings-Cpus'
	}
	'JobOptions.VRAOptions.ReplicaVMInfo.CoresPerProcessor' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '1'
	}
	'JobOptions.VRAOptions.ReplicaVMInfo.Memory' = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-ReplicaSettings-Memory'
	}
	TargetDatastore = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Datastore'
	}
	TargetNetwork = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Network'
	}
	PostFailoverScript = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target PostFailoverScript'
		Value			= 'Failover Script Custom Field'
	}
	'JobOptions.CoreConnectionOptions.ConnectionStartParameters.CompressionLevel.Level' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '-1'
	}
	'JobOptions.CoreConnectionOptions.ConnectionStartParameters.CompressionLevel.Algorithm' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '0'
	}
	TargetVMContainer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Compute Container'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.TargetvCenter } | Select-Object -ExpandProperty Name)

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

# $ScriptBlock = [scriptblock ] { 

Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll' -UseWindowsPowerShell


$CompatibilitySession = Get-PSSession -Name WinPSCompatSession
Invoke-Command -Session $CompatibilitySession -ArgumentList @($Params, $DomainAdminCredential, $vCenterCredential) -ScriptBlock {
    param($Params, $DomainAdminCredential, $vCenterCredential)

    function Convert-Size {            
        [cmdletbinding()]            
        param(            
            [validateset("Bytes", "KB", "MB", "GB", "TB")]            
            [string]$From,            
            [validateset("Bytes", "KB", "MB", "GB", "TB")]            
            [string]$To,            
            [Parameter(Mandatory = $true)]            
            [double]$Value,            
            [int]$Precision = 2          
        )            
        switch ($From) {            
            "Bytes" { $value = $Value }            
            "KB" { $value = $Value * 1024 }            
            "MB" { $value = $Value * 1024 * 1024 }            
            "GB" { $value = $Value * 1024 * 1024 * 1024 }            
            "TB" { $value = $Value * 1024 * 1024 * 1024 * 1024 }            
        }            
                    
        switch ($To) {            
            "Bytes" { return $value }            
            "KB" { $Value = $Value / 1KB }            
            "MB" { $Value = $Value / 1MB }            
            "GB" { $Value = $Value / 1GB }            
            "TB" { $Value = $Value / 1TB }            
                    
        }            
                    
        return [Math]::Round($value, $Precision, [MidPointRounding]::AwayFromZero)            
                   
    }  
    
    ## Define a few Methods
    function Get-Value($object, $key) {
        $p1, $p2 = $key.Split(".")
        if ($p2) { return Get-Value -object $object.$p1 -key $p2 }
        else { return $object.$p1 }
    }
    function Set-Value($object, $key, $Value) {
            
        ## Deal with appropriate typing
        if ($Value -match "^\d+$") { $Value = [Int64]$Value }
        if ($Value -eq 'true') { $Value = $True }
        if ($Value -eq 'false') { $Value = $False }
    
        ## Split the Key into comparable parts
        # $p1, $p2 = $key.Split(".") | Select-Object -First 2
        $p1, $p2 = $key.Split(".")
            
        ## Is the node an array reference
        if ($p1 -like '*]') {
                
            ## This node is an array object, separte the array node and the array pointer
            $p1Node = $p1 | Select-String -Pattern ".*[a-zA-Z]" | ForEach-Object { $_.Matches[0].Value }
            $p1Pointer = $p1 | Select-String -Pattern "[0-9]" | ForEach-Object { $_.Matches[0].Value }
            if ($p2) { Set-Value -object $object.$p1Node[$p1Pointer] -key $p2 -Value $Value }
            else { $object.$p1 = $Value }
        }
    
        else {
            ## This object is a flat node object, not an array.
            # Write-Host "Node is an object"
            if ($p2) { Set-Value -object $object.$p1 -key $p2 -Value $Value }
            else { $object.$p1 = $Value }
        }
    }

    ## Create Progress Indicators
    Write-Progress -Id 0 -Activity "Create Replication Job" -PercentComplete 0
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 0 -Status Pending
    Write-Progress -Id 20 -ParentId 0 -Activity "Create Carbonite Connections" -PercentComplete 0 -Status Pending
    Write-Progress -Id 30 -ParentId 0 -Activity "Get Recomended Job Options" -PercentComplete 0 -Status Pending
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 0 -Status Pending
    Write-Progress -Id 50 -ParentId 0 -Activity "Validate Replication Job" -PercentComplete 0 -Status Pending
    Write-Progress -Id 60 -ParentId 0 -Activity "Submit Replication Job" -PercentComplete 0 -Status Pending

    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $Params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    # Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'

    ## Temporary workaround Can be removed once VRA727 DNS has properly propogated after name chanage 2020-10-06
    if ($Params.VRA -eq 'VRA727') { $Params.VRA = '10.192.85.250' }

    ## Test Access to Source and VRA
    Write-Progress -Id 20 -ParentId 0 -Activity "Create Carbonite Connections" -PercentComplete 5
    # if(-Not (Test-Connection -ComputerName $Params.DeviceHostname -TCPPort 6325)){
    #     throw ("Unable to reach Carbonite Service on Source Server: " + $Params.DeviceHostname)
    # }
    # if(-Not (Test-Connection -ComputerName $Params.VRA -TCPPort 6325)){
    #     throw ("Unable to reach Carbonite Service on Source Server: " + $Params.DeviceHostname)
    # }

    ## Create Carbonite Objects
    $DTServer = New-DtServer -Name ($Params.DeviceHostname + ":6325") -Credential $DomainAdminCredential
    $DTVRA = New-DtServer -Name ($Params.VRA + ":6325") -Credential $DomainAdminCredential
    $TargetvCenter = New-DtServer -Name $Params.'TargetvCenter' -Credential $vCenterCredential -Role "TargetVimServer"
    $OtherServers = @($TargetvCenter)
    
    ## Validate the workload selection for the Source Machine
    Write-Host "Validating Selected Workload/Job Type:"$Params.JobType
    $AvailableWorkloadTypes = Get-DtWorkloadType -ServiceHost $DTServer | Where-Object { $_.IsPresent -eq $True }
    
    ## Only continue if the job type is supported by the endpoint
    if ($Params.JobType -notin $AvailableWorkloadTypes.Name) {
        throw ($Params.JobType + ' is not available on this server. Valid types available on this server include ' + [string]($AvailableWorkloadTypes.Name | Out-String))
    }
    Write-Progress -Id 20 -ParentId 0 -Activity "Carbonite Connections Created" -PercentComplete 100 -Completed
    
    ## Job Type is Valid.  Get Recommended Job Options
    Write-Progress -Id 30 -ParentId 0 -Activity "Get Recomended Job Options" -PercentComplete 5
    
    ## Start by building a workload profile for the server
    $workloadGUID = New-DtWorkload -ServiceHost $DTServer -WorkloadTypeName $Params.JobType 
    $Workload = Get-DtWorkload -ServiceHost $DTServer -WorkloadId $workloadGUID 
    $JobOptions = Get-DtRecommendedJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $Params.JobType -Workload $Workload
    
    if (-Not $JobOptions) {
        throw 'There was an issue when creating JobOptions on the VRA. Please verify connectivity and Configurations'
    }
    
    ## Job Type is Valid.  Report Progress
    Write-Progress -Id 30 -ParentId 0 -Activity "Get Recomended Job Options" -PercentComplete 100 -Completed
    
    ## Update Job Options
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 5
    
    ## Update Job Name
    Write-Host "Updating JobOptions Parameter: JobOptions.Name="($Params.Bundle + ' - ' + $Params.DeviceName)
    $JobOptions.JobOptions.Name = ($Params.Bundle + ' - ' + $Params.DeviceName).ToUpper()
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 10
    
    ## Set Post Failover Script Setting
    Write-Host "Updating JobOptions Parameter: JobOptions.CoreMonitorOptions.MonitorConfiguration.Scripts.PostFailoverScript="$Params.PostFailoverScript
    $JobOptions.JobOptions.CoreMonitorOptions.MonitorConfiguration.Scripts.PostFailoverScript = $Params.PostFailoverScript
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 20
    
    ## Set Target Virtual Switch Mapping
    Write-Host "Updating JobOptions Parameter: JobOptions.VRAOptions.VirtualSwitchMapping.TargetVirtualSwitch.Label="$Params.TargetNetwork
    foreach ($VirtualSwitchMapping in $JobOptions.JobOptions.VRAOptions.VirtualSwitchMapping) {
        $VirtualSwitchMapping.TargetVirtualSwitch.Label = $Params.TargetNetwork
    }
    
    ## VITA Customized - Remove EBARS Interface
    $JobOptions.JobOptions.VRAOptions.VirtualSwitchMapping | Where-Object {$_.SourceVirtualSwitch.Label -like '*EBARS*'}
    
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 30
    
    ## Set VM Replica Path
    Write-Host "Updating JobOptions Parameter: JobOptions.VRAOptions.ReplicaVMInfo.Path="$Params.TargetDatastore
    $JobOptions.JobOptions.VRAOptions.ReplicaVMInfo.Path = $Params.TargetDatastore
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 40
    
    ## Update the path for each Volumes (Windows AND Linux)
    foreach ($Volume in $JobOptions.JobOptions.VRAOptions.Volumes) {
        Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.Volumes['$Volume.Name'].VirtualDiskPath='$Params.TargetDatastore
        $Volume.VirtualDiskPath = $Params.TargetDatastore
        
        Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.Volumes['$Volume.Name'].DiskProvisioningType='$Params.DiskType
        $Volume.DiskProvisioningType = $Params.DiskType
    }
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 70
    
    ## Update the path for each Volumes (Linux)
    foreach ($VolumeGroup in $JobOptions.JobOptions.VRAOptions.LVMOptions.VolumeGroups) {
        
        ## Update The Physical Volumes
        foreach ($PhysicalVolume in $VolumeGroup.PhysicalVolume) {
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].PhysicalVolume.VirtualDiskPath='$Params.TargetDatastore
            $VolumeGroup.PhysicalVolume.VirtualDiskPath = $Params.TargetDatastore
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].PhysicalVolume.DiskProvisioningType='$Params.DiskType
            $VolumeGroup.PhysicalVolume.DiskProvisioningType = $Params.DiskType
        }
        ## Update The Logical Volumes
        foreach ($LogicalVolume in $VolumeGroup.LogicalVolume) {
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].LogicalVolume['$LogicalVolume.Name'].VirtualDiskPath='$Params.TargetDatastore
            $VolumeGroup.LogicalVolume[$LogicalVolume.Name].VirtualDiskPath = $Params.TargetDatastore
            
            Write-Host 'Updating JobOptions Parameter: JobOptions.VRAOptions.LVMOptions.VolumeGroups['$VolumeGroup.Name'].LogicalVolume['$LogicalVolume.Name'].DiskProvisioningType='$Params.DiskType
            $VolumeGroup.LogicalVolume[$LogicalVolume.Name].DiskProvisioningType = $Params.DiskType
        }
    }
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 85
    
    ## Apply Parameter based Job Options Updates
    $JobOptionsUpdates = $Params.PSObject.Properties | Where-Object { $_.Name -like "JobOptions.*" }
    $JobOptionsUpdates | ForEach-Object {
        Write-Host "Updating JobOptions Parameter: "$_.Name"="$_.Value
        Set-Value -object $JobOptions -key $_.Name -Value $_.Value
    }   
    Write-Progress -Id 40 -ParentId 0 -Activity "Update Job Options" -PercentComplete 100 -Completed
    
    ## Verify the Job Options Configuration
    Write-Progress -Id 50 -ParentId 0 -Activity "Submitting Updated Replication Job for Verification" -PercentComplete 5
    Write-Host 'Validating JobOptions with VRA ['$Params.VRA']' 
    $JobValidationToken = Confirm-DtJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $Params.JobType -JobOptions $JobOptions.JobOptions
    
    if (-Not $JobValidationToken) {
        throw "Unable to confirm options with the VRA"
    }

    ## Wait for the job to reach a known status 
    Write-Progress -Id 50 -ParentId 0 -Activity "Verification Report Being Generated" -PercentComplete 50
    $JobValidationResults = Get-DtVerificationStatus -ServiceHost $DTVRA -Token $JobValidationToken

    if (-Not $JobValidationResults) {
        throw "Unable to get Verification Results from VRA"
    }

    while ($JobValidationResults.Task.Status -notin @("Completed", "Faulted", "Canceled")) {
        Write-Host "Job Validation Status:" ($JobValidationResults.Task.Status)
        Start-Sleep -Seconds 2
        $JobValidationResults = Get-DtVerificationStatus -ServiceHost $DTVRA -Token $JobValidationToken
    }
    Write-Progress -Id 50 -ParentId 0 -Activity "Verification Report Complete, checking for errors" -PercentComplete 50
    
    ## Check the Steps for errors and report them.  
    ## Don't throw any of the individual errors, there may be more than one. Write all of them.
    $Errors = $false
    for ($i = 0; $i -lt $JobValidationResults.Steps.Count; $i++) {
        $ValidationStepResult = ($JobValidationResults.Steps[$i].TitleKey + ': ' + $JobValidationResults.Steps[$i].MessageKey)
        if ($JobValidationResults.Steps[$i].Status -eq "Error") {
            
            if ($JobValidationResults.Steps[$i].CanFix) {
                Write-Host 'Warning - Correctible warning:' $ValidationStepResult -ForegroundColor Yellow
                
            } else {
                Write-Host 'Error: '$ValidationStepResult -ForegroundColor Red
                $Errors = $True
            }
        }
        Write-Host $ValidationStepResult -ForegroundColor Gray
    }
    
    if ($Errors) {
        throw "Verification Failed, Job not created."
    }
    Write-Progress -Id 50 -ParentId 0 -Activity "Verification Report created, checking for errors" -PercentComplete 100 -Completed
    Write-Progress -Id 60 -ParentId 0 -Activity "Submitting Replication Job to VRA" -PercentComplete 5
    
    ## Job Is valid and will be accepted
    Write-Host 'Submitting Job to VRA ['$Params.VRA']' 
    $DTJob = New-DTJob -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $Params.JobType -JobOptions $JobOptions.JobOptions
    
    
    ## Update Progress for Carbonite Action
    Write-Progress -Id 60 -ParentId 0 -Activity "Job Submitted to VRA" -PercentComplete 100 -Completed
    Write-Progress -Id 0 -Activity "Replication Job Created" -PercentComplete 100 -Completed
    
    ## Return a few objects for the Pwsh shell to receive as $ReturnObject = $Result | Select-Object -Last 1
    # return @{
    #     DTJob                 = $DTJob
    #     JobOptions            = $JobOptions
    #     JobValidation         = $JobValidation
    #     JobValidationToken    = $JobValidationToken
    #     JobValidationResults  = $JobValidationResults
    # } | ConvertTo-Json -Depth 100 -Compress  
} 
# Invoke-WindowsPowerShell -Params $Params -ScriptBlock $ScriptBlock


