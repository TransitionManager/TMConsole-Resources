<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 0. Full Setup 1-4 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Perform Full Setup of Carbonite
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Custom Field'
	}
	JobType = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-WorkloadType'
		Value			= 'Workload Field'
	}
	TargetvCenter = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Compute Container'
	}
	ActivationCode = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Activation Code'
	}
	'ServerOption-EncryptNetworkData' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '1'
	}
	'get_credential-TargetvCenterCredential' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Target vCenter Admin Credential'
	}
	'get-Credential-DeviceAdminCred' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Device Admin Credential'
	}
}
## End of TM Configuration, Begin Script

$ScriptBlock = [scriptblock ] { param($Params)
 ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Host "TMD-Update:Progress: 10"
    Write-Host "Establishing Server Connections"
    $DTServer = New-DtServer -Name ($Params.DeviceHostname + ":6325") -Credential $Params.DeviceAdminCred
    $DTVRA = New-DtServer -Name ($Params.VRA + ":6325") -Credential $Params.DeviceAdminCred
    $TargetvCenter = New-DtServer -Name $Params.TargetvCenter -Credential $Params.VCACredential -Role "TargetVimServer" 
    $OtherServers = @($TargetvCenter)

    Install-DoubleTake -ActivationCode $Params.ActivationCode -NoReboot -RemoteServer $DTServer -Schedule (Get-Date) -Debug

    ## Get the Resulting DT Server Activation Status
    Write-Host "Checking Activation Status"
    $ActivationStatus = Get-DtActivationStatus -ServiceHost $DTServer
    if (
        ($ActivationStatus.Codes.ProductName -ne "Double-Take Move Source") `
            -and ($ActivationStatus.Codes.Code -eq "") `
    ) {
        Write-Host "Not Licensed - Applying License Code: "$Params.ActivationCode
        $ActivationStatus = Set-DTActivationCode -ServiceHost $DTServer -Code $Params.ActivationCode

        Get-DtOnlineActivationRequest -ServiceHost $DTServer `
        | Request-DtOnlineActivation -Code $Params.ActivationCode `
        | Set-DtActivationCode 
   
        ## Check the activation status
        # $ActivationStatus = Get-DtActivationStatus -ServiceHost $DTServer
        ## Return a few objects for the Pwsh shell to receive as $Result
        
    }
    else {
        Write-Host "Server was licensed during installation "
    }

    ## Apply the server settings from the Parameters
    $ServerOptions = $Params.PSObject.Properties | Where-Object { $_.Name -like 'ServerOption-*' }
    $ServerOptions | ForEach-Object {
        
        # Deal with appropriate typing
        if ($_.Value -match "^\d+$") { $OptionValue = [Int64]$_.Value }
        if ($_.Value -eq 'true') { $OptionValue = $True }
        if ($_.Value -eq 'false') { $OptionValue = $False }

        $OptionName = $_.Name.Replace('ServerOption-', '')

        Write-Host "Changing Options on Server"$OptionName" = "$OptionValue
        Set-DTOption -ServiceHost $DTServer -Setting (@{$OptionName = $OptionValue })
    }


    $AvailableWorkloadTypes = Get-DtWorkloadType -ServiceHost $DTServer | Where-Object { $_.IsPresent -eq $True }

    ## Only continue if the job type is supported by the endpoint
    if ($Params.JobType -in $AvailableWorkloadTypes.Name) {
        
        ## Start by building a workload profile for the server
        $workloadGUID = New-DtWorkload -ServiceHost $DTServer -WorkloadTypeName $Params.JobType 
        $Workload = Get-DtWorkload -ServiceHost $DTServer -WorkloadId $workloadGUID 
        $RecommendedJobOptions = Get-DtRecommendedJobOptions -ServiceHost $DTVRA -Source $DTServer -OtherServers $OtherServers -JobType $Params.JobType -Workload $Workload
        ## Return a few objects for the Pwsh shell to receive as $Result
        @{
            RecommendedJobOptions = $RecommendedJobOptions
        } | ConvertTo-Json -Depth 100 -Compress
    }
    else {
        throw ($Params.JobType + ' is not available on this server. Valid types available on this server include ' + [string]($AvailableWorkloadTypes.Name | Out-String))
    }
}
Invoke-WindowsPowerShell -Params $Params -ScriptBlock $ScriptBlock

$global:Data = @{
    assetUpdates = @{
        'CM-ReplicaSettings-Cpus'              = $RecommendedJobOptions.JobOptions.VRAOptions.ReplicaVMInfo.Cpus
        'CM-ReplicaSettings-CoresPerProcessor' = $RecommendedJobOptions.JobOptions.VRAOptions.ReplicaVMInfo.CoresPerProcessor
        'CM-ReplicaSettings-Memory'            = $RecommendedJobOptions.JobOptions.VRAOptions.ReplicaVMInfo.Memory
    }
}


