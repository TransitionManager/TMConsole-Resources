<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Replication Job - 5. Monitor Failover until Complete 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Monitor Carbonite Failover Job
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Custom Field'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

$ScriptBlock = [scriptblock ] { param($params, $DomainAdminCredential)
    
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Host "TMD-Update:Progress: 10"
    Write-Host "Validating Server Connections"
    
    ## Get Replication Job
    Write-Progress -Activity "Getting Replication Job" -PercentComplete 20
    Write-Host "Getting Job for :"$params.DeviceHostname
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $DomainAdminCredential
    $DTJob = Get-DtJob -ServiceHost $DTVRA | Where-Object { $_.SourceHostUri -like ("dtms://" + $params.DeviceHostname + "*") }
    if ($null -eq $DTJob) {
        Write-Host "No Job was found on the VRA ["$params.VRA"]"
        Throw ("No Job was found on the VRA [" + $params.VRA + "]")
    }

    ## Report the Job, including global ENUMs
    Write-Host "Job Name:"$DTJob.Options.Name
    Write-Host "Job ID:"$DTJob.Id
    Write-Host "Job Type:"$DTJob.JobType
    Write-Host "Source Unique Id:"$DTJob.SourceUniqueId
    Write-Host "Target Unique Id:"$DTJob.TargetUniqueId

    ## Log the items we return to prevent returning them again
    $LoggedItems = @{
        HighLevelStatus = @()
        ActionTitleId   = @()
        ActionMessage   = @()
        Percentage      = 0
    }
    
    ## Begin Looping to Monitor the Status Details
    $IsFailedOver = $False
    while ($IsFailedOver) {

        ## Refresh the Job Data
        $DTJob = Get-DtJob -ServiceHost $DTVRA -JobId $DTJob.id
        $HighLevelStatus = $DTJob.Status.HighLevelState.ToString().Trim()
        $LowLevelStatus = $DTJob.Status.ExtendedLowLevelStates
        $Percentage = [math]::Round($DTJob.Status.PermillageComplete / 10)
         
        ## Check for Errors
        if ($DTJob.Status.IsInError) {
            Write-Host "Job is in an error state."
            Throw "Job is in an error state."
        }
 
         
        ## Report Current Job Status
        if ($HighLevelStatus -notin $LoggedItems.HighLevelStatus) {
            $LoggedItems.HighLevelStatus += $HighLevelStatus
            Write-Host "Status:[ $HighLevelStatus ]"
        }
     

        ## Update the Percentage
        if ($LoggedItems.Percentage -ne $Percentage) {
            $LoggedItems.Percentage = $Percentage
            Write-Progress -Id 0 -Activity $HighLevelStatus -PercentComplete $Percentage
        }

        ## Report that Calculation is occuring
        if ($DTJob.Statistics.CoreConnectionDetails.ReplicationSetCalcInProgress) {
            if ("Calculation" -notin $LoggedItems.HighLevelStatus) {
                $LoggedItems.HighLevelStatus += 'Calculation'
                Write-Progress -Id 0 -Activity "Calculating Replication Size Requirements" -PercentComplete $Percentage
            }
        }
 
        ## Report Low Level States
        foreach ($State in $LowLevelStatus) {
            if ($State.MessageId -notin $LoggedItems.LowLevelStates ) {
                $LoggedItems.LowLevelStates += $State.MessageId
                Write-Host $State.MessageId
            }
        }
     
        ## Mirroring Status 
        if ($HighLevelStatus -like 'Mirroring') {
            $RemainingGB = Convert-Size -From Bytes -To GB -Value ($DTJob.Statistics.CoreConnectionDetails.MirrorBytesRemaining)  
            $TotalGB = Convert-Size -From Bytes -To GB -Value ($DTJob.Statistics.CoreConnectionDetails.MirrorBytesTransmitted + $DTJob.Statistics.CoreConnectionDetails.MirrorBytesRemaining)
            Write-Progress -Id 0 -Activity 'Replication Progress:'$RemainingGB' of '$TotalGB' GB remaining.' -PercentComplete $Percentage
        
        }
        
        ## Report the Actions already taken
        foreach ($Action in $DTJob.Status.Actions) {
            if ($Action.TitleId -notin $LoggedItems.ActionTitleId ) {
                $LoggedItems.ActionTitleId += $Action.TitleId
                Write-Host $Action.TitleId": "$Action.MessageId
            }
        }

        if ($DTJob.Status.HighLevelState -eq 'FailedOver') {
            $IsFailedOver = $True
        }
        else {
            Start-Sleep -Seconds 1
        } 
 
    }
    
    Write-Host $params.DeviceHostname" has successfully failed over."
    Write-Progress -Id 0 -Activity ($params.DeviceHostname + " is ready for failover.") -PercentComplete 100 -Completed
}
Invoke-WindowsPowerShell -Params @($params, $DomainAdminCredential) -ScriptBlock $ScriptBlock


