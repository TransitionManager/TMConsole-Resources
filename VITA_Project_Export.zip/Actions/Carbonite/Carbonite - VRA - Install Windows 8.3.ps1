<####### TransitionManager Action Script ######

	ActionName			= Carbonite - VRA - Install Windows 8.3 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	ComputerName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Provide a device Admin credential for Windows.'
	}
	InstallerFilePath = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '\\JSSHARE\Data\Server\Carbonite\Migrate 8.3\8.3.1.14 Carbonite Migrate\Extracted\'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

$LocalSystemTempPath = ('\\' + $Params.ComputerName + '\C$\Windows\Temp\CarboniteInstall\')

## Create Progress Items
Write-Progress -Id 0 -Activity 'Install VRA Software' -PercentComplete 0
Write-Progress -Id 10 -ParentId 0 -Activity 'Copy Installer to System' -PercentComplete 0
Write-Progress -Id 20 -ParentId 0 -Activity 'Install VRA Software' -PercentComplete 0
Write-Progress -Id 30 -ParentId 0 -Activity 'Remove Installer Files' -PercentComplete 0

## Copy the Install folder to the local disk

Write-Progress -Id 10 -ParentId 0 -Activity 'Copy Installer to System' -PercentComplete 5
Copy-Item `
-Path $Params.InstallerFilePath `
-Destination $LocalSystemTempPath `
-Recurse `
-Force
Get-ChildItem -Path $LocalSystemTempPath -Recurse | Format-Table Name,CreationTime
Write-Progress -Id 10 -ParentId 0 -Activity 'Installer Copied to System' -PercentComplete 100 -Completed

## Assemble the StartProcess command
$ScriptBlock = {
    
     Start-Process "C:\Windows\Temp\CarboniteInstall\Extracted\setup.exe" `
     -ArgumentList ('/s /v"DTSETUPINI=\"' + $LocalSystemTempPath + '\DTSetup.ini\" /qn"') `
     -Verbose `
     -Wait
}

## Invoke the Install
Write-Progress -Id 20 -ParentId 0 -Activity 'Install VRA Software' -PercentComplete 5
Invoke-Command -ComputerName $Params.ComputerName -ScriptBlock $ScriptBlock -Credential $Params.'Device Admin Credential' -Verbose
Write-Progress -Id 20 -ParentId 0 -Activity 'VRA Software Installed' -PercentComplete 100 -Completed

## Remove the Installation Files
Write-Progress -Id 30 -ParentId 0 -Activity 'Remove Installer Files' -PercentComplete 5
Remove-Item `
-Path ('\\' + $Params.ComputerName + '\C$\\Windows\Temp\CarboniteInstall\') `
-Recurse `
-Force

Write-Progress -Id 30 -ParentId 0 -Activity 'Installer Files Removed' -PercentComplete 100 -Completed


