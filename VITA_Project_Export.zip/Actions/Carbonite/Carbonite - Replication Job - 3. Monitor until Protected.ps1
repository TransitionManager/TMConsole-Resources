<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Replication Job - 3. Monitor until Protected 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Monitor a Carbonite Job
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'Custom VRA Field'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

#Action Name = Replication Job - 3. Monitor until Protected
$ScriptBlock = [scriptblock ] { param($params, $DomainAdminCredential)
     
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    function Convert-Size {            
        [cmdletbinding()]            
        param(            
            [validateset("Bytes", "KB", "MB", "GB", "TB")]            
            [string]$From,            
            [validateset("Bytes", "KB", "MB", "GB", "TB")]            
            [string]$To,            
            [Parameter(Mandatory = $true)]            
            [double]$Value,            
            [int]$Precision = 2          
        )            
        switch ($From) {            
            "Bytes" { $value = $Value }            
            "KB" { $value = $Value * 1024 }            
            "MB" { $value = $Value * 1024 * 1024 }            
            "GB" { $value = $Value * 1024 * 1024 * 1024 }            
            "TB" { $value = $Value * 1024 * 1024 * 1024 * 1024 }            
        }            
                    
        switch ($To) {            
            "Bytes" { return $value }            
            "KB" { $Value = $Value / 1KB }            
            "MB" { $Value = $Value / 1MB }            
            "GB" { $Value = $Value / 1GB }            
            "TB" { $Value = $Value / 1TB }            
                    
        }            
                    
        return [Math]::Round($value, $Precision, [MidPointRounding]::AwayFromZero)            
                   
    }  

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Progress -Activity "Creating Server Connections" -PercentComplete 5
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $DomainAdminCredential
    
    Write-Progress -Activity "Getting Replication Job" -PercentComplete 10 -Status ("Getting Job for :" + $params.DeviceHostname)
    # Write-Host "Getting Job for :"$params.DeviceHostname
    $DTJob = Get-DtJob -ServiceHost $DTVRA | Where-Object { $_.SourceHostUri -like ("dtms://" + $params.DeviceHostname + "*") }
    
    if ($null -eq $DTJob) {
        Write-Host "No Job was found on the VRA ["$params.VRA"]"
        Throw ("No Job was found on the VRA [" + $params.VRA + "]")
    }
 
    ## Report the Job, including global ENUMs
    Write-Host "Job Name:"$DTJob.Options.Name
    Write-Host "Job ID:"$DTJob.Id
    Write-Host "Job Type:"$DTJob.JobType
    Write-Host "Source Unique Id:"$DTJob.SourceUniqueId
    Write-Host "Target Unique Id:"$DTJob.TargetUniqueId
 
    ## Log the items we return to prevent returning them again
    $LoggedItems = @{
        HighLevelStatus     = @()
        ActionTitleId       = @()
        ActionMessage       = @()
        LowLevelStates      = @()
        ReplicationProgress = @()
        Percentage          = 0
    }
    
    ## Begin Looping to Monitor the Status Details
    $CanFailover = $False
    while (-not $CanFailover) {
 
        ## Refresh the Job Data
        $DTJob = Get-DtJob -ServiceHost $DTVRA -JobId $DTJob.id
        $HighLevelStatus = $DTJob.Status.HighLevelState.ToString().Trim()
        $LowLevelStatus = $DTJob.Status.ExtendedLowLevelStates
        $Percentage = [math]::Round($DTJob.Status.PermillageComplete / 10)
         
        ## Check for Errors
        if ($DTJob.Status.IsInError) {
            Write-Host "Job is in an error state."
            Throw "Job is in an error state."
        }
         
        ## Report Current Job Status
        if ($HighLevelStatus -notin $LoggedItems.HighLevelStatus) {
            $LoggedItems.HighLevelStatus += $HighLevelStatus
            Write-Host "Status:[ $HighLevelStatus ]"
            Write-Progress -Id 0 -Activity $HighLevelStatus -PercentComplete $Percentage
        }
     
        ## Update the Percentage
        if ($LoggedItems.Percentage -ne $Percentage) {
            $LoggedItems.Percentage = $Percentage
        }
        
        ## Report that Calculation is occuring
        if ($DTJob.Statistics.CoreConnectionDetails.ReplicationSetCalcInProgress) {
            if ("Calculation" -notin $LoggedItems.HighLevelStatus) {
                $LoggedItems.HighLevelStatus += 'Calculation'
                Write-Progress -Id 0 -Activity "Calculating Replication Size Requirements" -PercentComplete $Percentage
            }
        }
        
        ## Report Low Level States
        foreach ($State in $LowLevelStatus) {
            if ($State.MessageId -notin $LoggedItems.LowLevelStates ) {
                $LoggedItems.LowLevelStates += $State.MessageId
                Write-Host $State.MessageId
            }
        }
        
        ## Mirroring Status 
        if ($HighLevelStatus -like 'Mirroring') {
            
            ## Prevent dupilcate reporting
            
            ## Calculate Remaining and Total Size
            $RemainingGB = Convert-Size -From Bytes -To GB -Value ($DTJob.Statistics.CoreConnectionDetails.MirrorBytesRemaining)  
            $TotalGB = Convert-Size -From Bytes -To GB -Value ($DTJob.Statistics.CoreConnectionDetails.MirrorBytesTransmitted + $DTJob.Statistics.CoreConnectionDetails.MirrorBytesRemaining)
            
            $StatusString = [string]$RemainingGB + ' of ' + [string]$TotalGB + ' GB remaining.'
            
            if ($StatusString -notin $LoggedItems.ReplicationProgress) {
                $LoggedItems.ReplicationProgress += $StatusString
                Write-Progress -Id 0 -Activity 'Replication Progress' -PercentComplete $Percentage -Status $StatusString
                Write-Host 'Replication Progress: '$Percentage'% - '$RemainingGB' of '$TotalGB' GB remaining.'
            }
        }
        
        ## Report the Actions already taken
        foreach ($Action in $DTJob.Status.Actions) {
            if ($Action.TitleId -notin $LoggedItems.ActionTitleId ) {
                $LoggedItems.ActionTitleId += $Action.TitleId
                Write-Host $Action.TitleId": "$Action.MessageId
            }
        }

        if ($DTJob.Status.CanFailover -eq $True) {
            $CanFailover = $True
        }
        else {
            Start-Sleep -Seconds 1
        }     
    }
     
    Write-Host $params.DeviceHostname" is ready for failover."
    Write-Progress -Id 0 -Activity ($params.DeviceHostname + " is ready for failover.") -PercentComplete 100 -Completed
}
Invoke-WindowsPowerShell -Params @($params, $DomainAdminCredential) -ScriptBlock $ScriptBlock


