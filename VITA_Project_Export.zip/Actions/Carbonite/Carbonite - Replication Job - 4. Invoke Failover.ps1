<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Replication Job - 4. Invoke Failover 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Invoke Carbonite Job Failover
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Custom Field'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

$ScriptBlock = [scriptblock] { param($params, $DomainAdminCredential)
    
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Progress -Activity "Getting Replication Job" -PercentComplete 20
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $DomainAdminCredential
    Write-Host "Getting Job for :"$params.DeviceHostname
    $DTJob = Get-DtJob -ServiceHost $DTVRA | Where-Object { $_.SourceHostUri -like ("dtms://" + $params.DeviceHostname + "*") }
    if ($null -eq $DTJob) {
        Write-Host "No Job was found on the VRA ["$params.VRA"]"
        Throw ("No Job was found on the VRA [" + $params.VRA + "]")
    }
    
    ## Report the Job, including global ENUMs
    Write-Host "Job Name:"$DTJob.Options.Name
    Write-Host "Job ID:"$DTJob.Id
    Write-Host "Job Type:"$DTJob.JobType
    Write-Host "Source Unique Id:"$DTJob.SourceUniqueId
    Write-Host "Target Unique Id:"$DTJob.TargetUniqueId

    Write-Host "Job Health:" ($DTJob.Status.Health | Out-String )
    Write-Host "Job Status:" ($DTJob.Status.HighLevelState | Out-String )

    
    if (-not $DTJob.Status.CanFailover) {

        Write-Host $params.DeviceHostname"is NOT ready to failover."
        return "Job is not ready to failover"
        
    }
    
    Write-Progress -Activity "Invoking Failover" -PercentComplete 80
    Write-Host "Invoking Failover"
    $RecommendedFailoverOptions = Get-DtUvraRecommendedFailoverOptions -ServiceHost $DTVRA -JobId $DTJob.Id
    Start-DTJobFailover -ServiceHost $DTVRA -JobId $DTJob.Id -FailoverOptions $RecommendedFailoverOptions
    
    ## Report Completion
    Write-Progress -Activity "Failover has begin." -PercentComplete 100 -Completed

    ## Always return an object as JSON in the pipeline so
    ## the Pwsh shell to receive as $ReturnObject = $Result | Select-Object -Last 1
    @{
        RecommendedFailoverOptions = $RecommendedFailoverOptions
        DTJob = $DTJob
    } | ConvertTo-Json -Depth 100 -Compress
} 
Invoke-WindowsPowerShell -Params @($params, $DomainAdminCredential) -ScriptBlock $ScriptBlock


