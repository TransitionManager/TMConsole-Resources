<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Replication Job - 2. Start Job 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Start Carbonite Job
#>

## Parameter Configuration
$Params = @{
	VRA = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-VRA'
		Value			= 'VRA Custom Field'
	}
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

#Action Name = Replication Job - 3. Monitor until Protected
$ScriptBlock = [scriptblock ] { param($params, $DomainAdminCredential)
     
    ## Load Carbonite Replication Module
    Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5
    # Set-Location $params.TmdPsRoot
    # . .\App\Providers\Carbonite.ps1

    ## Import Doubletake Module
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed

    $ErrorActionPreference = 'Continue'
    
    ## Create a Server Object
    Write-Progress -Activity "Creating Server Connections" -PercentComplete 5
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $DomainAdminCredential
    
    Write-Progress -Activity "Getting Replication Job" -PercentComplete 10 -Status ("Getting Job for :" + $params.DeviceHostname)
    $DTJob = Get-DtJob -ServiceHost $DTVRA | Where-Object { $_.SourceHostUri -like ("*" + $params.DeviceHostname + "*") }
    if ($null -eq $DTJob) {
        Write-Host "No Job was found on the VRA ["$params.VRA"]"
        Throw ("No Job was found on the VRA [" + $params.VRA + "]")
    }
 
    ## Report the Job, including global ENUMs
    Write-Host "Starting Job Name:"$DTJob.Options.Name
   
    Write-Host "Job ID:"$DTJob.Id
    Write-Host "Job Type:"$DTJob.JobType
    Write-Host "Source Unique Id:"$DTJob.SourceUniqueId
    Write-Host "Target Unique Id:"$DTJob.TargetUniqueId
 
 	Start-DTJob -ServiceHost $DTVRA -JobId $DTJob.Id
    Write-Progress -Id 0 -Activity "Job Started" -PercentComplete 100 -Completed
    
    ## Return a few objects for the Pwsh shell to receive as $ReturnObject = $Result | Select-Object -Last 1
    return @{
        
    } | ConvertTo-Json -Depth 100 -Compress 
}
Invoke-WindowsPowerShell -Params @($params, $DomainAdminCredential) -ScriptBlock $ScriptBlock


