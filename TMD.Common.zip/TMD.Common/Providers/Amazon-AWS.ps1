
$Global:ProviderSetup = @{

    ProviderName    = 'Amazon AWS'
    StartupMessage  = 'Importing AWSPowerShell Module and Configuration'
    ModulesToImport = @('AWSPowerShell.NetCore')
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration

    }
}
