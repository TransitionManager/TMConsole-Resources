
$Global:ProviderSetup = @{

    ProviderName    = 'Carbonite'
    StartupMessage  = 'Importing Carbonite Module and Configuration'
    ModulesToImport = @()
    StartupScript   = [scriptblock] {
       
        ## Looks up installed DLL
        $InstallPath = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\NSI Software\Double-Take\CurrentVersion' ).InstallPath
        $ConsoleDLL = Join-Path $InstallPath Console DoubleTake.PowerShell.dll
        $ServiceDLL = Join-Path $InstallPath Service DoubleTake.PowerShell.dll
        if (Test-Path $ConsoleDLL) { $DtDLL = $ConsoleDLL }
        elseif (Test-Path $ServiceDLL ) { $DtDLL = $ServiceDLL }
        else { throw 'Double-Take PowerShell module NOT FOUND! Abort!' }

        switch ($PSVersionTable.PSVersion.Major) {
            7 {
                # . Import-Module $DtDLL -UseWindowsPowerShell -Scope Global

                ## Add the DLL path to the Params object.  This will allow the Invoke-Shim to only need to load the single $params object.
                $params | Add-Member -NotePropertyName 'DtDllPath' -NotePropertyValue $DtDLL -Force
                $params | Add-Member -NotePropertyName 'TmdPsRoot' -NotePropertyValue $TmdPsRoot -Force
                if ($Credential) { $params | Add-Member -NotePropertyName 'Credential' -NotePropertyValue ($Credential) -Force }

                ## Handle get-Credential parameters to fetch a local credential from storage.
                $params.PSObject.Properties | Where-Object {
                    $_.Name -like 'get-Credential-*'
                } | ForEach-Object {
            
                    ## Trim the Instruction Prefix from the name, then Get the store credential
                    $CredentialName = $_.Name.Replace('get-Credential-', '')
                    $CredentialObj = Get-StoredCredential -CredentialName $_.value
            
                    ## Add the retrieved credential to the Params object that gets passed around
                    $params | Add-Member -NotePropertyName $CredentialName -NotePropertyValue $CredentialObj -Force
                    $params.PSObject.Properties.Remove($_.Name)
                }
            }
            6 {


                ## Add the DLL path to the Params object.  This will allow the Invoke-Shim to only need to load the single $params object.
                $params | Add-Member -NotePropertyName 'DtDllPath' -NotePropertyValue $DtDLL -Force
                $params | Add-Member -NotePropertyName 'TmdPsRoot' -NotePropertyValue $TmdPsRoot -Force
                if ($Credential) { $params | Add-Member -NotePropertyName 'Credential' -NotePropertyValue ($Credential) -Force }

                ## Handle get-Credential parameters to fetch a local credential from storage.
                $params.PSObject.Properties | Where-Object {
                    $_.Name -like 'get-Credential-*'
                } | ForEach-Object {
            
                    ## Trim the Instruction Prefix from the name, then Get the store credential
                    $CredentialName = $_.Name.Replace('get-Credential-', '')
                    $CredentialObj = Get-StoredCredential -CredentialName $_.value
            
                    ## Add the retrieved credential to the Params object that gets passed around
                    $params | Add-Member -NotePropertyName $CredentialName -NotePropertyValue $CredentialObj -Force
                    $params.PSObject.Properties.Remove($_.Name)
                }
            }


            5 {
                ## Suppress Carbonite's use of Write-Progress Output
                $ProgressPreference = 'SilentlyContinue'
        
                ## Log that the Carbonite Windows Powershell module is being loaded
                Write-Host 'Loading Carbonite Windows PowerShell Module'
                Import-Module -Name $params.DtDllPath
                $ConfirmPreference = 'Low'
        
                ## Resume use of Write-Progress Output
                $ProgressPreference = 'Continue'
            }

            Default {
                $DtHealthStates = @{
                    '0' = 'The health of the job is unknown or not yet determined.'
                    '1' = 'The health of the job is good and data is protected.'
                    '2' = 'The job is taking corrective action. Data may not be protected. You should closely monitor a job in a warning state.'
                    '3' = 'The job has encountered an error that requires user attention. Data is not protected.'
                }

                $DtHighLevelState = @{
                    '0'  = 'The job state is unknown or not yet determined.'
                    '1'  = 'The job is being created.'
                    '2'  = 'The job is being deleted.'
                    '3'  = 'The job has failed back.'
                    '4'  = 'The job has failed over.'
                    '5'  = 'The job is failing back.'
                    '6'  = 'The job is failing over.'
                    '7'  = 'Failover has failed.'
                    '8'  = 'The job has a failover condition met.'
                    '9'  = 'The job is mirroring.'
                    '10' = 'The job requires a mirror to ensure data integrity.'
                    '11' = 'The job is paused.'
                    '12' = 'The job is pausing.'
                    '13' = 'The job is started and protecting.'
                    '14' = 'The job is provisioning resources required to start protection.'
                    '15' = 'The job has completed restoring data.'
                    '16' = 'Restoration has failed.'
                    '17' = 'The job is restoring data but transmission is currently paused.'
                    '18' = 'The job needs to restore data from the target to a new or the original source.'
                    '19' = 'The job is restoring data.'
                    '20' = 'The job is resuming.'
                    '21' = 'The job is reversing roles.'
                    '22' = 'The job is reverting.'
                    '23' = 'The job is starting.'
                    '24' = 'The job is stopped.'
                    '25' = 'The job is stopping.'
                    '26' = 'The job is undoing a failover.'
                    '27' = 'The job is reverting to a previous snapshot.'
                    '28' = 'This property is no longer used.'
                    '29' = 'The job does not have sufficient credentials to operate properly.'
                    '30' = 'The Carbonite replication engine is reporting a licensing warning.'
                    '31' = 'The Carbonite replication engine is reporting a licensing error.'
                    '32' = 'The connection associated with the job is reporting an error, but the threshold for failed communication has not yet been met.'
                    '33' = 'The connection associated with the job is reporting an error, and the threshold for failed communication has been exceeded.'
                    '34' = 'The Management Service on the target cannot communicate with the target replication engine or the Management Service on the source cannot communicate with the source replication engine, but the threshold for failed communication has not yet been met.'
                    '35' = 'The Management Service on the target cannot communicate with the target replication engine or the Management Service on the source cannot communicate with the source replication engine, and the threshold for failed communication has been exceeded.'
                    '36' = 'The Management Service on the target cannot contact the Management Service on the source, but the threshold for failed communication has not yet been met.' 
                    '37' = 'The Management Service on the target cannot contact the Management Service on the source, and the threshold for failed communication has not yet been met.'
                    '38' = 'The controller appliance for an agentless vSphere job cannot communicate with the target.'
                    '39' = 'The job is being edited.'
                }

                $DtActionStatuses = @{
                    '0' = 'Pending: The action has not yet started'
                    '1' = 'Running: The Action is Running'
                    '2' = 'Completed: The action has completed successfully'
                    '3' = 'Cancelled: The action was cancelled.'
                    '4' = 'Faulted: The action encountered an error.'
                }
            }
        }
    }
}