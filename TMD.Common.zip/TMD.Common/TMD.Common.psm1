
## Setup an apropriate quiet environment
$global:InformationPreference = 'Continue'
$global:ProgressPreference = 'Continue'
$global:VerbosePreference = 'SilentlyContinue'
$global:DebugPreference = 'SilentlyContinue'
$global:WarningPreference = 'SilentlyContinue'
$global:ErrorActionPreference = 'Continue' # Using 'Stop' will break execution and not throw errors to the next handler.
$global:ConfirmPreference = 'None'  ## Allows functions that would typically require confirmation to be overridden

## Load the Lib files
Get-ChildItem -Path (Join-Path $PSScriptRoot 'lib') | ForEach-Object { . $_.FullName }

## Store the User's preferred path in the registry
if ($IsWindows) {
	$regKey = Get-ChildItem -Path "HKCU:\Software\" | Where-Object { $_.Name -like '*\TransitionManager' }
        
	if (-not $regKey) {
		## Create a user path
		$global:userFilesRoot = $ENV:HOMEDRIVE + $env:HOMEPATH + '\TMD_Files'
		$global:TmdPsRoot = (Get-Item $PSScriptRoot).Parent.Parent.FullName
		
		New-Item -Path "HKCU:\Software\TransitionManager"
		Set-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "UserFilesRoot" -Value $userFilesRoot
		Set-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "TmdPsRoot" -Value $TmdPsRoot
		Set-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "DebugFolderPath" -Value 'C:\ProgramData\TMD\debug'
		Set-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "SessionManagerInstanceId" -Value '4bcc190b-2c25-4ed9-83db-d026c3d172fc'
	}
 else {
		$global:userFilesRoot = (Get-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "UserFilesRoot").UserFilesRoot
		$global:TmdPsRoot = (Get-ItemProperty -Path "HKCU:\Software\TransitionManager" -Name "TmdPsRoot").TmdPsRoot
	}
	
	

	## Confirm Existence of 
}

## Store the User's preferred path in the registry
if ($IsMacOS) {
	
	## Create a user path
	$global:userFilesRoot = Join-Path $HOME 'TMD_Files'
	$TmdUserConfigFile = Join-Path $userFilesRoot 'config' 'config.json'
	
	# $global:TmdPsRoot = (Get-Item $PSScriptRoot).Parent.Parent.FullName
	$global:TmdPsRoot = (Get-Item '/Users/tbaker/SOURCE/tds/tmd/integrations/PowerShell').FullName
	
	## Read or Create the User config file
	if (Test-Path -Path $TmdUserConfigFile) {
		
		## Read the Config File
		$UserConfig = Get-Content $TmdUserConfigFile | ConvertFrom-Json

	}
	else {
		
		## Create a Default Config file
		$UserConfig = [PSCustomObject]@{
			UserFilesRoot   = $userFilesRoot
			TmdPsRoot       = $TmdPsRoot
			DebugFolderPath = (Join-Path -Path $userFilesRoot 'debug').FullName
		}
	}
}

## Application Paths
$global:appPaths = @{
	providers     = Join-Path $global:TmdPsRoot "App" "Providers"
	modules       = Join-Path $global:TmdPsRoot "App" "Modules"
	scripts       = Join-Path $global:TmdPsRoot "App" "Scripts"
	defaultConfig = Join-Path $global:TmdPsRoot "App" "DefaultConfig"
	winExes       = Join-Path $global:TmdPsRoot "exe"
}

## User Paths
$global:userPaths = @{
	debug       = Join-Path $global:userFilesRoot "Debug"
	queue       = Join-Path $global:userFilesRoot "Queue"
	config      = Join-Path $global:userFilesRoot "Config"
	input       = Join-Path $global:userFilesRoot "Input"
	output      = Join-Path $global:userFilesRoot "Output"
	credentials = Join-Path $global:userFilesRoot "Credentials"
	git         = Join-Path $global:userFilesRoot "Git"
}

## Confirm each user folder exists
$global:userPaths.Values | ForEach-Object {
	Test-FolderPath -FolderPath $_
}

## Write the Configuration to disk
if ($IsMacOS) {
	$UserConfig | ConvertTo-Json | Set-Content -Path $TmdUserConfigFile 
}

## Declare a varaible used within the functions in this module
$CRLF = "`r`n";
