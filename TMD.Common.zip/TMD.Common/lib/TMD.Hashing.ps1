

function Get-StringHash {
    param(
        [CmdletBinding()]
        [Parameter(mandatory = $true, ValueFromPipeline=$true)]
        [String]
        $String
        )

    $md5 = New-Object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider
    $utf8 = New-Object -TypeName System.Text.UTF8Encoding

    return [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($String)))
}

    