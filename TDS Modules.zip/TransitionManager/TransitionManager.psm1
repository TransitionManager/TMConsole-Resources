## Load all files in the lib directory
$LibraryFiles = Get-ChildItem (Join-Path $PSScriptRoot 'lib') -Recurse -Force -File

# For Each $Library File, load it
foreach ($LibraryFile in $LibraryFiles) {
    . ($LibraryFile.FullName)
}