class TMTag {
	[Int]$id

	[String]$name

	[String]$description

	[ValidateSet('Grey', 'Red', 'Orange', 'Yellow', 'Green', 'Blue', 'Cyan', 'Purple', 'Pink', 'White')]
	[String]$color

	static [String[]]$ValidColors = @('Grey', 'Red', 'Orange', 'Yellow', 'Green', 'Blue', 'Cyan', 'Purple', 'Pink', 'White')

	TMTag() {
		$this.color = 'Grey'
	}

	TMTag([String]$_name) {
		$this.name = $_name
		$this.color = 'Grey'
	}

	TMTag([String]$_name, [String]$_description, [String]$_color) {
		$this.name = $_name
		$this.description = $_description
		$this.color = $_color ?? 'Grey'
	}

	TMTag([Int]$_id, [String]$_name, [String]$_description, [String]$_color) {
		$this.id = $_id
		$this.name = $_name
		$this.description = $_description
		$this.color = $_color ?? 'Grey'
	}

	TMTag([Hashtable]$_tagHashtable) {
		$this.id = $_tagHashtable.id ?? $null
		$this.name = $_tagHashtable.name ?? ""
		$this.description = $_tagHashtable.description ?? ""
		$this.color = $_tagHashtable.color ?? 'Grey'
	}

	TMTag([PSCustomObject]$_tagObject) {
		$this.id = $_tagObject.id ?? $null
		$this.name = $_tagObject.name ?? ""
		$this.description = $_tagObject.description ?? ""
		$this.color = $_tagObject.color ?? 'Grey'
	}
}

