class TMProfile {
	[String]$Name

	[String]$Server

	[String]$Project

	[PSCredential]$Credential

	[Bool]$AllowInsecureSSL

	TMProfile() {
		
	}

	TMProfile([String]$_name) {
		$this.Name = $_name
	}

	TMProfile([String]$_name, [String]$_server, [String]$_project = '', [PSCredential]$_credential, [Bool]$_allowInsecureSSL = $false) {
		$this.Name = $_name
		$this.Server = $_server
		$this.Project = $_project
		$this.Credential = $_credential
		$this.AllowInsecureSSL = $_allowInsecureSSL
	}
}
