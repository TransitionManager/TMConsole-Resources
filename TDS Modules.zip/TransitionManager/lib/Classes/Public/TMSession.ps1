class TMSession {
	## A Name parameter to identify the session in other -TMSessions functions
	[String]$Name

	# TM Server hostname
	[String]$TMServer

	# TMVersion drives the selection of compatible APIs to use
	[String]$TMVersion

	# Logged in TM User's Context (indicates loggedin-ness)
	[PSCustomObject]$UserContext

	# TMWebSession Variable. Maintained by the Invoke-WebRequest function's capability
	[Microsoft.PowerShell.Commands.WebRequestSession]$TMWebSession

	## Tracks non-changing items to reduce HTTP lookups, and increase speed of scripts.
	## DataCache is expected to be a k/v pair, where the V could be another k/v pair,
	## However, it's implementation will be more of the nature to hold the list of object calls from the API
	## like 'credentials' = @(@{...},@{...});  'actions' = @(@{...},@{...})
	## Get-TM* functions will cache unless a -NoCache switch is provided
	[Hashtable]$DataCache

	## Should PowerShell ignore the SSL Cert on the TM Server? 
	[Bool]$AllowInsecureSSL

	TMSession() {
		$this.Name = 'Default'
		$this.AllowInsecureSSL = $false
		$this.DataCache = @{}
		$this.UserContext = $null
	}

	TMSession([String]$_name = 'Default') {
		$this.Name = $_name
		$this.AllowInsecureSSL = $false
		$this.DataCache = @{}
		$this.UserContext = $null
	}

	TMSession([String]$_name = 'Default', [String]$_server, [Bool]$_allowInsecureSSL = $false) {
		$this.Name = $_name
		$this.AllowInsecureSSL = $_allowInsecureSSL
		$this.TMServer = $_server
		$this.DataCache = @{}
		$this.UserContext = $null
	}
}