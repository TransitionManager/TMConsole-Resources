## Events
Function Get-TMEvent {
	[OutputType([TMEvent])]
	param(
		[Parameter(Mandatory = $false)][String]$Name,
		[Parameter(Mandatory = $false)][String]$TMSession = 'Default',
		[Parameter(Mandatory = $false)][int]$ProjectId = $global:TMSessions[$TMSession].UserContext.project.id,
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,
		[Parameter(Mandatory = $false)][Switch]$ResetIDs

	)
	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw 'TM Session Not Found.  Use New-TMSession command before using features.'
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')
	
	$uri = 'https://'
	$uri += $instance
	
	## Test if this is a v4.7 or V5. version of TM
	if (($Global:TMSessions[$TMSession].TMVersion -like '5.*') -or ($Global:TMSessions[$TMSession].TMVersion -like '4.7*')) {
		
		$uri += '/tdstm/ws/moveEvent/list'
		try {
			$response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
		}
		catch {
			return $_
		}
		if ($response.StatusCode -ne 200) {
			throw ('There was an error retriving the event list.' + $_.Exception.Message)
		}
		
		## Convert the results
		$Result = ($response.Content | ConvertFrom-Json).data

	}
	else {
		
		## Older TM Version Handling
		$uri += '/tdstm/moveEvent/listJson'

		try {
			$response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
		}
		catch {
			return $_
		}

		if ($response.StatusCode -eq 200) {
			$Result = ($response.Content | ConvertFrom-Json).rows
		
			## Unwrap the 'cell' node
			for ($i = 0; $i -lt $Result.Count; $i++) {
				$Result[$i] = @{
					id            = $Result[$i].id
					name          = $Result[$i].cell[0]
					estStart      = $Result[$i].cell[1]
					estCompletion = $Result[$i].cell[2]
					description   = $Result[$i].cell[3]
					bundles       = $Result[$i].cell[6]
				}
			}
		}
		else {
			return 'Unable to collect Events.'
		}
	
		if ($ResetIDs) {
			for ($i = 0; $i -lt $Result.Count; $i++) {
				$Result[$i].id = $null
			}
		}
	}

	## Return appropriate results
	if ($Name) {
		
		[TMEvent]::new(($Result | Where-Object { $_.name -eq $Name }))
			
	}
	else {

		$Result | ForEach-Object { [TMEvent]::new($_) }
	}
}

function New-TMEvent {
	<#
    .SYNOPSIS
    Creates a new Event in TransitionManager
    
    .DESCRIPTION
    This function creates a new Event in TransitionManager
    
    .PARAMETER InputObject
    The Event to create.
	
    .PARAMETER Name
    The name for the Event
    
	.PARAMETER Description
    The description for the Event
	
	.EXAMPLE
    New-TMEvent -Name 'New Event #5'
    
    .EXAMPLE
    New-TMEvent -InputObject @{name = 'Event name'; description = 'Event Description'}
    
    .EXAMPLE
    [TMEvent]::new('First Event') | New-TMEvent -Passthru
    
    
    .OUTPUTS
    This command does not provide output.
    #>

	[CmdletBinding(DefaultParameterSetName = 'ByProperties')]
	[OutputType([TMEvent])]
	param(
		[Parameter(Mandatory = $true,
			Position = 0,
			ValueFromPipeline = $true,
			ParameterSetName = 'ByObject')]
		[TMEvent]
		$InputObject,
		
		[Parameter(Mandatory = $false,
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ByProperties')]
		[String]$Name,
		
		[Parameter(Mandatory = $false,
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ByProperties')]
		[String]$Description,

		[Parameter(Mandatory = $false)][String]$TMSession = 'Default',
		[Parameter(Mandatory = $false)][int]$ProjectId = $global:TMSessions[$TMSession].UserContext.project.id,
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,
		
		[Parameter(Mandatory = $false)][Switch]$PassThru
	)

	begin {

		## Get Session Configuration
		$TMSessionConfig = $global:TMSessions[$TMSession]
		if (-not $TMSessionConfig) {
			Write-Host 'TMSession: [' -NoNewline
			Write-Host $TMSession -ForegroundColor Cyan
			Write-Host '] was not Found. Please use the New-TMSession command.'
			Throw 'TM Session Not Found.  Use New-TMSession command before using features.'
		}

		#Honor SSL Settings
		if ($TMSessionConfig.AllowInsecureSSL) {
			$TMCertSettings = @{SkipCertificateCheck = $true }
		}
		else { 
			$TMCertSettings = @{SkipCertificateCheck = $false }
		}

	
		$instance = $Server.Replace('/tdstm', '')
		$instance = $instance.Replace('https://', '')
		$instance = $instance.Replace('http://', '')
	
		$uri = 'https://'
		$uri += $instance + '/tdstm/ws/moveEvent/save/null'
	}

	process {
		Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

		## Handle the Parameter Creation based on the set
		$TMEvent = $PSCmdlet.ParameterSetName -eq 'ByProperties' ? [TMEvent]::new($Name, $Description) : $InputObject
		
		## Write the new Event that will be created
		Write-Verbose ($TMEvent | ConvertTo-Json)

		## Update the Content Type to JSON
		Set-TMHeaderContentType -ContentType 'JSON'

		## Check for an existing Event
		$CheckEvent = Get-TMEvent -Name $TMEvent.name
		if ($CheckEvent -and $Passthru) {
			return $CheckEvent
		}
		
		## Create a Request Splat
		$WebRequestSplat = @{
			Method     = 'POST'
			Uri        = $uri
			WebSession = $TMSessionConfig.TMWebSession
			Body       = ($TMEvent | ConvertTo-Json) 
		}

		try {
			$response = Invoke-WebRequest @WebRequestSplat @TMCertSettings
			if ($response.StatusCode -eq 200 ) {
				$ResponseContent = $response.content | ConvertFrom-Json
				if ($ResponseContent.status -ne 'success') {
					Write-Error -Message $ResponseContent.errors[0]
					return
				}
				else {

					## The Object was returned, pass it through to 
					if ($PassThru) {
						return [TMEvent]::new($ResponseContent.data)
					}
					else { return }
				}
			}
			elseif ($response.StatusCode -eq 204) {
				return (Get-TMEvent -Name $TMEvent.name)
			}
			else {
				throw 'Unable to Create Event'
			}
		}
		catch {
			throw $_
		}
	}

	end {
	}
}
