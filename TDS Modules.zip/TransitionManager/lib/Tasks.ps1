

## Tasks
Function Get-TMTasks {
	[CmdletBinding(DefaultParameterSetName = 'TaskId')]
	param(
		[Parameter(Mandatory = $false, ParameterSetName = 'TaskId')][Int]$Id,
		[Parameter(Mandatory = $false, ParameterSetName = 'EventName')][String]$EventName,
		[Parameter(Mandatory = $false, ParameterSetName = 'EventId')][Int]$EventId,
		[Parameter(Mandatory = $false)][Switch]$JustMine = $false,
		[Parameter(Mandatory = $false)][Switch]$JustActionalble = $false,
		[Parameter(Mandatory = $false)][String]$ProjectName,
		[Parameter(Mandatory = $false)][Int]$ProjectId,
		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL
	)

	Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	# Write-Host "Getting TM Tasks - Just Mine: " $JustMine ", Just Actionable: " $JustActionalble
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')
	
	## Construct a URL to get the single task
	if ($Id) {
		$uri = "https://"
		$uri += $instance
		$uri += '/tdstm/assetEntity/showComment?id='
		$uri += $Id
	} 

	## Construct a URL to get many tasks
	else {

		
		$uri = "https://"
		$uri += $instance
		$uri += '/tdstm/ws/task'
		
		if ($JustMine) { $justMyTasks = 1 } else { $justMyTasks = 0 }
		$uri += '?justMyTasks=' + $justMyTasks
		
		if ($JustActionalble) { $vJustActionalble = 1 } else { $vJustActionalble = 0 }
		$uri += '&justActionable=' + $vJustActionalble
		
		## Resolve the Project and Event ID
		if ($PSCmdlet.ParameterSetName -eq 'EventName') {
			$EventId = Get-TMEvent -Name $EventName | Select-Object -ExpandProperty id
		}
	
		## Append the Event ID if there is one
		if ($EventId) {
			$uri += '&moveEvent=' + $EventId
		}
		## Resolve the Project and Event ID
		if ($PSCmdlet.ParameterSetName -eq 'ProjectName') {
			$ProjectId = Get-TMProject -Name $ProjectName | Select-Object -ExpandProperty id
		}
	
		## Append the Project ID if there is one
		if ($ProjectId) {
			$uri += '&project=' + $ProjectId
		}
	}
	
	try {
		$Response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
	}
	catch {
		return $_
	}

	if ($Response.StatusCode -eq 200) {
		$ContentJson = $Response.Content | ConvertFrom-Json
		
		## Return the single unwrapped object
		if ($Id) {
			$ContentJson
			
		}

		## Otherwise return the Data Node
		else {
			$ContentJson.data

		}
	}
}

Function Set-TMTask {
	param(
		[Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)][PsCustomObject]$InputObject,

		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL
	)

	
	Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	# Write-Host "Getting TM Tasks - Just Mine: " $JustMine ", Just Actionable: " $JustActionalble
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')

	# API
	$uri = 'https://'
	$uri += $instance
	$uri += "/tdstm/assetEntity/updateComment"
	
	$PostBody = @{
		id          = $InputObject.id
		taskNumber  = $InputObject.taskNumber
		comment     = $InputObject.title
		status      = $InputObject.status

		## Good to here
		apiAction   = $InputObject.action
		apiActionId = $InputObject.action.toString()
		# assignedTo = $InputObject.assignedTo.id
		# team = $InputObject.team

	} | ConvertTo-Json -Compress

	## Invoke the HTTP Request and handle the response
	try {
		# Perform actual web request
		$Response = Invoke-WebRequest -Method Post -Uri $uri -WebSession $TMSessionConfig.TMWebSession -Body $PostBody @TMCertSettings
		if ($Response.StatusCode -eq 200) {
			$ResponseJson = $response.Content | ConvertFrom-Json -Depth 100
			
			## Handle v4 singular Error object
			if ($Null -ne $ResponseJson.error) {
				throw $ResponseJson.error
			}
			
			## Handle v5 status = error with plural Errors property
			if ($ResponseJson.status.toString() -eq 'error') {
				throw $ResponseJson.errors
			}
		}

		## TM 5.0+ returns a 204 (OK, but no content)
		elseif ($Response.StatusCode -eq 204) {
			return
		}
		else { 
			Throw ('Error while setting task to ' + $State) 
		}
			
	}
	catch {
		throw $_
	}
}
Function Set-TMTaskStatus {
	[CmdletBinding(DefaultParameterSetName = 'TaskId')]
	param(
		[Parameter(Mandatory = $false, ParameterSetName = 'TaskId')][Int]$Id,
		[Parameter(Mandatory = $true)]
		[ValidateSet('Planned', 'Pending', 'Ready', 'Started', 'Completed', 'Hold')]
		[String]$State,

		[Parameter(Mandatory = $false)]
		[ValidateRange(0, 100)]
		[int]$Progress,

		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,

		## Extra Features / Data Values
		[Parameter(Mandatory = $false)][String]$Message,
	
	
		[Parameter(Mandatory = $false)][String]$Stdout,
		[Parameter(Mandatory = $false)][String]$Stderr,
		[Parameter(Mandatory = $false)][PSObject]$Data,
		[Parameter(Mandatory = $false)][String]$DataFile
	)

	
	Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	# Write-Host "Getting TM Tasks - Just Mine: " $JustMine ", Just Actionable: " $JustActionalble
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')

	# API
	$uri = 'https://'
	$uri += $instance
	$uri += "/tdstm/assetEntity/updateComment"
	
	$PostBody = @{
		id     = $Id
		status = $State
	} | ConvertTo-Json -Compress

	## Invoke the HTTP Request and handle the response
	try {
		# Perform actual web request
		$Response = Invoke-WebRequest -Method Post -Uri $uri -WebSession $TMSessionConfig.TMWebSession -Body $PostBody @TMCertSettings
		if ($Response.StatusCode -eq 200) {
			$ResponseJson = $response.Content | ConvertFrom-Json -Depth 100
	
			if ($ResponseJson.status -eq 'error') {
				throw $ResponseJson.errors
			}
		}

		## TM 5.0+ returns a 204 (OK, but no content)
		elseif ($Response.StatusCode -eq 204) {
			return
		}
		else { 
			Throw ('Error while setting task to ' + $State) 
		}
			
	}
 catch {
		throw $_
	}
}