
$Global:ProviderSetup = @{

    ProviderName    = 'VMware vCenter'
    StartupMessage  = 'Importing VMware vCenter Module and Configuration'
    ModulesToImport = @('VMware.VimAutomation.Core')
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration
     

    }
}

