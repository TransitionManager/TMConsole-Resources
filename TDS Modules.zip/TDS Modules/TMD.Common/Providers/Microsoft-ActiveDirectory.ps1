
$Global:ProviderSetup = @{

    ProviderName         = 'Microsoft Active Directory'
    StartupMessage       = 'Importing Active Directory Module and Configuration'
    ModulesToImport      = @()
    WinPSModulesToImport = @('ActiveDirectory')
    StartupScript        = [scriptblock] {
        
        <#

            ## Overview ## 
            Each of the Optimize-VMPowerCLIData functions require a Parameter containg 
        a configuration map. The following maps define a configuration template 
        you can copy to your 'TMD_Files\Config\VMware-vCenter.ps1' file if 
        you wish to make changes.  Config Map in that file override the default 
        configuration deployed with the TMD VMware vCenter Provider Package.

            The intent is to expose a configuration file location where a user can edit
        each these functions without disrupting the TMD Application code.

        ## ScriptBlock / ProcessingMaps
            Consider each of the below ScriptBlocks as a processing map. They are
        are executed inside of a loop, once for each asset when the object is being Optimized
        within the Optimize-VMPowerCLIData functions.
            
            Each Itteration of the script block exposes an $Item (One for each in the $Data
        parameter).  The usage of the Optimize-VMPowerCLIData command is to provide a configuration
        map, where each $Item results in an output of an object.  The $Item.{properties} can be mapped
        to a PSObject or HashTable object per the following example:
        
        ######################################################
            [scriptblock]$ADMaps.Datacenter = {
                return @{
                    
                    ## Basic Asset Details
                    id             = $Item.Id
                    name           = $Item.Name

                    
                    ## Asset Class Details
                    assetDetails   = @{
                        datastore = $Item.ExtensionData.Datastore
                    }
                    
                    ## Asset's Environment Resources
                    assetResources = @{
                        items = $Item.ExtensionData.items
                    }
                }
            }
        ######################################################

        Tip:  Convenient way to identify the $Item properties:
        $Item.PSObject.Properties | Select-Object Name, Value | Clip

        #>

        ## Define the Map objects
        $ADMaps = @{}

        ##
        ##  Active Directory Processing Maps
        ##


        ## Get-ADDomain
        [scriptblock]$ADMaps.ADDomain = {
            return [PSCustomObject] @{
                AllowedDNSSuffixes                 = $Item.AllowedDNSSuffixes.Value
                ChildDomains                       = $Item.ChildDomains.Value
                ComputersContainer                 = $Item.ComputersContainer
                DeletedObjectsContainer            = $Item.DeletedObjectsContainer
                DistinguishedName                  = $Item.DistinguishedName
                DNSRoot                            = $Item.DNSRoot
                DomainControllersContainer         = $Item.DomainControllersContainer
                DomainMode                         = $Item.DomainMode
                DomainSID                          = $Item.DomainSID.Value
                ForeignSecurityPrincipalsContainer = $Item.ForeignSecurityPrincipalsContainer
                Forest                             = $Item.Forest
                InfrastructureMaster               = $Item.InfrastructureMaster
                LastLogonReplicationInterval       = $Item.LastLogonReplicationInterval
                LinkedGroupPolicyObjects           = $Item.LinkedGroupPolicyObjects
                LostAndFoundContainer              = $Item.LostAndFoundContainer
                ManagedBy                          = $Item.ManagedBy
                Name                               = $Item.Name
                NetBIOSName                        = $Item.NetBIOSName
                ObjectClass                        = $Item.ObjectClass
                ObjectGUID                         = $Item.ObjectGUID
                ParentDomain                       = $Item.ParentDomain
                PDCEmulator                        = $Item.PDCEmulator
                PublicKeyRequiredPasswordRolling   = $Item.PublicKeyRequiredPasswordRolling
                QuotasContainer                    = $Item.QuotasContainer
                ReadOnlyReplicaDirectoryServers    = $Item.ReadOnlyReplicaDirectoryServers.Value
                ReplicaDirectoryServers            = $Item.ReplicaDirectoryServers.Value
                RIDMaster                          = $Item.RIDMaster
                SubordinateReferences              = $Item.SubordinateReferences
                SystemsContainer                   = $Item.SystemsContainer
                UsersContainer                     = $Item.UsersContainer
            }
        }


        ##  Get-ADForest
        [scriptblock]$ADMaps.ADForest = {
            return [PSCustomObject] @{
                ApplicationPartitions = $Item.ApplicationPartitions
                CrossForestReferences = $Item.CrossForestReferences
                DomainNamingMaster    = $Item.DomainNamingMaster
                Domains               = $Item.Domains
                ForestMode            = $Item.ForestMode
                GlobalCatalogs        = $Item.GlobalCatalogs
                Name                  = $Item.Name
                PartitionsContainer   = $Item.PartitionsContainer
                RootDomain            = $Item.RootDomain
                SchemaMaster          = $Item.SchemaMaster
                Sites                 = $Item.Sites
                SPNSuffixes           = $Item.SPNSuffixes
                UPNSuffixes           = $Item.UPNSuffixes
            }
        }


        ##  Get-ADDomainController
        [scriptblock]$ADMaps.ADDomainController = {
            return [PSCustomObject] @{
                ComputerObjectDN           = $Item.ComputerObjectDN
                DefaultPartition           = $Item.DefaultPartition
                Domain                     = $Item.Domain
                Enabled                    = $Item.Enabled
                Forest                     = $Item.Forest
                HostName                   = $Item.HostName
                InvocationId               = $Item.InvocationId
                IPv4Address                = $Item.IPv4Address
                IPv6Address                = $Item.IPv6Address
                IsGlobalCatalog            = $Item.IsGlobalCatalog
                IsReadOnly                 = $Item.IsReadOnly
                LdapPort                   = $Item.LdapPort
                Name                       = $Item.Name
                NTDSSettingsObjectDN       = $Item.NTDSSettingsObjectDN
                OperatingSystem            = $Item.OperatingSystem
                OperatingSystemHotfix      = $Item.OperatingSystemHotfix
                OperatingSystemServicePack = $Item.OperatingSystemServicePack
                OperatingSystemVersion     = $Item.OperatingSystemVersion
                OperationMasterRoles       = $Item.OperationMasterRoles
                Partitions                 = $Item.Partitions
                PSShowComputerName         = $Item.PSShowComputerName
                ServerObjectDN             = $Item.ServerObjectDN
                ServerObjectGuid           = $Item.ServerObjectGuid
                Site                       = $Item.Site
                SslPort                    = $Item.SslPort

            }
        }


        ##  Get-ADComputer
        [scriptblock]$ADMaps.ADComputer = {
            return [PSCustomObject] @{

                ## Basic Asset Details
                id                         = $Item.Sid.Value
                name                       = $Item.Name
                Description                = $Item.Description

                ## AD Computer Object Details
                Enabled                    = $Item.Enabled
                InstanceType               = $Item.InstanceType
                DistinguishedName          = $Item.DistinguishedName
                SamAccountName             = $Item.SamAccountName
                ObjectCategory             = $Item.ObjectCategory
                ObjectClass                = $Item.ObjectClass
                ObjectGuid                 = $Item.ObjectGuid.Guid
                Location                   = $Item.Location
                ManagedBy                  = $Item.ManagedBy

                ## System Details
                OperatingSystem            = $Item.OperatingSystem
                OperatingSystemHotfix      = $Item.OperatingSystemHotfix
                OperatingSystemServicePack = $Item.OperatingSystemServicePack
                OperatingSystemVersion     = $Item.OperatingSystemVersion
        
                ## Network Details
                DNSHostName                = $Item.DNSHostName
                IPv4Address                = $Item.IPv4Address

                ## Usage and Memberships
                LastLogonTimestamp         = $Item.lastLogonTimestamp
                MemberOf                   = $Item.MemberOf
                PrimaryGroup               = $Item.PrimaryGroup
            }
        }


        ##  Get-ADGroup
        [scriptblock]$ADMaps.ADGroup = {
            return [PSCustomObject] @{
                adminCount                      = $Item.adminCount
                CanonicalName                   = $Item.CanonicalName
                CN                              = $Item.CN
                Created                         = $Item.Created
                createTimeStamp                 = $Item.createTimeStamp
                Deleted                         = $Item.Deleted
                Description                     = $Item.Description
                DisplayName                     = $Item.DisplayName
                DistinguishedName               = $Item.DistinguishedName
                dSCorePropagationData           = $Item.dSCorePropagationData
                GroupCategory                   = $Item.GroupCategory
                GroupScope                      = $Item.GroupScope
                groupType                       = $Item.groupType
                HomePage                        = $Item.HomePage
                instanceType                    = $Item.instanceType
                isCriticalSystemObject          = $Item.isCriticalSystemObject
                isDeleted                       = $Item.isDeleted
                LastKnownParent                 = $Item.LastKnownParent
                ManagedBy                       = $Item.ManagedBy
                member                          = $Item.member
                MemberOf                        = $Item.MemberOf
                Members                         = $Item.Members
                Modified                        = $Item.Modified
                modifyTimeStamp                 = $Item.modifyTimeStamp
                Name                            = $Item.Name
                ObjectCategory                  = $Item.ObjectCategory
                ObjectClass                     = $Item.ObjectClass
                ObjectGUID                      = $Item.ObjectGUID
                objectSid                       = $Item.objectSid.Value
                ProtectedFromAccidentalDeletion = $Item.ProtectedFromAccidentalDeletion
                SamAccountName                  = $Item.SamAccountName
                sAMAccountType                  = $Item.sAMAccountType
                sDRightsEffective               = $Item.sDRightsEffective
                SID                             = $Item.SID.Value
                SIDHistory                      = $Item.SIDHistory
                systemFlags                     = $Item.systemFlags
                uSNChanged                      = $Item.uSNChanged
                uSNCreated                      = $Item.uSNCreated
                whenChanged                     = $Item.whenChanged
                whenCreated                     = $Item.whenCreated
            }
        }


        ##  Get-ADGroupMember
        [scriptblock]$ADMaps.ADGroupMember = {
            return [PSCustomObject] @{
                distinguishedName = $Item.distinguishedName
                name              = $Item.name
                objectClass       = $Item.objectClass
                objectGUID        = $Item.objectGUID
                SamAccountName    = $Item.SamAccountName
                SID               = $Item.SID.Value
        
            }
        }


        ##  Get-ADUser
        [scriptblock]$ADMaps.ADUser = {
            return [PSCustomObject] @{
                AccountExpirationDate                = $Item.AccountExpirationDate
                accountExpires                       = $Item.accountExpires
                AccountLockoutTime                   = $Item.AccountLockoutTime
                AccountNotDelegated                  = $Item.AccountNotDelegated
                adminCount                           = $Item.adminCount
                AllowReversiblePasswordEncryption    = $Item.AllowReversiblePasswordEncryption
                AuthenticationPolicy                 = $Item.AuthenticationPolicy
                AuthenticationPolicySilo             = $Item.AuthenticationPolicySilo
                BadLogonCount                        = $Item.BadLogonCount
                badPasswordTime                      = $Item.badPasswordTime
                badPwdCount                          = $Item.badPwdCount
                CannotChangePassword                 = $Item.CannotChangePassword
                CanonicalName                        = $Item.CanonicalName
                Certificates                         = $Item.Certificates
                City                                 = $Item.City
                CN                                   = $Item.CN
                codePage                             = $Item.codePage
                Company                              = $Item.Company
                CompoundIdentitySupported            = $Item.CompoundIdentitySupported
                Country                              = $Item.Country
                countryCode                          = $Item.countryCode
                Created                              = $Item.Created
                createTimeStamp                      = $Item.createTimeStamp
                Deleted                              = $Item.Deleted
                Department                           = $Item.Department
                Description                          = $Item.Description
                DisplayName                          = $Item.DisplayName
                DistinguishedName                    = $Item.DistinguishedName
                Division                             = $Item.Division
                DoesNotRequirePreAuth                = $Item.DoesNotRequirePreAuth
                dSCorePropagationData                = $Item.dSCorePropagationData
                EmailAddress                         = $Item.EmailAddress
                EmployeeID                           = $Item.EmployeeID
                EmployeeNumber                       = $Item.EmployeeNumber
                Enabled                              = $Item.Enabled
                Fax                                  = $Item.Fax
                GivenName                            = $Item.GivenName
                HomeDirectory                        = $Item.HomeDirectory
                HomedirRequired                      = $Item.HomedirRequired
                HomeDrive                            = $Item.HomeDrive
                HomePage                             = $Item.HomePage
                HomePhone                            = $Item.HomePhone
                Initials                             = $Item.Initials
                instanceType                         = $Item.instanceType
                isCriticalSystemObject               = $Item.isCriticalSystemObject
                isDeleted                            = $Item.isDeleted
                KerberosEncryptionType               = $Item.KerberosEncryptionType
                LastBadPasswordAttempt               = $Item.LastBadPasswordAttempt
                LastKnownParent                      = $Item.LastKnownParent
                lastLogoff                           = $Item.lastLogoff
                lastLogon                            = $Item.lastLogon
                LastLogonDate                        = $Item.LastLogonDate
                lastLogonTimestamp                   = $Item.lastLogonTimestamp
                LockedOut                            = $Item.LockedOut
                lockoutTime                          = $Item.lockoutTime
                logonCount                           = $Item.logonCount
                logonHours                           = $Item.logonHours
                LogonWorkstations                    = $Item.LogonWorkstations
                Manager                              = $Item.Manager
                MemberOf                             = $Item.MemberOf
                MNSLogonAccount                      = $Item.MNSLogonAccount
                MobilePhone                          = $Item.MobilePhone
                Modified                             = $Item.Modified
                modifyTimeStamp                      = $Item.modifyTimeStamp
                'msDS-SupportedEncryptionTypes'      = $Item.'msDS-SupportedEncryptionTypes'
                'msDS-User-Account-Control-Computed' = $Item.'msDS-User-Account-Control-Computed'
                Name                                 = $Item.Name
                ObjectCategory                       = $Item.ObjectCategory
                ObjectClass                          = $Item.ObjectClass
                ObjectGUID                           = $Item.ObjectGUID
                objectSid                            = $Item.objectSid.Value
                Office                               = $Item.Office
                OfficePhone                          = $Item.OfficePhone
                Organization                         = $Item.Organization
                OtherName                            = $Item.OtherName
                PasswordExpired                      = $Item.PasswordExpired
                PasswordLastSet                      = $Item.PasswordLastSet
                PasswordNeverExpires                 = $Item.PasswordNeverExpires
                PasswordNotRequired                  = $Item.PasswordNotRequired
                POBox                                = $Item.POBox
                PostalCode                           = $Item.PostalCode
                PrimaryGroup                         = $Item.PrimaryGroup
                primaryGroupID                       = $Item.primaryGroupID
                PrincipalsAllowedToDelegateToAccount = $Item.PrincipalsAllowedToDelegateToAccount
                ProfilePath                          = $Item.ProfilePath
                ProtectedFromAccidentalDeletion      = $Item.ProtectedFromAccidentalDeletion
                pwdLastSet                           = $Item.pwdLastSet
                SamAccountName                       = $Item.SamAccountName
                sAMAccountType                       = $Item.sAMAccountType
                ScriptPath                           = $Item.ScriptPath
                sDRightsEffective                    = $Item.sDRightsEffective
                ServicePrincipalNames                = $Item.ServicePrincipalNames
                SID                                  = $Item.SID.Value
                SIDHistory                           = $Item.SIDHistory
                SmartcardLogonRequired               = $Item.SmartcardLogonRequired
                State                                = $Item.State
                StreetAddress                        = $Item.StreetAddress
                Surname                              = $Item.Surname
                Title                                = $Item.Title
                TrustedForDelegation                 = $Item.TrustedForDelegation
                TrustedToAuthForDelegation           = $Item.TrustedToAuthForDelegation
                UseDESKeyOnly                        = $Item.UseDESKeyOnly
                userAccountControl                   = $Item.userAccountControl
                userCertificate                      = $Item.userCertificate
                UserPrincipalName                    = $Item.UserPrincipalName
                uSNChanged                           = $Item.uSNChanged
                uSNCreated                           = $Item.uSNCreated
                whenChanged                          = $Item.whenChanged
                whenCreated                          = $Item.whenCreated
            }
        }



        ## Publish the Maps as a Global Scope Variable
        $global:ADMaps = $ADMaps




    }
}
