

$Global:ProviderSetup = @{

    ProviderName    = 'ServiceNow'
    StartupMessage  = 'Importing ServiceNow Module and Configuration'
    ModulesToImport = @()
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration

    }
}

