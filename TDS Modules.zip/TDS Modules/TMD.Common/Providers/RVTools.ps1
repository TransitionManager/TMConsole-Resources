

$Global:ProviderSetup = @{

    ProviderName    = 'RVTools'
    StartupMessage  = 'Importing RVTools Module and Configuration'
    ModulesToImport = @()
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration

    }
}

