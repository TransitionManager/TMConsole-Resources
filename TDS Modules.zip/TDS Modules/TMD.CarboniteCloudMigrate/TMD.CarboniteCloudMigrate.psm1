#
# Double-Take Orchestrator PowerShell module
#

$global:DtLogins = @{}
$global:DtCurrentLoginKey = $null
$global:DtDefaultHostName = "migrateapi.doubletake.com"
$global:DtDefaultScheme = "https"
$global:DtDefaultEncryptedEBS = $False

# Add-Type @"
# 	using System.Net;
# 	using System.Security.Cryptography.X509Certificates;
# 	public class TrustAllCertsPolicy : ICertificatePolicy {
# 		public bool CheckValidationResult(
# 			ServicePoint srvPoint, X509Certificate certificate,
# 			WebRequest request, int certificateProblem) {
# 			return true;
# 		}
# 	}
# "@
# [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy



## Load the Library Powershell files
Get-ChildItem -Path (Join-Path $PSScriptRoot 'lib') | ForEach-Object { . $_.FullName }


#
# Double-Take CMC Common Migrations Helper PowerShell module
#


# Function that adds a proxy to an environment
function AddProxy
{
    [CmdletBinding()]
    Param (
        # Name of the proxy to add
        [Parameter(Mandatory = $true)]
        [string]$proxyName,
        
        # Environment to add the proxy too
        [Parameter(Mandatory = $true)]
        [object]$environment        
    )

    Process
    {
        # Get the proxy
        $proxy = Get-DtoProxy | Where-Object {$_.Name -eq $proxyName}

        if ([string]::IsNullOrEmpty($proxy))
        {
            throw [string]::Format("Proxy $proxyName was not found! The proxy was not added to the environment {0}.", $environment.name)
        }

        # Add the proxy to the environment
        $environment | Add-Member -MemberType NoteProperty -Name proxyId -Value $proxy.Id
        Edit-DtoEnvironment -Environment $environment
    }
}

# Function that checks and waits for a discovery to complete
function CheckDiscoveryTask
{
    [CmdletBinding()]
    Param (
        # Discovery Task Id
        [Parameter(Mandatory = $true)]
        [string]$discoveryTaskId,
        
        # Max number of time to check if the discovery completed
        [Parameter(Mandatory = $true)]
        [int]$maxCount,
        
        # Sleep time between each check
        [Parameter(Mandatory = $true)]
        [int]$sleepTime        
    )

    Process
    {    
        $discoveryTaskStatus = "pending"
        for ($i=1; $i -le $maxCount; $i++)
        {        
            $discoveryTask = Get-DtoDiscoveryTask -TaskId $discoveryTaskId
            $discoveryTaskStatus = $discoveryTask.status
        
            if ($discoveryTaskStatus -eq "completed")
            {            
                Write-Host "Discovery completed successfully!"
                break
            }

            if ($discoveryTaskStatus -eq "faulted")
            {            
                throw "The discovery process completed with error: $discoveryTask.errorMessage"
            }        

            Write-Host "Discovery is still running... Waiting $sleepTime seconds to get the updated status... Attempt $i of $maxCount"  
            Start-Sleep -Seconds $sleepTime
        }

        if ($discoveryTaskStatus -ne "completed")
        {
            throw "Discovery did not complete successfully!"
        }
    }    
}

# Function that creates a credential object
function CreateCredentialObject
{
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$True)]
        [string]$userName,
       
        [Parameter(Mandatory=$True)]
        [string]$password      
    )

    Process
    {    
        $securePassword = $password | ConvertTo-SecureString -AsPlainText -Force
        $credentialObject = New-Object PSCredential($userName, $securePassword)
        return $credentialObject
    }    
}


# Function that searches for and returns a server. Searches X amount of times and throws if it can not find the server
function GetServer
{
    [CmdletBinding()]
    Param (
        # Server name to get
        [Parameter(Mandatory=$True)]
        [string]$serverName,

        # VM Service Name
        [Parameter(Mandatory = $false)]
        [string]$vmServiceName,
    
        # Environment ID the server is in
        [Parameter(Mandatory=$True)]
        [string]$environmentId,
        
        # Max number of time to check for the server
        [Parameter(Mandatory = $true)]
        [int]$maxCount,
        
        # Sleep time between each check
        [Parameter(Mandatory = $true)]
        [int]$sleepTime             
    )

    Process
    {
        Write-Host "Getting server ID for server $serverName..."
        for ($i=1; $i -le $maxCount; $i++)
        {
            # Get server
            if ($vmServiceName)
            {
                $server = Get-DtoServer | Where-Object {$_.vmName -eq $serverName -and $_.environmentId -eq $environmentId -and $_.vmServiceName -eq $vmServiceName}
            }
            else
            {
                $server = Get-DtoServer | Where-Object {$_.vmName -eq $serverName -and $_.environmentId -eq $environmentId}
            }

            if (![string]::IsNullOrEmpty($server))
            {    
                if ($server.status -ne "pending" -and $server.status -ne "aquiringSystemInfo" -and $server.status -ne "discovered")
                {
                    break    
                }
            }
            
            Write-Host "Server $serverName not found!... Trying again in $sleepTime seconds... Attempt $i of $maxCount"
            Start-Sleep -Seconds $sleepTime
        }

        if ([string]::IsNullOrEmpty($server))
        {
            throw "Server $serverName was not found"            
        }
        if ($server.status -ne "readyToMigrate")
        {
            throw "Server $serverName is in state " + $server.status + ". It is not ready to migrate."
        }

        Write-Host "Server ID found!"
        return $server
    }    
}

# Function that starts a migration
function StartMigration
{
    [CmdletBinding()]
    Param (   
        # Target environment ID
        [Parameter(Mandatory=$True)]
        [string]$targetEnvId,

        # Target location: virtual network, virtual datacenter,  or region
        [Parameter()]
        [string]$targetLocation,
          
        # Target Key Pair: Used only for Amazon target envirnonment.
	    # This key pair will be used to create Vm, if do not wish to 
	    # associate any key pair, pass 'No Key Pair' or $null
        [Parameter()]
        [string]$AwsKeyPair,

        # Resource Group Name: Used only for AzureMH target envirnonment.
        [Parameter(Mandatory=$False)]
        [string]$ResourceGroupName,

        # Migrate Project Name: Used only for AzureMH target envirnonment.
        [Parameter(Mandatory=$False)]
        [string]$AMHProjectName,

        # Migrate Project Solution Name: Used only for AzureMH target envirnonment.
        [Parameter(Mandatory=$False)]
        [string]$AMHProjectsolutionName,

        [Parameter()]
        [ValidateSet($False,$True, 0, 1)]
        [string]$encryptedEBS,

        [Parameter()]
        [string]$targetNetwork,
        
        # Target admin credential object
        [Parameter(Mandatory = $true)]
        [object]$adminCredential,
        
        # Source server to migrate
        [Parameter(Mandatory = $true)]
        [object]$sourceServer,     

        # Target VM Name
        [Parameter()]
        [object]$targetVMName,
        
        # target template name to use
        [Parameter()]
        [string]$targetTemplateName,
        
        [Parameter(Mandatory = $true)]
        [string]$InstanceSizeName, 

        [Parameter(Mandatory=$False)]
        [string]$VmVirtualNetwork,

        [Parameter(Mandatory=$False)]
        [string]$VmVirtualNetworkSubnet,

        [Parameter(Mandatory=$False)]
        [string]$SubDomainForRDP
    )

    Process
    {   
        $requestOptions = Get-DtoRecommendedRequestOptions -ServerId $sourceServer.id -TargetEnvironmentId $targetEnvId -TargetLocation $targetLocation 
                  
        if (!$requestOptions)
        {    
            throw "Error occurred while fetching recommended request options!"    
        }

        if(![string]::IsNullOrWhiteSpace($targetVMName))
        {
         #Changing the vm Name which retrieved from Get-DtoRecommendedRequestOptions method
         $requestOptions.migrations[0].vmConfig.vmName=$targetVMName
        }

        if(![string]::IsNullOrWhiteSpace($targetTemplateName))
        {
         #Changing the target template Name which retrieved from Get-DtoRecommendedRequestOptions method
         $requestOptions.migrations[0].vmConfig.imageName=$targetTemplateName
        }
       
        $request = New-DtoRequest -Name $sourceServer.computerName -TargetEnvironmentId $targetEnvId -ServerId $sourceServer.id -AdminCredential $adminCredential -RequestOptions $requestOptions -EncryptedEBS $encryptedEBS -AwsKeyPair $AwsKeyPair -ResourceGroupName $ResourceGroupName -AMHProjectName $AMHProjectName -AMHProjectsolutionName $AMHProjectsolutionName -targetNetwork $targetNetwork -VmVirtualNetwork $VmVirtualNetwork -VmVirtualNetworkSubnet $VmVirtualNetworkSubnet -instanceSizeName $InstanceSizeName -subdomainForRDP $SubDomainForRDP
        if (!$request)
        {    
            throw "Error occurred while starting the migration!"    
        }
       
        Write-Host "Starting migration!"
        return $request
    }    
}

# Function that checks and waits for a migration to complete
function CheckMigration
{
    [CmdletBinding()]
    Param (
        # Migration ID
        [Parameter(Mandatory=$True)]
        [string]$migrationId,
        
        # CMC WebApi URI. ex: migrateapi.doubletake.com 
        [Parameter(Mandatory=$True)]
        [string]$cmcApiServer,

        # CMC Scheme. ex: http or https
        [Parameter(Mandatory=$True)]
        [string]$cmcScheme,

        # CMC user email
        [Parameter(Mandatory=$True)]
        [string]$cmcUserName,
    
        # CMC user password
        [Parameter(Mandatory=$True)]
        [string]$cmcPassword        
    )

    Process
    {   
        $previousStatus = $null
        $previousProgress = $null
        do
        {
            $user = AuthenticateUser -cmcApiServer $cmcApiServer -cmcScheme $cmcScheme -cmcUserName $cmcUserName -cmcPassword $cmcPassword
            $migration = Get-DtoMigration -Id $migrationId                       
            $migrationCurrentOperation = $migration.currentOperation
            $migrationCurrentOperationStatus = $migration.currentOperationStatus
            $migrationCurrentOperationProgress = $migration.currentOperationProgress

            If ($migrationCurrentOperation -eq "cuttingOver")
            {
                throw "Cutover has started. This migration was set to require user intervention."
            }
    
            if ($migrationCurrentOperation -eq "waitingToCutover")
            {
                break
            }

            If ($migration.status -ne $previousStatus -or $migrationCurrentOperationProgress -ne $previousProgress)
            {
                if ($migrationCurrentOperationProgress)
                {
                    Write-Host "CurrentOperation is: "  $migrationCurrentOperation "  CurrentOperationStatus is: " $migrationCurrentOperationStatus "  CurrentOperationPercentage is: " $migrationCurrentOperationProgress                   
                }
                elseif ($migrationCurrentOperation -and $migrationCurrentOperationStatus)
                {
                    Write-Host "CurrentOperation is: "  $migrationCurrentOperation "  CurrentOperationStatus is: " $migrationCurrentOperationStatus
                }
            }

            $previousStatus = $migration.status
            $previousProgress = $migration.currentOperationProgress
            Start-Sleep -Seconds 30
    
            if ($migration.status -eq "faulted")
            {
                Write-Host "The migration is in a faulted state!"
                throw "Migration is in a faulted state"
            }
        }
        while ($migrationCurrentOperation -ne "waitingToCutover")

        Write-Host "CurrentOperation is: "  $migrationCurrentOperation        
    }    
}

# Function that removes a request and waits until it is removed
function RemoveRequest
{
    [CmdletBinding()]
    Param (
        # Request ID
        [Parameter(Mandatory=$True)]
        [string]$requestId 
    )

    Process
    {   
        if (!$requestId)
        {
            throw "RequestId is null"
        }

        # Remove the request
        Remove-DtoRequest -Id $requestId

        # Wait until it is removed
        do
        {
            Try
            {
                $request = Get-DtoRequest -Id $requestId

                If ($request)
                {
                    Write-Host "Request still exists.  The status is: " $request.status
                    $retry = "true"

                    Start-Sleep -Seconds 10
                }
            }
            catch [Exception]
            {
                If($_.Exception.Message -eq "The remote server returned an error: (404) Not Found.")
                {
                    $retry = "false"
                }
            }
        }
        while ($retry -eq "true")

        Write-Host "Request has been deleted!"
    }    
} 
