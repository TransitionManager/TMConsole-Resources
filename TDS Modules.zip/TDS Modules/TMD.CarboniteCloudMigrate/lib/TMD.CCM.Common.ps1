
<#
.SYNOPSIS
	Sets the DNS name of the Double-Take Cloud Migration Center REST API server.

.DESCRIPTION
	Set-DtoDefaultHostName sets the DNS name of the server hosting the Double-Take Cloud Migration Center REST API.

.PARAMETER HostName
	The DNS name of the API hosting server.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Set-DtoDefaultHostName mytestserver
#>
function Set-DtoDefaultHostName
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$HostName
	)

	Process
	{
		$global:DtDefaultHostName = $HostName
	}
}

<#
.SYNOPSIS
	Gets the DNS name of the Double-Take Cloud Migration Center REST API server.

.DESCRIPTION
	Get-DtoDefaultHostName gets the DNS name of the server hosting the Double-Take Cloud Migration Center REST API.

.INPUTS
	None.

.OUTPUTS    
	Get-DtoDefaultHostName returns a string with the name of the server hosting
	the Double-Take Cloud Migration Center REST API.        

.EXAMPLE
	Get-DtoDefaultHostName    
#>
function Get-DtoDefaultHostName
{
	[CmdletBinding()]
	Param ()

	Process
	{
		$global:DtDefaultHostName
	}
}

<#
.SYNOPSIS
	Sets the default scheme of the Double-Take Cloud Migration Center REST API URI.

.DESCRIPTION
	Set-DtoDefaultScheme sets the default scheme of the Double-Take Cloud Migration Center REST API URI.

.PARAMETER Scheme
	The Scheme to use

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Set-DtoDefaultScheme https
#>

function Set-DtoDefaultScheme
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateSet("http", "https")]
		[string]$Scheme
	)

	Process
	{
		$global:DtDefaultScheme = $Scheme
	}
}

<#
.SYNOPSIS
	Gets the default scheme of the Double-Take Cloud Migration Center REST API URI.

.DESCRIPTION
	Get-DtoDefaultScheme gets the default scheme of the Double-Take Cloud Migration Center REST API URI.

.INPUTS
	None.

.OUTPUTS
	Get-DtoDefaultScheme returns a string with the scheme of the Double-Take Cloud Migration Center REST API URI.

.EXAMPLE
	Get-DtoDefaultScheme    
#>
function Get-DtoDefaultScheme
{
	[CmdletBinding()]
	Param ()

	Process
	{
		$global:DtDefaultScheme
	}
}

<#
.SYNOPSIS
	Makes a REST call with the supplied parameters.

.DESCRIPTION
	Invoke-DtoMethod encodes a request body to the UTF-8 format (if supplied) and sets all the
	parameters needed and sends an HTTP or HTTPS request to a RESTful web service using Invoke-RestMethod.

.PARAMETER Path
	Web API route.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Query
	The extra query to add to the URI.

.PARAMETER Body
	The body to encode.

.PARAMETER ContentType
	The content type of the web request.

.PARAMETER Headers
	The headers of the web request.

.PARAMETER Method
	The method used for the web request. Valid values are Default, Delete, Get, Head, Merge, Options, Patch, Post, Put, and Trace.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Invoke-DtoMethod -Path webAPIRoute -Scheme https -HostName mytestserver -Query testQuery -Body testBody -ContentType "application/json" -Headers testHeaders -Method Post
#>
function Invoke-DtoMethod
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0, Mandatory = $true)]
		[string]$Path,

		[Parameter(Position = 1)]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter(Position = 2)]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[string]$Query,

		[Parameter()]
		[System.Object]$Body,

		[Parameter()]
		[string]$ContentType,

		[Parameter()]
		[Int32]$TimeoutInSecs = 300,

		[Parameter()]
		[System.Collections.IDictionary]$Headers = $(Get-DtoCurrentHeader),

		[Parameter()]
		[Microsoft.PowerShell.Commands.WebRequestMethod]$Method = [Microsoft.PowerShell.Commands.WebRequestMethod]::Get
	)

	Process
	{
		if ($Body)
		{
			$RequestBody = ([System.Text.Encoding]::UTF8.GetBytes($Body))
		}

		Invoke-RestMethod $(New-DtoUri $Scheme $HostName $Path -Query $Query) -Method $Method -Body $RequestBody -ContentType $ContentType -Headers $Headers -TimeoutSec $TimeoutInSecs
	}
}


<#
.SYNOPSIS
	Verifies a Double-Take Cloud Migration Center account.

.DESCRIPTION
	Confirm-DtoAccount verifies that a Double-Take Cloud Migration Center account is valid by attempting to connect to it.
	The error code and error message will be returned if the test failed.

.PARAMETER AwsAccessKey
	The Amazon Web Services access key.

.PARAMETER AwsSecretKey
	The Amazon Web Services secret key.

.PARAMETER PublishSettingsPath
	The Azure publish settings file path.

.PARAMETER Subscription
	The subscription name to be used from the publish settings file.

.PARAMETER VmWareHost
	The vSphere or vCloud host IP or name.

.PARAMETER VCloudOrganization
	The vCloud organization name.

.PARAMETER OpenStackServerUrl
	The openstack server keystone URL.

.PARAMETER OpenStackProject
	The openstack project name.

.PARAMETER ProxyServerName
	The proxy server name.

.PARAMETER DomainName
	The domain name of the active directory environment.

.PARAMETER LdapSearchPath
	The ldap search path of the active directory environment.

.PARAMETER UserNameEnv
	The username for the vSphere host, vCloud host, OpenStack server, or Active Directory.

.PARAMETER PasswordEnv
	The password for the vSphere host, vCloud host, OpenStack server, or Active Directory.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	Amazon Web Services access key, Amazon Web Services secret key, vSphere or vCloud host IP or name, vCloud organization name, proxy ID,
	domain name of the active directory environment, ldap search path of the active directory environment, username and password for the 
	vSphere host, vCloud host, or Active Directory.

.OUTPUTS
	Confirm-DtoAccount returns the test result which includes success or authorizationFailed.
	The error code and error message will be included if the test failed. 

.EXAMPLE
	Confirm-DtoAccount -AwsAccessKey amazonAccessKey -AwsSecretKey amazonSecretKey

.EXAMPLE
	Confirm-DtoAccount -PublishSettingsPath AzurepublishSettingsPath -Subscription subscriptionName

.EXAMPLE
	Confirm-DtoAccount -VmWareHost vSphereHost -UserNameEnv vSphereHostUserName -PasswordEnv vSphereHostPassword

.EXAMPLE
	Confirm-DtoAccount -VmWareHost vCloudHost -VCloudOrganization vCloudOrganization -ProxyServerName proxyName -UserNameEnv vCloudHostUserName -PasswordEnv vCloudHostPassword

.EXAMPLE
	Confirm-DtoAccount -OpenStackServerUrl openStackServerUrl -OpenStackProject openStackProject -UserNameEnv openStackUserName -PasswordEnv openStacktPassword

.EXAMPLE
	Confirm-DtoAccount -DomainName domainName -UserNameEnv domainUserName -PasswordEnv domainPassword
#>
function Confirm-DtoAccount
{
	[CmdletBinding(DefaultParameterSetName = "AmazonAccount")]
	Param (
		[Parameter(Mandatory = $true, ParameterSetName = "AmazonAccount", ValueFromPipelineByPropertyName = $true)]
		[string]$AwsAccessKey,

		[Parameter(Mandatory = $true, ParameterSetName = "AmazonAccount", ValueFromPipelineByPropertyName = $true)]
		[string]$AwsSecretKey,

		[Parameter(ParameterSetName = "AzureEnvironment", Mandatory = $true)]
		[string]$PublishSettingsPath,

		[Parameter(ParameterSetName = "AzureEnvironment", Mandatory = $true)]
		[string]$Subscription,
				
		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)] 
		[Alias("Host")]       
		[string]$VmWareHost,   
		
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]        
		[string]$VCloudOrganization,

		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$OpenStackServerUrl,

		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$OpenStackProject,

		[Parameter(ParameterSetName = "AmazonAccount", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "AzureEnvironment")]
		[Parameter(ParameterSetName = "vSphereEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", ValueFromPipelineByPropertyName = $true)]        
		[string]$ProxyServerName,
		
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]        
		[string]$DomainName,  
		
		[Parameter(ParameterSetName = "ADEnvironment", ValueFromPipelineByPropertyName = $true)]        
		[string]$LdapSearchPath,                 

		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[ValidateLength(1, 254)]
		[Alias("u")]
		[string]$UserNameEnv,

		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[ValidateLength(3, 50)]
		[Alias("p")]
		[string]$PasswordEnv,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$verificationModel = New-Object PSObject
				
		# Add the proxy if supplied
		if($ProxyServerName)
		{
			$proxy = Get-DtoProxy | Where-Object {$_.Name -eq $ProxyServerName}

			$verificationModel | Add-Member -MemberType NoteProperty -Name proxyId -Value $proxy.Id          
		}

		switch ($PSCmdlet.ParameterSetName)
		{
			"AmazonAccount" {
				$envType = Get-EnvTypeKey -EnvironmentType "Amazon" 

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					accessKey = $AwsAccessKey 
					secretKey = $AwsSecretKey 
				}                

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel
			}

			"AzureEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "Azure" 

				try
				{
					[xml]$publishSettings = Get-Content $PublishSettingsPath
				}
				catch [ItemNotFoundException]
				{
					throw
				}

				$publishProfile = $publishSettings.PublishData.PublishProfile
				$sub =  $publishProfile.Subscription | Where-Object {$_.Name -eq $Subscription}

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					publishMethod = $publishProfile.PublishMethod
					serviceManagementUrl = $sub.ServiceManagementUrl
					subscriptionId = $sub.Id
					subscriptionName = $sub.Name
					managementCertificate = $sub.ManagementCertificate
				}

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel
			}            

			"vSphereEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "VSphere"

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $VmWareHost
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel 
			}

			"vCloudEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "VCloud" 

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $VmWareHost
					organization = $VCloudOrganization
					userName = $UserNameEnv
					password = $PasswordEnv                    
				}

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel                
			}

			"OpenStackEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "OpenStack" 

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $OpenStackServerUrl
					project = $OpenStackProject
					userName = $UserNameEnv
					password = $PasswordEnv                    
				}

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel                
			}

			"ADEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "AD"

				$accountModel = New-Object PSObject -Property @{
					envType = $envType
					domainName = $DomainName
					ldapSearchPath = $LdapSearchPath
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$verificationModel | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$verificationModel | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $accountModel 
			}            
		}
 
		$body = ConvertTo-Json $verificationModel 
		Write-Verbose $body

		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path "api/environments/actions/verifyAccount" -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}
# Private Functions
function New-DtoUri
{
	[CmdletBinding()]
	[OutputType([System.Uri])]
	Param (
		[Parameter(Position = 0)]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter(Position = 1)]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter(Position = 2)]
		[string]$Path,
		
		[Parameter(Position = 3)]
		[string]$UserName,

		[Parameter()]
		[string]$Query
	)

	Process
	{
		$uriHost = $HostName
		$uriPort = [int]-1
		if ($HostName.Contains(":"))
		{
			$parts = $HostName.Split(":")
			$uriHost = $parts[0]
			$uriPort = [System.Convert]::ToInt32($parts[1])
		}

		$builder = New-Object System.UriBuilder ($Scheme, $uriHost)
		if ($uriPort -ne -1)
		{
			$builder.Port = $uriPort
		}

		if ($Path)
		{
			$builder.Path = $Path
		}

		if ($UserName)
		{
			$builder.UserName = [System.Uri]::EscapeDataString($UserName)
		}

		if ($Query)
		{
			$builder.Query = $Query
		}

		$builder.Uri
	}
}

function Get-DtoCurrentHeader
{
	[CmdletBinding()]
	Param()

	Process
	{
		if ($global:DtCurrentLoginKey -ne $null)
		{
			$currentLogin = $global:DtLogins[$global:DtCurrentLoginKey];
			$expires = [System.DateTime]::Parse($currentLogin.".expires");
			if ($expires -lt [System.DateTime]::Now)
			{
				$currentLogin = Update-DtoLogin
			}

			@{ Authorization = "Bearer $($currentLogin.access_token)" }
		}
		else
		{
			throw "No authentication token has been established. Please use Add-DtoLogin to establish one."
		}
	}
}


<#
.SYNOPSIS
	Creates a list of servers in the database.

.DESCRIPTION
	New-DtoCustomServerUpdateDb creates a list of servers in the database.

.PARAMETER ServerDescriptions
	The server description object(s).

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	New-DtoCustomServerUpdateDb returns the list of servers created.

.EXAMPLE
	New-DtoCustomServerUpdateDb -ServerDescriptions serverDescriptionObjects
#>
function New-DtoCustomServerUpdateDb
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true)]
		[object[]]$ServerDescriptions,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$body = ConvertTo-Json @($ServerDescriptions) -Depth 5
		Write-Verbose $body
		Invoke-DtoMethod -Path "api/servers" $Scheme $HostName -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}
