


function New-DtoRequest
{
	[CmdletBinding()]
	Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$Name,

	[Parameter(Mandatory = $true, position = 1)]
	[string]$TargetEnvironmentId,

	[Parameter(Mandatory = $true, Position = 2)]
	[int[]]$ServerId,               

	[Parameter(Mandatory = $true)]
	[System.Management.Automation.Credential()]$AdminCredential,

	[Parameter(Mandatory = $true)]
	[object]$RequestOptions,

	[Parameter()]
	[ValidateSet($False,$True, 0, 1)]
	[string]$EncryptedEBS,

	[Parameter()]      
	[string]$AwsKeyPair,

	# Resource Group Name: Used only for AzureMH target envirnonment.
	[Parameter(Mandatory=$False)]
	[string]$ResourceGroupName,

	# Migrate Project Name: Used only for AzureMH target envirnonment.
	[Parameter(Mandatory=$False)]
	[string]$AMHProjectName,

	# Migrate Project Solution Name: Used only for AzureMH target envirnonment.
	[Parameter(Mandatory=$False)]
	[string]$AMHProjectsolutionName,

	[Parameter()]
	[string]$HostName = $global:DtDefaultHostName,

	[Parameter()]
	[ValidateSet("http", "https")]
	[string]$Scheme = $global:DtDefaultScheme,
	
	[Parameter()]
	$Headers = $(Get-DtoCurrentHeader),

	[Parameter(Mandatory = $true)]
	[string]$InstanceSizeName,

	[Parameter(Mandatory=$False)]
	[string]$targetNetwork,

	[Parameter(Mandatory=$False)]
	[string]$VmVirtualNetwork,

	[Parameter(Mandatory=$False)]
	[string]$VmVirtualNetworkSubnet,
	
	[Parameter(Mandatory=$False)]
	[string]$subdomainForRDP
	
	)

	Process
	{
		if($AdminCredential)
		{
			$credentialBindingModel = New-Object PSObject -Property @{
				userName = $AdminCredential.UserName
				password = $AdminCredential.GetNetworkCredential().Password
			}

			$RequestOptions.vmConfig | Add-Member -MemberType NoteProperty -Name adminCredential -Value $credentialBindingModel
		}
		$RequestOptions.migrations[0].encryptedEBS = $EncryptedEBS
		$RequestOptions.migrations[0].vmConfig.instanceSizeName = $InstanceSizeName 
		if($RequestOptions.vmConfig.awsKeyPair -ne $null )
		{
			$RequestOptions.vmConfig.awsKeyPair = $AwsKeyPair  
		}

		$request = New-Object PSObject -Property @{
			name = $Name
			targetEnvironmentId = $TargetEnvironmentId
			vmConfig = $RequestOptions.vmConfig
			migrations = $RequestOptions.migrations
			automaticCutover = $RequestOptions.automaticCutover
			shutdownSource = $RequestOptions.shutdownSource
			useCompression = $RequestOptions.useCompression
			cleanUpTarget = $RequestOptions.cleanUpTarget    
		}
	    
		$targetRDPAccess = 0
		if($subdomainForRDP)
		{
			$targetRDPAccess = 1
			$request | Add-Member -NotePropertyName TargetRDPAccess -NotePropertyValue $targetRDPAccess
			$request | Add-Member -NotePropertyName SubDomainForRDP -NotePropertyValue $subdomainForRDP
		}

		#Set Network Parameters for Azure
		if (-not ([string]::IsNullOrEmpty($ResourceGroupName)))
		{
			$request.vmConfig.affinityGroup = $ResourceGroupName

			if (-not ([string]::IsNullOrEmpty($VmVirtualNetwork)))
			{
				$request.vmConfig.virtualNetwork = $VmVirtualNetwork
			}
			if (-not ([string]::IsNullOrEmpty($VmVirtualNetworkSubnet)))
			{
				$request.vmConfig.virtualNetworkSubnet = $VmVirtualNetworkSubnet
			}

			if ($AMHProjectName -eq $null)
			{
				throw "Error occurred while fetching recommended request options! Migrate Project Name not specified."
			}
			$request | Add-Member -MemberType NoteProperty -Name migrationProject -Value $AMHProjectName
			if ($AMHProjectsolutionName -eq $null)
			{
				throw "Error occurred while fetching recommended request options! Migrate Project Solution Name not specified."
			}
			$request | Add-Member -MemberType NoteProperty -Name migrationProjectSolution -Value $AMHProjectsolutionName
		}


		#Set Network Parameters for AWS
		elseif (-not ([string]::IsNullOrEmpty($targetNetwork)))
		{
			$request.vmConfig.affinityGroup = $targetNetwork
			if (-not ([string]::IsNullOrEmpty($VmVirtualNetwork)))
			{
				$request.vmConfig.virtualNetwork = $VmVirtualNetwork
			}
			else
			{
				throw "VmVirtualNetwork cannot be null for custom targetNetwork."
			}
		}
		$body = ConvertTo-Json $request -Depth 10
		Write-Verbose $body

		Invoke-DtoMethod "api/requests" $Scheme $HostName -Method Post -Headers $Headers -ContentType application/json -Body $body
	}
}

<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center request or all the requests for a user.

.DESCRIPTION
	Get-DtoRequest gets a specified Double-Take Cloud Migration Center request or all the requests for a specified user. All the 
	requests created by the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The request ID to get.

.PARAMETER UserId
	The user ID to get the request list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoRequest returns the information of the request(s).

.EXAMPLE
	Get-DtoRequest -Id requestID

.EXAMPLE    
	Get-DtoRequest -UserId userID    
#>
function Get-DtoRequest
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[object[]]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "requests" -EntityTypeName "DoubleTake.Dto.Request" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

<#
.SYNOPSIS
	Gets all tasks for a Double-Take Cloud Migration Center request.

.DESCRIPTION
	Get-DtoRequestTask lists all tasks for a specified Double-Take Cloud Migration Center request.

.PARAMETER RequestId
	The request ID to get the list of tasks.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoRequestTask returns the list of tasks for the request.

.EXAMPLE
	Get-DtoRequestTask -RequestId requestID
#>
function Get-DtoRequestTask
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[object[]]$RequestId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "requests/$RequestId/tasks" -EntityTypeName "DoubleTake.Dto.MigrationTask" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

<#
.SYNOPSIS
	Gets the recommended request options for the provided target environment and servers.

.DESCRIPTION
	Get-DtoRecommendedRequestOptions gets the recommended request options for the provided target environment and servers.

.PARAMETER ServerId
	The server ID.

.PARAMETER TargetEnvironmentId
	The target environment ID.

.PARAMETER TargetLocation
	The target location: virtual network, virtual datacenter,  or region.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoRecommendedRequestOptions returns the recommended request options.

.EXAMPLE
	Get-DtoRecommendedRequestOptions -ServerId serverId -TargetEnvironmentId targetEnvironmentId -TargetLocation targetLocation
#>
function Get-DtoRecommendedRequestOptions
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[int[]]$ServerId,

		[Parameter(Mandatory = $true, position = 1)]
		[string]$TargetEnvironmentId,

		[Parameter()]
		[string]$TargetLocation,       

        [Parameter()]
        [ValidateSet($False,$True, 0, 1)]
        [string]$EncryptedEBS = $global:DtDefaultEncryptedEBS,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)    

	$request = New-Object PSObject -Property @{
		location = $TargetLocation
		serverIds = $ServerId
		targetEnvironmentId = $TargetEnvironmentId       
	}

	$body = ConvertTo-Json $request
	Write-Verbose $body

	Invoke-DtoMethod "api/requests/recommendByLocation" $Scheme $HostName -Method Post -Headers $Headers -ContentType application/json -Body $body
}
<#
.SYNOPSIS
	Starts a migration by request ID.

.DESCRIPTION
	Start-DtoRequest starts a migration by request ID. The request can be a group migration.

.PARAMETER Id
	The ID of the request.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the request.

.OUTPUTS
	None.

.EXAMPLE
	Start-DtoRequest -Id requestId
#>
function Start-DtoRequest
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "/api/requests/$Id/start" $Scheme $HostName -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Resumes a migration by request ID.

.DESCRIPTION
	Resume-DtoRequest resumes a migration by request ID. The request can be a group migration.

.PARAMETER Id
	The ID of the request.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the request.

.OUTPUTS
	None.

.EXAMPLE
	Resume-DtoRequest -Id requestId
#>
function Resume-DtoRequest
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "/api/requests/$Id/resume" $Scheme $HostName -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Removes a migration by request ID.

.DESCRIPTION
	Remove-DtoRequest removes a migration by request ID. The request can be a group migration.

.PARAMETER Id
	The ID of the request.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the request.

.OUTPUTS
	Remove-DtoRequest returns the information of the request removed.

.EXAMPLE
	Remove-DtoRequest -Id requestId
#>
function Remove-DtoRequest
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/requests/$Id" $Scheme $HostName -Method Delete -Headers $Headers
	}
}


<#
.SYNOPSIS
	Starts the cutover operation for the migration(s) in a request.

.DESCRIPTION
	Invoke-DtoRequestCutover starts the cutover operation for the migration(s) in the specified request.

.PARAMETER Id
	The ID of the request.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the request.

.OUTPUTS
	None.

.EXAMPLE
	Invoke-DtoRequestCutover -Id requestId
#>
function Invoke-DtoRequestCutover
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/requests/$Id/cutover" $Scheme $HostName -Method Post -Headers $Headers
	}
}
