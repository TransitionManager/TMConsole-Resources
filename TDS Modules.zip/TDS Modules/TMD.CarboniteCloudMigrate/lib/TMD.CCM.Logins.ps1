

<#
.SYNOPSIS
	Authenticates a user with the Double-Take Cloud Migration Center Web API server.

.DESCRIPTION
	Add-DtoLogin authenticates a user with the Double-Take Cloud Migration Center Web API
	server using a credential object or using an insecure login (username and password).

.PARAMETER Credential
	The credential object.

.PARAMETER UserName
	The username to authenticate.

.PARAMETER Password
	The password.

.PARAMETER SetCurrent
	Switch that if present sets the current Login Key.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.INPUTS
	None.

.OUTPUTS
	Add-DtoLogin returns the access token, token type and all the User information.

.EXAMPLE
	Add-DtoLogin -Credential credentialObject -SetCurrent
#>
function Add-DtoLogin {
	[CmdletBinding(DefaultParameterSetName = "SecureLogin")]
	Param (
		[Parameter(ParameterSetName = "SecureLogin", Mandatory = $true)]
		[System.Management.Automation.Credential()]
		$Credential,

		[Parameter(ParameterSetName = "InsecureLogin", Position = 0, Mandatory = $true)]
		[string]$UserName,

		[Parameter(ParameterSetName = "InsecureLogin", Position = 1, Mandatory = $true)]
		[string]$Password,

		[Parameter()]
		[switch]$SetCurrent,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,
		
		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		[switch]$PassThru
	)

	Process {
		if ($PSCmdlet.ParameterSetName -eq "InsecureLogin") {
			$securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
			$Credential = New-Object PSCredential ($UserName, $securePassword)
		}

		$requestUserName = $credential.UserName
		$requestPassword = $credential.GetNetworkCredential().Password

		$request = "grant_type=password&username={0}&password={1}&client_id=pshell&client_secret=pshellsecret" -f $requestUserName, $requestPassword

		try {
			$response = Invoke-RestMethod $(New-DtoUri $Scheme $HostName "token") -Method Post -ContentType "appliction/x-www-form-urlencoded" -Body $request
			Write-Verbose $(ConvertTo-Json $response)

			$response | Add-Member -MemberType NoteProperty -Name hostname -Value $HostName

			$uri = New-DtoUri $Scheme $HostName -UserName $Credential.UserName
			$authorizationKey = $uri.GetComponents([System.UriComponents]::Host -bor [System.UriComponents]::UserInfo, [System.UriFormat]::SafeUnescaped)

			$global:DtLogins[$authorizationKey] = $response
			
			if ($SetCurrent.IsPresent) {
				$global:DtCurrentLoginKey = $authorizationKey
			}

			if ($PassThru) {
				return $response
			}
		}
		catch [System.Net.WebException] {
			throw            
		}
	}
}

<#
.SYNOPSIS
	Gets authenticated user(s) information from the Double-Take Cloud Migration Center Web API server.

.DESCRIPTION
	Get-DtoLogin gets the authenticated user(s) information from the Double-Take Cloud Migration Center Web API server.
	If no username is specified, it returns the current authenticated user. If the -All switch is specified, 
	all the authenticated users are returned.

.PARAMETER UserName
	The user to get the information for.

.PARAMETER All
	Switch that if present gets all the authenticated user information.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.INPUTS
	None.

.OUTPUTS
	Get-DtoLogin returns the access token, token type and all the User information.

.EXAMPLE
	Get-DtoLogin -All

.EXAMPLE
	Get-DtoLogin -UserName "test@carbonite.com"
#>
function Get-DtoLogin {
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string[]]$UserName,

		[Parameter()]
		[switch]$All,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme
	)

	Process {
		if ($UserName) {
			$UserName | ForEach-Object {
				$uri = New-DtoUri $Scheme $HostName -UserName $_
				$key = $uri.GetComponents([System.UriComponents]::Host -bor [System.UriComponents]::UserInfo, [System.UriFormat]::SafeUnescaped)
				if ($global:DtLogins.ContainsKey($key)) {
					$global:DtLogins[$key]
				}
			}
		}
		else {
			if ($All.IsPresent) {
				$global:DtLogins.Values | ForEach-Object { $_ }
			}
			elseif ($null -ne $global:DtCurrentLoginKey) {
				$global:DtLogins[$global:DtCurrentLoginKey]
			}
		}
	}
}



function Update-DtoLogin {
	[CmdletBinding()]
	Param (
		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme
	)

	Process {
		if ($null -ne $global:DtCurrentLoginKey) {
			$currentLogin = $global:DtLogins[$global:DtCurrentLoginKey]
			$request = "grant_type=refresh_token&refresh_token={0}&client_id=pshell&client_secret=pshellsecret" -f $currentLogin.refresh_token

			try {
				$uri = $(New-DtoUri $Scheme $HostName "token")
				$response = Invoke-RestMethod $uri -Method Post -ContentType "appliction/x-www-form-urlencoded" -Body $request
				$response | Add-Member -MemberType NoteProperty -Name hostname -Value $HostName
				$global:DtLogins[$global:DtCurrentLoginKey] = $response
				$response
			}
			catch [System.Net.WebException] {
				throw
			}
		}
	}
}
