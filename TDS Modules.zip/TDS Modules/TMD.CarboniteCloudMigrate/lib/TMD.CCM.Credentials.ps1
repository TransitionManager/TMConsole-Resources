<#
.SYNOPSIS
	Gets the credentials associated with an environment, a server, or by ID.

.DESCRIPTION
	Get-DtoCredential gets the credentials associated with the specified environment, the specified server, or by ID.

.PARAMETER Id
	The credentials ID to retrieve.

.PARAMETER EnvironmentId
	The environment ID.

.PARAMETER ServerId
	The server ID.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoCredential returns the credentials.

.EXAMPLE
	Get-DtoCredential -Id credentialsID

.EXAMPLE
	Get-DtoCredential -EnvironmentId environmentID

.EXAMPLE
	Get-DtoCredential -ServerId serverID
#>
function Get-DtoCredential
{
	[CmdletBinding(DefaultParameterSetName = "ForEnvironment")]
	Param (
		[Parameter(ParameterSetName = "ById", Mandatory = $true, Position = 0)]
		[string]$Id,

		[Parameter(ParameterSetName = "ForEnvironment", Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter(ParameterSetName = "ForServer", Mandatory = $true, Position = 0)]
		[int]$ServerId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		switch ($PSCmdlet.ParameterSetName)
		{
			"ById" {
				Get-DtoEntity -ControllerName "credentials" -EntityTypeName "DoubleTake.Dto.Credential" -EntityId $Id -HostName $HostName -Scheme $Scheme -Headers $Headers
			}
			"ForEnvironment" {
				Get-DtoEntity -ControllerName "environments/$EnvironmentId/credentials" -EntityTypeName "DoubleTake.Dto.Credential" -HostName $HostName -Headers $Headers
			}
			"ForServer" {
				Get-DtoEntity -ControllerName "servers/$ServerId/credentials" -EntityTypeName "DoubleTake.Dto.Credential" -HostName $HostName -Scheme $Scheme -Headers $Headers
			}
		}
	}
}


<#
.SYNOPSIS
	Associates a credential object with the specified server.

.DESCRIPTION
	New-DtoCredentialForServer associates a credential object with the specified server.

.PARAMETER Id
	The server Id.

.PARAMETER CmcCredential
	The credential object.   

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	New-DtoCredentialForServer returns the list of credentials associated with the specified server.

.EXAMPLE
	New-DtoCredentialForServer -Id serverId -CmcCredential credentialObject
#>
function New-DtoCredentialForServer
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true)]
		[int]$Id,
		
		[Parameter(Mandatory = $true)]
		[object]$CmcCredential,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$serverUserName = $CmcCredential.UserName
		$serverPassword = $CmcCredential.GetNetworkCredential().Password

		$credentialObject = New-Object PSObject -Property @{
			username = $serverUserName
			password = $serverPassword
		}

		$body = ConvertTo-Json $credentialObject
		Write-Verbose $body
		Invoke-DtoMethod -Path "api/servers/$Id/credentials" $Scheme $HostName -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}
