

<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center server or all the servers for a user.

.DESCRIPTION
	Get-DtoServer gets a specified Double-Take Cloud Migration Center server or all the server belonging to a specified user.
	All the servers for the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The server ID to get.

.PARAMETER UserId
	The user ID to get the server list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoServer returns the information of the server(s).

.EXAMPLE
	Get-DtoServer -Id serverID

.EXAMPLE    
	Get-DtoServer -UserId userID    
#>
function Get-DtoServer
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[int]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "servers" -EntityTypeName "DoubleTake.Dto.Server" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}
<#
.SYNOPSIS
	Gets the recommended servers for migration.

.DESCRIPTION
	Get-DtoRecommendedMigrationServer gets the recommended servers for migration. An environment can be specified to get
	the recommended servers for migration for that environment.

.PARAMETER EnvironmentId
	The environment ID.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoRecommendedMigrationServer returns the list of recommended servers for migration.

.EXAMPLE
	Get-DtoRecommendedMigrationServer -EnvironmentId environmentId
#>
function Get-DtoRecommendedMigrationServer
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	if ($PSCmdlet.MyInvocation.BoundParameters.ContainsKey("EnvironmentId"))
	{
		Invoke-DtoMethod "api/environments/$EnvironmentId/servers/recommend" $Scheme $HostName -Method Post -Headers $Headers
	}
	else
	{
		Invoke-DtoMethod "api/servers/recommend" $Scheme $HostName -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Removes a server or servers by server ID.

.DESCRIPTION
	Remove-DtoServer removes a single server or a list of servers by server ID.

.PARAMETER Id
	The ID of the server(s).

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the server(s).

.OUTPUTS
	Remove-DtoServer returns the information of the server(s) removed.

.EXAMPLE
	Remove-DtoServer -Id serverId
#>
function Remove-DtoServer
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int[]]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$body = ConvertTo-Json $id -Depth 5        
		Write-Verbose $body

		Invoke-DtoMethod "api/servers/delete" $Scheme $HostName -Method Post -Headers $Headers -Body $body -ContentType "application/json"
	}
}


<#
.SYNOPSIS
	Tests if a Double-Take Cloud Migration Center server needs to be rebooted.

.DESCRIPTION
	Test-DtoIsRebootRequired tests if the specified Double-Take Cloud Migration Center server needs to be rebooted.

.PARAMETER Id
	The server ID to test.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Test-DtoIsRebootRequired returns whether the server needs to be rebooted with all the information.

.EXAMPLE
	Test-DtoIsRebootRequired -Id serverID
#>
function Test-DtoIsRebootRequired
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[object[]]$Id,       

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{        
		Get-DtoEntity -ControllerName "servers/isRebootRequired" -EntityTypeName "DoubleTake.Dto.Server" -EntityId $Id -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

