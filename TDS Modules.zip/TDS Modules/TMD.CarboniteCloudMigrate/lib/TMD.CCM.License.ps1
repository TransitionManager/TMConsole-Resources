
<#
.SYNOPSIS
	Validates a migration license.

.DESCRIPTION
	Confirm-DtoLicense validates the specified migration license.

.PARAMETER ActivationCode
	The migration license to validate.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	Migration license.

.OUTPUTS
	Confirm-DtoLicense returns the information about the migration license which includes whether it is valid or not and the number activation
	counts remaining.

.EXAMPLE
	Confirm-DtoLicense -ActivationCode migrationLicense
#>
function Confirm-DtoLicense
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeLine = $true)]
		[string]$ActivationCode,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$model = New-Object PSObject -Property @{
			activationCode = $ActivationCode 
		}
		$body = ConvertTo-Json $model
		Write-Verbose $body

		Invoke-DtoMethod -Path "api/licenses/actions/verifyActivationCode" -Scheme $Scheme -HostName $HostName -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}

<#
.SYNOPSIS
	Adds a migration license to the Double-Take Cloud Migration Center.

.DESCRIPTION
	Add-DtoLicense adds the specified migration license to the Double-Take Cloud Migration Center. The license is validated before it is added. An error is returned if the license is invalid
	or it does not have any remaining activations.

.PARAMETER ActivationCode
	The migration license to add.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	Migration license.

.OUTPUTS
	Add-DtoLicense returns the information about the migration license which includes whether it is valid or not and the number activation
	counts remaining. An error is returned if the license is invalid.

.EXAMPLE
	Add-DtoLicense -ActivationCode migrationLicense
#>
function Add-DtoLicense
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeLine = $true)]
		[string]$ActivationCode,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$model = New-Object PSObject -Property @{
			activationCode = $ActivationCode 
		}
		$body = ConvertTo-Json $model
		Write-Verbose $body

		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path "api/licenses" -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}

<#
.SYNOPSIS
	Gets the license for an activation code or gets the list of licenses belonging to a user.

.DESCRIPTION
	Get-DtoLicense gets the license for the specified activation code or gets the list of licenses belonging to the specified user.
	All the licenses for the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The activation code ID to get the license for.

.PARAMETER UserId
	The user ID to get the license list.

.PARAMETER Refresh
	Switch to refresh license quantities.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoLicense returns the license information.

.EXAMPLE
	Get-DtoLicense -id activationCodeID

.EXAMPLE    
	Get-DtoLicense -UserId userID -Refresh
#>
function Get-DtoLicense
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[object[]]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[switch]$Refresh,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		if ($Refresh)
		{
			$query = "refresh=true"
		}

		Get-DtoEntity -ControllerName "licenses" -EntityTypeName "DoubleTake.Dto.License" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers -Query $query
	}
}


<#
.SYNOPSIS
	Removes a migration license from the Double-Take Cloud Migration Center.

.DESCRIPTION
	Remove-DtoLicense removes the specified migration license from the Double-Take Cloud Migration Center.

.PARAMETER ActivationCode
	The migration license to remove.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	Migration license.

.OUTPUTS
	Remove-DtoLicense returns the information about the migration license that was removed.

.EXAMPLE
	Remove-DtoLicense -ActivationCode migrationLicense
#>
function Remove-DtoLicense
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$ActivationCode,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/licenses/$ActivationCode" $Scheme $HostName -Method Delete -Headers $Headers
	}
}
