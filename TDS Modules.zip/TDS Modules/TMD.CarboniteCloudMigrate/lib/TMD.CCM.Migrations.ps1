

<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center migration or all the migrations for a user.

.DESCRIPTION
	Get-DtoMigration gets a specified Double-Take Cloud Migration Center migration or all the migrations for a specified user. All the 
	migrations for the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The migration ID to get.

.PARAMETER UserId
	The user ID to get the migration list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoMigration returns the information of the migration(s).

.EXAMPLE
	Get-DtoMigration -Id migrationID

.EXAMPLE    
	Get-DtoMigration -UserId userID    
#>
function Get-DtoMigration
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[object[]]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "migrations" -EntityTypeName "DoubleTake.Dto.Migration" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}


<#
.SYNOPSIS
	Gets all tasks for a Double-Take Cloud Migration Center migration.

.DESCRIPTION
	Get-DtoMigrationTask lists all tasks for a specified Double-Take Cloud Migration Center migration.

.PARAMETER MigrationId
	The migration ID to get the list of tasks.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoMigrationTask returns the list of tasks for the migration.

.EXAMPLE
	Get-DtoMigrationTask -MigrationId migrationID
#>
function Get-DtoMigrationTask
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[object[]]$MigrationId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "migrations/$MigrationId/tasks" -EntityTypeName "DoubleTake.Dto.MigrationTask" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}


<#
.SYNOPSIS
	Lists log entries for a specified Double-Take Cloud Migration Center migration or request task, or lists all log entries
	for all migration requests belonging to a user.

.DESCRIPTION
	Get-DtoMigrationLogEntry lists log entries for a specified Double-Take Cloud Migration Center migration or request task, or lists all log entries
	for all migration requests belonging to the specified user. All the log entries for the authenticated user is returned if nothing is supplied.

.PARAMETER LastId
	The last log entry log ID. If used, only log entries after this ID will be retrieved.

.PARAMETER MigrationId
	The migration ID to get the log entry list.

.PARAMETER RequestId
	The request ID to get the log entry list.

.PARAMETER UserId
	The user ID to get the log entry list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoMigrationLogEntry returns the log entry list.

.EXAMPLE
	Get-DtoMigrationLogEntry -UserId userID -LastId lastLogEntryLogID
#>
function Get-DtoMigrationLogEntry
{
	[CmdletBinding(DefaultParameterSetName = "All")]
	Param (
		[Parameter(ParameterSetName = "All", Position = 0)]
		[Parameter(ParameterSetName = "ForMigration")]
		[Parameter(ParameterSetName = "ForRequest")]
		[int]$LastId,

		[Parameter(ParameterSetName = "ForMigration", Mandatory = $true)]
		[int]$MigrationId,

		[Parameter(ParameterSetName = "ForRequest", Mandatory = $true)]
		[int]$RequestId,

		[Parameter(ParameterSetName = "All")]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		switch ($PSCmdlet.ParameterSetName)
		{
			"ForMigration" { $uri = "migrations/$MigrationId/log" }
			"ForRequest" { $uri = "requests/$RequestId/log" }
			default {
				$uri = "log"
			}
		}

		$query = $null
		if ($PSCmdlet.MyInvocation.BoundParameters.ContainsKey("LastId"))
		{
			$query = "lastId=$LastId"
		}

		Get-DtoEntity -ControllerName $uri -EntityTypeName "DoubleTake.Dto.MigrationLogEntry" -Query $query -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

<#
.SYNOPSIS
	Removes a migration by migration ID.

.DESCRIPTION
	Remove-DtoMigration removes a single migration by migration ID.

.PARAMETER Id
	The ID of the migration.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the migration.

.OUTPUTS
	Remove-DtoMigration returns the information of the migration removed.

.EXAMPLE
	Remove-DtoMigration -Id migrationId
#>
function Remove-DtoMigration
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/migrations/$Id" $Scheme $HostName -Method Delete -Headers $Headers
	}
}


<#
.SYNOPSIS
	Resumes a migration by migration ID.

.DESCRIPTION
	Resume-DtoMigration resumes a single migration by migration ID.

.PARAMETER Id
	The ID of the migration.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the migration.

.OUTPUTS
	None.

.EXAMPLE
	Resume-DtoMigration -Id migrationId
#>
function Resume-DtoMigration
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "/api/migrations/$Id/resume" $Scheme $HostName -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Starts the cutover operation on a migration.

.DESCRIPTION
	Invoke-DtoMigrationCutover starts the cutover operation on the specified migration.

.PARAMETER Id
	The ID of the migration.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the migration.

.OUTPUTS
	None.

.EXAMPLE
	Invoke-DtoMigrationCutover -Id migrationId
#>
function Invoke-DtoMigrationCutover
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/migrations/$Id/cutover" $Scheme $HostName -Method Post -Headers $Headers
	}
}
