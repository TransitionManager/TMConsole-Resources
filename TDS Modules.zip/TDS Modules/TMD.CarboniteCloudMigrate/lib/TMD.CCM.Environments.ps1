
function Get-EnvTypeKey
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentType        
	)

	Process
	{
		switch ($EnvironmentType)
		{
			"Amazon" {
				return 1            
			}

			"Azure" {
				return 2            
			}

			"Custom" {
				return 3            
			}

			"AD" {
				return 4            
			}

			"VCloud" {
				return 5            
			}

			"VSphere" {
				return 6            
			}

			"OpenStack" {
				return 7            
			}

			"ARM" {
				return 8
			}

			"AMH" {
				return 9
			}

			default {
				return 0
			}
		}       
	}
}


<#
.SYNOPSIS
	Creates a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Add-DtoEnvironment creates a Double-Take Cloud Migration Center environment.

.PARAMETER Name
	The name of the environment to create.

.PARAMETER AccessKey
	The Amazon Web Services access key.

.PARAMETER SecretKey
	The Amazon Web Services secret key.

.PARAMETER PublishSettingsPath
	The Azure publish settings file path.

.PARAMETER Subscription
	The subscription name to be used from the publish settings file.

.PARAMETER ClientId
	The Azure Resource Manager or AMH ClientId.

.PARAMETER ClientSecret
	The Azure Resource Manager or AMH ClientSecret.

.PARAMETER TenantId
	The Azure Resource Manager or AMH TenantId.

.PARAMETER SubscriptionId
	The Azure Resource Manager or AMH SubscriptionId.

.PARAMETER VmWareHost
	The vSphere or vCloud host IP or name.

.PARAMETER VCloudOrganization
	The vCloud organization name.

.PARAMETER OpenStackServerUrl
	The openstack server keystone URL.

.PARAMETER OpenStackProject
	The openstack project name.

.PARAMETER DomainName
	The domain name of the active directory environment.

.PARAMETER LdapSearchPath
	The ldap search path of the active directory environment.

.PARAMETER UserNameEnv
	The username for the vSphere host, vCloud host, OpenStack server, or Active Directory.

.PARAMETER PasswordEnv
	The password for the vSphere host, vCloud host, OpenStack server, or Active Directory.

.PARAMETER ProxyServerName
	The proxy server name.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	Name of the environment, Amazon Web Services access key, Amazon Web Services secret key, Azure ClientId, ClientSecret, TenantId, SubscriptionId, 
	vSphere or vCloud host IP or name, vCloud organization name, domain name of the active directory environment, ldap search path of the active 
	directory environment, username and password for the vSphere host, vCloud host, or Active Directory.

.OUTPUTS
	Add-DtoEnvironment returns the information of the environment that was created.

.EXAMPLE
	Add-DtoEnvironment -Name environmentName -AccessKey amazonAccessKey -SecretKey amazonSecretKey

.EXAMPLE
	Add-DtoEnvironment -Name environmentName -PublishSettingsPath azurePublishSettingsFilePath -Subscription subscriptionName

.EXAMPLE
	Add-DtoEnvironment -Name environmentName -ClientId clientId -ClientSecret clientSecret -TenantId tenantId -$SubscriptionId subscriptionId

.EXAMPLE    
	Add-DtoEnvironment -Name environmentName -VmWareHost vSphereHost -UserNameEnv vSphereHostUserName -PasswordEnv vSphereHostPassword -ProxyServerName proxyName

.EXAMPLE    
	Add-DtoEnvironment -Name environmentName -VmWareHost vCloudHostIp -VCloudOrganization vCloudOrganization -UserNameEnv vCloudHostUserName -PasswordEnv vCloudHostPassword -ProxyServerName proxyName

.EXAMPLE    
	Add-DtoEnvironment -Name environmentName -OpenStackServerUrl openStackServerUrl -OpenStackProject openStackProject -UserNameEnv openStackUserName -PasswordEnv openStacktPassword -ProxyServerName proxyName

.EXAMPLE    
	Add-DtoEnvironment -Name environmentName -DomainName domainName -UserNameEnv domainUserName -PasswordEnv domainPassword -LdapSearchPath ldapSearchPath -ProxyServerName proxyName
#>
function Add-DtoEnvironment
{
	[CmdletBinding(DefaultParameterSetName = "Custom")]
	Param (        
		[Parameter(ParameterSetName = "AmazonEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "AzureEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "AzureRMEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "Custom", Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[string]$Name,

		[Parameter(ParameterSetName = "AmazonEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$AccessKey,

		[Parameter(ParameterSetName = "AmazonEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$SecretKey,

		[Parameter(ParameterSetName = "AzureRMEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$ClientId,

		[Parameter(ParameterSetName = "AzureRMEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$ClientSecret,

		[Parameter(ParameterSetName = "AzureRMEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$TenantId,

		[Parameter(ParameterSetName = "AzureRMEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$SubscriptionId,

		[Parameter(ParameterSetName = "AzureEnvironment", Mandatory = $true)]
		[string]$PublishSettingsPath,

		[Parameter(ParameterSetName = "AzureEnvironment", Mandatory = $true)]
		[string]$Subscription,
				
		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Alias("Host")]        
		[string]$VmWareHost,               
		
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]        
		[string]$VCloudOrganization,

		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$OpenStackServerUrl,

		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$OpenStackProject,

		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]        
		[string]$DomainName,  
		
		[Parameter(ParameterSetName = "ADEnvironment", ValueFromPipelineByPropertyName = $true)]        
		[string]$LdapSearchPath,                 

		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[ValidateLength(1, 254)]
		[Alias("u")]
		[string]$UserNameEnv,

		[Parameter(ParameterSetName = "vSphereEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
		[ValidateLength(3, 50)]
		[Alias("p")]
		[string]$PasswordEnv,
		
		[Parameter(ParameterSetName = "AmazonEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "AzureEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vSphereEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "vCloudEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "OpenStackEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "ADEnvironment", ValueFromPipelineByPropertyName = $true)]
		[Parameter(ParameterSetName = "Custom", ValueFromPipelineByPropertyName = $true)]
		[string]$ProxyServerName,        

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$environment = New-Object PSObject -Property @{ name = $Name } 
		
		# Add the proxy to the environment if supplied
		if($ProxyServerName)
		{
			$proxy = Get-DtoProxy | Where-Object {$_.Name -eq $ProxyServerName}

			$environment | Add-Member -MemberType NoteProperty -Name proxyId -Value $proxy.Id                        
		}              

		switch ($PSCmdlet.ParameterSetName)
		{
			"AmazonEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "Amazon" 
								
				$amazonAccount = New-Object PSObject -Property @{                    
					envType = $envType
					accessKey = $AccessKey 
					secretKey = $SecretKey 
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $amazonAccount
			}

			"AzureEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "Azure"

				try
				{
					[xml]$publishSettings = Get-Content $PublishSettingsPath
				}
				catch [ItemNotFoundException]
				{
					throw
				}

				$publishProfile = $publishSettings.PublishData.PublishProfile
				$sub =  $publishProfile.Subscription | Where-Object {$_.Name -eq $Subscription}

				$azureProfile = New-Object PSObject -Property @{
					envType = $envType
					publishMethod = $publishProfile.PublishMethod
					serviceManagementUrl = $sub.ServiceManagementUrl
					subscriptionId = $sub.Id
					subscriptionName = $sub.Name
					managementCertificate = $sub.ManagementCertificate
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $azureProfile 
			}            
			
			"AzureRMEnvironment" {
				
				$envType = Get-EnvTypeKey -EnvironmentType "ARM"	
				
				$azureRMProfile = New-Object PSObject -Property @{
					envType = $envType
					armClientId = $ClientId
					armClientSecret = $ClientSecret
					tenantId = $TenantId
					subscriptionId = $SubscriptionId
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $azureRMProfile

			}

			"vSphereEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "VSphere" 

				$vSphereAccount = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $VmWareHost
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $vSphereAccount 
			}

			"vCloudEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "VCloud" 

				$vCloudAccount = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $VmWareHost
					organization = $VCloudOrganization
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $vCloudAccount 
			}

			"OpenStackEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "OpenStack" 

				$openStackAccount = New-Object PSObject -Property @{
					envType = $envType
					serverAddress = $OpenStackServerUrl
					project = $OpenStackProject
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $openStackAccount 
			}

			"ADEnvironment" {
				$envType = Get-EnvTypeKey -EnvironmentType "AD" 

				$msAdAccount = New-Object PSObject -Property @{
					envType = $envType
					domainName = $DomainName
					ldapSearchPath = $LdapSearchPath
					userName = $UserNameEnv
					password = $PasswordEnv
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $msAdAccount 
			}

			"Custom" {
				$envType = Get-EnvTypeKey -EnvironmentType "Custom"
 
				$customAccount = New-Object PSObject -Property @{
					envType = $envType
					networkDiscoveryRange = [string]::Empty
				}

				$environment | Add-Member -MemberType NoteProperty -Name envType -Value $envType
				$environment | Add-Member -MemberType NoteProperty -Name environmentAccount -Value $customAccount 
			}            
		}        

		$body = ConvertTo-Json $environment
		Write-Verbose $body

		Invoke-DtoMethod "api/environments" $Scheme $HostName -Method Post -Headers $Headers -Body $body -ContentType application/json | % {
			$_.PSTypeNames.Insert(0, "DoubleTake.Dto.Environment")
			$_
		}
	}
}

<#
.SYNOPSIS
	Modifies a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Edit-DtoEnvironment modifies a Double-Take Cloud Migration Center environment. For example, adds a proxy server to the environment.

.PARAMETER Environment
	The environment to edit.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Edit-DtoEnvironment returns the information of the environment that was modified.

.EXAMPLE
	$proxy = Get-DtoProxy | Where-Object {$_.Name -eq "proxyName"}
	$environment = Get-DtoEnvironment | Where-Object {$_.Name -eq "environmentName"}    
	$environment | Add-Member -MemberType NoteProperty -Name proxyId -Value $proxy.Id        
	Edit-DtoEnvironment -Environment $environment
#>
function Edit-DtoEnvironment
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateScript({ Test-DtoEntityType $_ "DoubleTake.Dto.Environment" -Validate })]
		[object]$Environment,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{ 
		$body = ConvertTo-Json $Environment -Depth 5
		Write-Verbose $body

		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path "api/environments/$($Environment.id)" -Method Put -Headers $Headers -Body $body -ContentType application/json
	}
}

<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center environment or all the environments for a specified user.

.DESCRIPTION
	Get-DtoEnvironment gets a specified Double-Take Cloud Migration Center environment or all the environments for a specified user. All the 
	environments for the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The environment ID to get.

.PARAMETER UserId
	The user ID to get the environment list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoEnvironment returns the information of the environment(s).

.EXAMPLE
	Get-DtoEnvironment -Id environmentID

.EXAMPLE    
	Get-DtoEnvironment -UserId userID    
#>
function Get-DtoEnvironment
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$environments = Get-DtoEntity -ControllerName "environments" -EntityTypeName "DoubleTake.Dto.Environment" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
				
		if ($environments)
		{
			ForEach ($env in $environments)
			{                
				$env | Add-Member -MemberType NoteProperty -Name envType -Value $env.environmentAccount.envType
			}            
		}
		
		return $environments
	}
}

<#
.SYNOPSIS
	Removes an environment by environment ID.

.DESCRIPTION
	Remove-DtoEnvironment removes an environment by environment ID.

.PARAMETER Id
	The ID of the environment.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the environment.

.OUTPUTS
	Remove-DtoEnvironment returns the information of the environment removed.

.EXAMPLE
	Remove-DtoEnvironment -Id environmentId
#>
function Remove-DtoEnvironment
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/environments/$Id" $Scheme $HostName -Method Delete -Headers $Headers
	}
}
