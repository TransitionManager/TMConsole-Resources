



<#
.SYNOPSIS
	Gets the virtual networks available for a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Get-DtoVirtualNetwork gets the virtual networks available for the specified Double-Take Cloud Migration Center environment.

.PARAMETER EnvironmentId
	The Environment ID to get the virtual networks for.

.INPUTS
	None.

.OUTPUTS
	Get-DtoVirtualNetwork returns the virtual networks available for the environment.

.EXAMPLE
	Get-DtoVirtualNetwork -EnvironmentId environmentId
#>
function Get-DtoVirtualNetwork
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "environments/$EnvironmentId/virtualNetworks" -EntityTypeName "DoubleTake.Dto.VirtualNetwork" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

<#
.SYNOPSIS
	Gets the direct networks available for a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Get-DtoDirectNetwork gets the direct networks available for the specified Double-Take Cloud Migration Center environment.

.PARAMETER EnvironmentId
	The Environment ID to get the direct networks for.

.INPUTS
	None.

.OUTPUTS
	Get-DtoDirectNetwork returns the direct networks available for the environment.

.EXAMPLE
	Get-DtoDirectNetwork -EnvironmentId environmentId
#>
function Get-DtoDirectNetwork
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "environments/$EnvironmentId/directnetworks" -EntityTypeName "DoubleTake.Dto.DirectNetwork" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}