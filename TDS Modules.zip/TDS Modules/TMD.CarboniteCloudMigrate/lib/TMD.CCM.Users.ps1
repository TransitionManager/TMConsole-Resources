
<#
.SYNOPSIS
	Gets the environment count, server count, and migration count for the specified user id.

.DESCRIPTION
	Get-DtoUserSummary gets the server count of each status (error, warning, ok, unknown), migration count of each status
	(error, warning, running, complete), and the environment count for the specified user id.

.PARAMETER Id
	The user ID to get the information for.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.INPUTS
	None.

.OUTPUTS
	Get-DtoUserSummary returns the environment count, server count, and migration count.

.EXAMPLE
	Get-DtoUserSummary -Id userID
#>
function Get-DtoUserSummary
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme
	)

	Process
	{
		$path = "api/users/{0}/summary" -f $Id
		Invoke-DtoMethod $path $Scheme $HostName
	}
}

<#
.SYNOPSIS
	Registers a user with the Double-Take Cloud Migration Center.

.DESCRIPTION
	Register-DtoUser registers the specified user with the Double-Take Cloud Migration Center. An email is sent to the email address
	for confirmation.

.PARAMETER Credential
	The credential object for the user.

.PARAMETER LastName
	The last name of the user.

.PARAMETER FirstName
	The first name of the user.

.PARAMETER CompanyName
	The company name of the user.

.PARAMETER UserPhoneNumber
	The phone number of the user.

.PARAMETER Country
	The country of the user.

.PARAMETER StateProvince
	The state or province of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.INPUTS
	None.

.OUTPUTS
	Register-DtoUser returns the user information that was registered which includes User ID, email, and the roles the user was registered too.

.EXAMPLE
	Register-DtoUser -Credential credentialObject -LastName lastName -FirstName firstName -CompanyName companyName -UserPhoneNumber userPhoneNumber -Country country -StateProvince stateOrProvince    
#>
function Register-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true)]
		[System.Management.Automation.Credential()]
		$Credential,               

		[Parameter(Mandatory = $true)]
		[string]$LastName,

		[Parameter(Mandatory = $true)]
		[string]$FirstName,

		[Parameter(Mandatory = $true)]
		[string]$CompanyName,

		[Parameter(Mandatory = $true)]
		[string]$UserPhoneNumber,

		[Parameter(Mandatory = $true)]
		[string]$Country,

		[Parameter(Mandatory = $true)]
		[string]$StateProvince, 

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme
	)

	Process
	{

		$content = New-Object PSObject -Property @{
			username = $Credential.UserName
			email = $Credential.UserName
			password = $Credential.GetNetworkCredential().Password
			lastname = $LastName
			firstname = $FirstName
			companyname = $CompanyName
			userphonenumber = $UserPhoneNumber
			country = $Country
			stateprovince = $StateProvince
		}

		$body = ConvertTo-Json $content
		Write-Verbose $body

		$requestBody = ([System.Text.Encoding]::UTF8.GetBytes($body))

		Invoke-RestMethod $(New-DtoUri $Scheme $HostName "api/users/register") -Method Post -Body $requestBody -ContentType "application/json"
	}
}

<#
.SYNOPSIS
	Triggers a forgot password for the specified email with the Double-Take Cloud Migration Center.

.DESCRIPTION
	Invoke-DtoForgotPassword sends an email containing a password reset link to the user email specified.

.PARAMETER Email
	The email of the user to reset the password.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Invoke-DtoForgotPassword -Email userEmail
#>
function Invoke-DtoForgotPassword
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$Email,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme
	)

	Process
	{
		$content = New-Object PSObject -Property @{
			email = $Email
		}

		$body = ConvertTo-Json $content
		Write-Verbose $body

		$requestBody = ([System.Text.Encoding]::UTF8.GetBytes($body))

		Invoke-RestMethod $(New-DtoUri $Scheme $HostName "api/users/forgotPassword") -Method Post -Body $requestBody -ContentType "application/json"
	}
}



<#
.SYNOPSIS
	Gets the specified user(s).

.DESCRIPTION
	Get-DtoUser gets the specified user(s). If no user is specified gets the list of users the authenticated user is authorized to view. If the authenticated user is not in the Admin role,
	only the authenticated user will be returned. If the authenticated user is not in the Admin role and the specified user is not the authenticated user, the call will result in a 403
	(Forbidden) response. An admin switch is available to list all the users. A deleted switch is available to list all the deleted users. The switches are only available to users that are
	members of the admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER Admin
	Switch to get a list of all users.

.PARAMETER Deleted
	Switch to get a list of all the deleted users.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoUser returns the user or the list of users.

.EXAMPLE
	Get-DtoUser -Id userID
#>
function Get-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[object[]]$Id,

		[Parameter()]
		[switch]$Admin,

		[Parameter()]
		[switch]$Deleted,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,        

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		if ($Deleted.IsPresent)
		{
			Get-DtoEntity -ControllerName "admin/deletedUsers" -EntityTypeName "DoubleTake.Dto.User" -EntityId $Id -HostName $HostName -Scheme $Scheme -Headers $Headers
		}
		elseif ($Admin.IsPresent)
		{
			Get-DtoEntity -ControllerName "admin/users" -EntityTypeName "DoubleTake.Dto.User" -EntityId $Id -HostName $HostName -Scheme $Scheme -Headers $Headers
		}
		else
		{
			Get-DtoEntity -ControllerName "users" -EntityTypeName "DoubleTake.Dto.User" -EntityId $Id -HostName $HostName -Scheme $Scheme -Headers $Headers
		}
	}
}

<#
.SYNOPSIS
	Gets a user's settings.

.DESCRIPTION
	Get-DtoUserSettings gets the specified user's settings. The userId specified in the request must match the userId of the logged on user
	or the logged on user must be a member of the admin role to get a user's settings.

.PARAMETER UserId
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoUserSettings returns an array of the specified user's settings.

.EXAMPLE
	Get-DtoUserSettings -UserId userID
#>
function Get-DtoUserSettings
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "settings" -EntityTypeName "DoubleTake.Dto.UserSettings" -HostName $HostName -Scheme $Scheme -Headers $Headers -UserId $UserId
	}
}

<#
.SYNOPSIS
	Deletes the specified user's specified settings.

.DESCRIPTION
	Remove-DtoUserSettings deletes the specified user's specified settings. The userId specified in the request must match the userId of the logged on user
	in order to allow the user's settings to be deleted. Returns 404: Not Found if an unauthorized user attempts to delete a setting for another user.

.PARAMETER UserId
	The ID of the user.

.PARAMETER Name
	The name of the setting.

.PARAMETER SettingsObject
	The array of setting objects.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The user ID, the names of the setting, or an array of setting names. 

.OUTPUTS
	None.

.EXAMPLE
	Remove-DtoUserSettings -UserId userID -Name settingName
#>
function Remove-DtoUserSettings
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[string]$UserId,

		[Parameter(Mandatory = $true, ParameterSetName = "ByName", ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]        
		[string]$Name,

		[Parameter(ParameterSetName = "BySettingsObject", Mandatory = $true)]
		[ValidateScript({ Test-DtoEntityType $_ "DoubleTake.Dto.UserSettings" -Validate })]
		[object[]]$SettingsObject,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		
		switch ($PSCmdlet.ParameterSetName)
		{
			"BySettingsObject" {
				$SettingNames = $SettingsObject | foreach { $_.name }
				$body = ConvertTo-Json @($SettingNames)
			}
			
			"ByName" {
				$body= convertto-Json @($Name)
			}
		}
		
		Write-Verbose $body
		
		$path = "api/users/{0}/settings" -f $UserId
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Delete -Headers $Headers -Body $body -ContentType application/json
	}
}

<#
.SYNOPSIS
	Adds the specified user settings.

.DESCRIPTION
	Add-DtoUserSetting adds the specified user settings. The userId specified in the request must match the userId of the logged on user
	in order to allow the user's settings to be added or changed. Returns 404: Not Found if an unauthorized user attempts to add or change
	a setting for another user.

.PARAMETER UserId
	The ID of the user.

.PARAMETER Name
	The name of the setting.

.PARAMETER Value
	The value of the setting.

.PARAMETER Tag
	The tag of the setting.

.PARAMETER UpdateExisting
	Switch to update an existing setting.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Add-DtoUserSetting -UserId userID -Name settingName -Value settingValue -Tag settingTag
#>
function Add-DtoUserSetting
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$UserId,

		[Parameter(Mandatory = $true)]
		[string]$Name,

		[Parameter(Mandatory = $true)]
		[string]$Value,

		[Parameter()]
		[string]$Tag,

		[Parameter()]
		[switch]$UpdateExisting,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		If ($UpdateExisting.IsPresent)
		{
			$updateExisting = $true
		}
		
		$setting = New-Object PSObject -Property @{
			name = $Name
			value = $Value
			tag = $Tag
			}

		$body = ConvertTo-Json @($setting)
		
		Write-Verbose $body

		$query = "updateExisting={0}" -f $updateExisting
		$path = "api/users/{0}/settings" -f $UserId
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers -Body $body -ContentType application/json -Query $query
	}
}

<#
.SYNOPSIS
	Updates the specified user settings.

.DESCRIPTION
	Edit-DtoUserSettings updates the specified user settings. The userId specified in the request must match the userId of the logged on user
	in order to allow the user's settings to be added or changed. Returns 404: Not Found if an unauthorized user attempts to add or change
	a setting for another user.

.PARAMETER UserId
	The ID of the user.

.PARAMETER UserSettings
	The setting.

.PARAMETER UpdateExisting
	Switch to update an existing setting.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Edit-DtoUserSettings -UserId userID -UserSettings settingsObject -UpdateExisting
#>
function Edit-DtoUserSettings
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$UserId,

		[Parameter(Mandatory = $true, Position = 1)]
		[object]$UserSettings,

		[Parameter()]
		[switch]$UpdateExisting,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		If ($UpdateExisting.IsPresent)
		{
			$updateExisting = $true
		}

		$body = ConvertTo-Json @($UserSettings)
		
		Write-Verbose $body

		$query = "updateExisting={0}" -f $updateExisting
		$path = "api/users/{0}/settings" -f $UserId
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers -Body $body -ContentType application/json -Query $query
	}
}


<#
.SYNOPSIS
	Updates the specified user.

.DESCRIPTION
	Edit-DtoUser updates the specified user. The authenticated user must be the user being modified.

.PARAMETER User
	The users new settings.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The user object.

.OUTPUTS
	Edit-DtoUser returns the users information with the new values.

.EXAMPLE
	Edit-DtoUser -User userObject
#>
function Edit-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
		[ValidateScript({ Test-DtoEntityType $_ "DoubleTake.Dto.User" -Validate })]
		[object]$User,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/users/{0}" -f $User.id
		$body = ConvertTo-Json $User
		Write-Verbose $body
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Put -Headers $Headers -Body $body -ContentType application/json
	}
}

<#
.SYNOPSIS
	Disables the specified user's account.

.DESCRIPTION
	Block-DtoUser disables the specified user's account. The authenticated user must be a member of the Admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The Id of the user.

.OUTPUTS
	None.

.EXAMPLE
	Block-DtoUser -Id userId
#>
function Block-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/users/{0}/actions/lock" -f $Id 
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Enables the specified user's account.

.DESCRIPTION
	Unblock-DtoUser enables the specified user's account. The authenticated user must be a member of the Admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The Id of the user.

.OUTPUTS
	None.

.EXAMPLE
	Unblock-DtoUser -Id userId
#>
function Unblock-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/users/{0}/actions/unlock" -f $Id 
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Triggers a forgot password for the specified user with the Double-Take Cloud Migration Center.

.DESCRIPTION
	Send-DtoUserPasswordReset sends an email containing a password reset link to the user specified. The authenticated user must
	be a member of the Admin role.

.PARAMETER Id
	The ID of the user to reset the password.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the user.

.OUTPUTS
	None.

.EXAMPLE
	Send-DtoUserPasswordReset -Id userId
#>
function Send-DtoUserPasswordReset
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/users/{0}/actions/sendPasswordReset" -f $Id 
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Sends an account confirmation e-mail to the specified user.

.DESCRIPTION
	Send-DtoUserAccountConfirmation sends an account confirmation e-mail to the specified user. The authenticated user must
	be a member of the Admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the user.

.OUTPUTS
	None.

.EXAMPLE
	Send-DtoUserAccountConfirmation -Id userId
#>
function Send-DtoUserAccountConfirmation
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/users/{0}/actions/sendAccountConfirmation" -f $Id 
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers
	}
}

<#
.SYNOPSIS
	Deletes the specified user from the Double-Take Cloud Migration Center.

.DESCRIPTION
	Remove-DtoUser deletes the specified user from the Double-Take Cloud Migration Center. The authenticated user must
	be a member of the Admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER HardDelete
	True or False. Hard delete if True. Default action is a soft delete of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the user.

.OUTPUTS
	None.

.EXAMPLE
	Remove-DtoUser -Id userId
#>
function Remove-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
		[string]$Id,

		[Parameter(Position = 1)]
		[bool]$HardDelete = $false,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/users/{0}/{1}" -f $Id, $HardDelete
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Delete -Headers $Headers
	}
}

<#
.SYNOPSIS
	Restores the specified deleted user's account.

.DESCRIPTION
	Restore-DtoUser restores the specified deleted user's account. The authenticated user must be a member of the Admin role.

.PARAMETER Id
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the user.

.OUTPUTS
	None.

.EXAMPLE
	Restore-DtoUser -Id userId
#>
function Restore-DtoUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipelineByPropertyName = $true, ValueFromPipeline = $true)]
		[string]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/admin/deletedUsers/{0}/actions/restore" -f $Id 
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Post -Headers $Headers
	}
}
