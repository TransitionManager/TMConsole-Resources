<#
.SYNOPSIS
	Gets the virtual machine images available for a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Get-DtoImage gets the virtual machine images available for the specified Double-Take Cloud Migration Center environment.

.PARAMETER EnvironmentId
	The Environment ID to get the virtual machine images for.

.PARAMETER Location
	The Location of the virtual machine image. This is required if the environment type is AzureRM.

.PARAMETER Publisher
	The Publisher of the virtual machine image.  This is required if the environment type is AzureRM.

.PARAMETER Offer
	The Offer name of the virtual machine image.

.PARAMETER Sku
	The Sku of the virtual machine image.

.INPUTS
	None.

.OUTPUTS
	Get-DtoImage returns the virtual machine images available for the environment.

.EXAMPLE
	Get-DtoImage -EnvironmentId environmentId
#>
function Get-DtoImage
{
[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$Location,

		[Parameter()]
		[string]$Publisher,

		[Parameter(DontShow = $true)]
		[string]$Offer,

		[Parameter(DontShow = $true)]
		[string]$Sku,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$environmentType = (Get-DtoEnvironment $EnvironmentId).envType

		if ($environmentType -eq 8) # AzureRM
		{
			if ([string]::IsNullOrWhiteSpace($Location))
			{
				throw "Location is required for Azure RM environment types.  Use Get-DtoRegion for a list of region names."
			}

			if ([string]::IsNullOrWhiteSpace($Publisher))
			{
				throw "Publisher is required for Azure RM environment types."
			}
			
			$query = "location=$Location&publisher=$Publisher&offer=$Offer&sku=$sku"
		
			Return Get-DtoEntity -ControllerName "environments/$EnvironmentId/imagesByFilter" -EntityTypeName "DoubleTake.Dto.TemplateSearchFilterModel" -Query $query -HostName $HostName -Scheme $Scheme -Headers $Headers
		}

		Get-DtoEntity -ControllerName "environments/$EnvironmentId/images" -EntityTypeName "DoubleTake.Dto.Image" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}