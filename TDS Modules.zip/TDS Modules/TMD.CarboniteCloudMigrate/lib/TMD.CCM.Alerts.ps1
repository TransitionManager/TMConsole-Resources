

function New-DtoAlert
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true)]
		[string]$SubjectName,

		[Parameter(Mandatory = $true)]
		[string]$Message,

		[Parameter(Mandatory = $true)]
		[string]$Severity,

		[Parameter(Mandatory = $true)]
		[string]$Category,

		[Parameter(Mandatory = $true)]
		[string]$EntityId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		[System.Collections.IDictionary]$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$AlertObject = New-Object PSObject -Property @{
				SubjectName = $SubjectName
				Message = $Message
				Severity = $Severity
				Category = $Category
				EntityId = $EntityId
			}

			$body = ConvertTo-Json $AlertObject

		Write-Verbose $body

		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path "api/alerts" -Method Post -Headers $Headers -Body $body -ContentType application/json
	}
}




function Get-DtoAlert
{
	[CmdletBinding()]
	Param (
		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		[System.Collections.IDictionary]$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "alerts" -EntityTypeName "DoubleTake.Dto.Alerts" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}


<#
.SYNOPSIS
	Gets the user's alert settings.

.DESCRIPTION
	Get-DtoAlertSettings gets the user's alert settings. If no user is specified, the userId of the logged in user is used.

.PARAMETER UserId
	The ID of the user.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Get-DtoAlertSettings -UserId userId
#>
function Get-DtoAlertSettings
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		if(!$UserId)
		{
			$User = Get-DtoUser
			$UserId = $User.Id
		}

		Get-DtoEntity -ControllerName "alert_settings" -EntityTypeName "DoubleTake.Dto.AlertSettings" -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}


<#
.SYNOPSIS
	Updates the user setting based on object supplied in the settings parameter.

.DESCRIPTION
	Update-DtoAlertSettings updates the user's alert settings. Use Get-DtoAlertSettings to obtain a list of settings. 
	Those settings can be modified and passed into the Settings parameter.

.PARAMETER UserId
	The ID of the user.

.PARAMETER Settings
	The user settings that were modified.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	None.

.EXAMPLE
	Get-DtoAlertSettings -UserId userId
#>
function Update-DtoAlertSettings
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string]$UserId,

		[object]$Settings,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$path = "api/users/$UserId/alert_settings"
		$body = ConvertTo-Json $settings
		Write-Verbose $body
		Invoke-DtoMethod -Scheme $Scheme -HostName $HostName -Path $path -Method Put -Headers $Headers -Body $body -ContentType application/json
	}
}
