<#
.SYNOPSIS
	Lists the discovery related log entries for a Double-Take Cloud Migration Center server.

.DESCRIPTION
	Get-DtoServerDiscoveryLogEntry lists the discovery related log entries for a specified Double-Take Cloud Migration Center server.

.PARAMETER ServerId
	The id of the server.

.PARAMETER LastId
	The last log entry log ID. If used, only log entries after this ID will be retrieved.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoServerDiscoveryLogEntry returns the log entry list.

.EXAMPLE
	Get-DtoServerDiscoveryLogEntry -ServerId serverId -LastId lastLogEntryLogID
#>
function Get-DtoServerDiscoveryLogEntry
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[int]$ServerId,

		[Parameter()]
		[int]$LastId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$controllerName = "servers/$ServerId/discoveryLog"
		[string]$query = $null

		if ($PSCmdlet.MyInvocation.BoundParameters.ContainsKey("LastId"))
		{
			$query = "lastId=$LastId"
		}

		Get-DtoEntity -ControllerName $controllerName -EntityTypeName "DoubleTake.Dto.DiscoveryTaskLogEntry" -Query $query -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}



<#
.SYNOPSIS
	Creates a discovery task on the environment

.DESCRIPTION
	New-DtoDiscoveryTask creates a discovery task on the specified environment.

.PARAMETER EnvironmentId
	The ID of the environment.

.PARAMETER Region
	The region.

.PARAMETER ServerId
	The ID of the server(s).

.PARAMETER Credential
	The discovery credentials.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the environment.

.OUTPUTS
	New-DtoDiscoveryTask returns the information on the newly created discovery task.

.EXAMPLE
	New-DtoDiscoveryTask -EnvironmentId environmentId -Credential discoveryCredential
#>
function New-DtoDiscoveryTask
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$Region,

		[Parameter()]
		[int[]]$ServerId,

		[Parameter(Mandatory = $true)]
		[System.Management.Automation.Credential()]
		$Credential,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$content = New-Object PSObject
		if ($Region -ne $null)
		{
			$content | Add-Member region $Region
		}

		if (($ServerId -ne $null) -and ($ServerId.Length -gt 0))
		{
			$content | Add-Member -MemberType NoteProperty -Name serverIds -Value $ServerId
		}

		if ($Credential -ne $null)
		{
			$serverCredential = New-Object PSObject -Property @{
				userName = $Credential.UserName
				password = $Credential.GetNetworkCredential().Password
			}
			$content | Add-Member -MemberType NoteProperty -Name serverCredential -Value $serverCredential
		}

		$body = ConvertTo-Json $content
		Write-Verbose $body

		Invoke-DtoMethod "api/environments/$EnvironmentId/discoveryTasks" $Scheme $HostName -Method Post -Headers $Headers -ContentType application/json -Body $body
	}
}


<#
.SYNOPSIS
	Creates a discovery only task on the environment

.DESCRIPTION
	New-DtoDiscoveryOnlyTask creates a discovery task on the specified environment.

.PARAMETER EnvironmentId
	The ID of the environment.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the environment.

.OUTPUTS
	New-DtoDiscoveryTask returns the information on the newly created discovery task.

.EXAMPLE
	New-DtoDiscoveryTask -EnvironmentId environmentId -Credential discoveryCredential
#>
function New-DtoDiscoveryOnlyTask
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$content = New-Object PSObject
		$content | Add-Member inventoryServers $false

		$body = ConvertTo-Json $content
		Write-Verbose $body

		Invoke-DtoMethod "api/environments/$EnvironmentId/discoveryTasks" $Scheme $HostName -Method Post -Headers $Headers -ContentType application/json -Body $body
	}
}

<#
.SYNOPSIS
	Runs the inventory operation on a server.

.DESCRIPTION
	Invoke-DtoServerInventory runs the inventory operation on the specified server.

.PARAMETER Id
	The ID of the server.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	The ID of the server.

.OUTPUTS
	Invoke-DtoServerInventory returns the result of the inventory operation.

.EXAMPLE
	Invoke-DtoServerInventory -Id serverId
#>
function Invoke-DtoServerInventory
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
		[int]$Id,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Invoke-DtoMethod "api/servers/$Id/inventory" $Scheme $HostName -Method Post -Headers $Headers
	}
}
