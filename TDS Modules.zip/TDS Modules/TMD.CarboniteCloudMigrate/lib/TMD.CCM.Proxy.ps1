
<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center proxy or all the proxies for a user.

.DESCRIPTION
	Get-DtoProxy gets a specified Double-Take Cloud Migration Center proxy or all the proxies belonging to a specified user.
	All the proxies for the authenticated user is returned if nothing is supplied.

.PARAMETER Id
	The proxy ID to get.

.PARAMETER UserId
	The user ID to get the proxy list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoProxy returns the proxy list.

.EXAMPLE
	Get-DtoProxy -Id proxyID

.EXAMPLE    
	Get-DtoProxy -UserId userID    
#>
function Get-DtoProxy
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[string]$Id,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "proxies" -EntityTypeName "DoubleTake.Dto.Proxy" -EntityId $Id -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}
