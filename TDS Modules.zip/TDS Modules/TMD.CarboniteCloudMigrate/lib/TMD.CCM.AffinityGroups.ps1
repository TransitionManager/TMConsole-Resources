

<#
.SYNOPSIS
	Gets the affinity groups for a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Get-DtoAffinityGroup gets the affinity groups for the specified Double-Take Cloud Migration Center environment.

.PARAMETER EnvironmentId
	The Environment ID to get the affinity groups for.

.INPUTS
	None.

.OUTPUTS
	Get-DtoAffinityGroup returns the affinity group(s) for the environment.

.EXAMPLE
	Get-DtoAffinityGroup -EnvironmentId environmentId
#>
function Get-DtoAffinityGroup
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "environments/$EnvironmentId/affinityGroups" -EntityTypeName "DoubleTake.Dto.AffinityGroup" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}
