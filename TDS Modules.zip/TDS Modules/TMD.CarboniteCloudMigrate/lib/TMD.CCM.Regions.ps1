
<#
.SYNOPSIS
	Gets the regions for a Double-Take Cloud Migration Center environment.

.DESCRIPTION
	Get-DtoRegion gets the regions for the specified Double-Take Cloud Migration Center environment.

.PARAMETER EnvironmentId
	The Environment ID to get the regions for.

.INPUTS
	None.

.OUTPUTS
	Get-DtoRegion returns the region(S) for the environment.

.EXAMPLE
	Get-DtoRegion -EnvironmentId environmentId
#>
function Get-DtoRegion
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$EnvironmentId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "environments/$EnvironmentId/regions" -EntityTypeName "DoubleTake.Dto.Region" -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}
