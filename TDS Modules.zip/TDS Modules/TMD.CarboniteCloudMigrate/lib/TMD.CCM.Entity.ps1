
function Test-DtoEntityType
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true)]
		[object]$Entity,

		[Parameter(Mandatory = $true, Position = 1)]
		[string]$TypeName,

		[Parameter()]
		[switch]$Validate
	)

	Process
	{
		$memberInfo = $Entity | Get-Member | select -First 1
		if ($memberInfo.TypeName -eq $TypeName)
		{
			$true
		}
		elseif ($Validate.IsPresent)
		{
			throw "The value must have type $TypeName, but instead has type $($memberInfo.TypeName)."
		}
		else
		{
			$false
		}
	}
}

function Get-DtoEntity
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[string]$ControllerName,

		[Parameter(Mandatory = $true, Position = 1)]
		[string]$EntityTypeName,

		[Parameter()]
		[object[]]$EntityId,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$Query,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		[System.Collections.IDictionary]$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		if ($UserId)
		{
			$controllerPath = "api/users/$UserId/$ControllerName"
		}
		else
		{
			$controllerPath = "api/$ControllerName"
		}

		if ($EntityId)
		{
			$EntityId | % {
				Invoke-DtoMethod "$controllerPath/$_" $Scheme $HostName -Query $Query -Headers $Headers
			} | % {
				$_.PSTypeNames.Insert(0, $EntityTypeName)
				$_
			}
		}
		else
		{
			Invoke-DtoMethod $controllerPath $Scheme $HostName -Query $Query -Headers $Headers | % { $_ } | % {
				$_.PSTypeNames.Insert(0, $EntityTypeName)
				$_
			}
		}
	}
}
