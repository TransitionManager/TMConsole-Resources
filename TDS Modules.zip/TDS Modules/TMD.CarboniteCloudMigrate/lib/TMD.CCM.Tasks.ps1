<#
.SYNOPSIS
	Gets a Double-Take Cloud Migration Center discovery task or all the discovery tasks for a user.

.DESCRIPTION
	Get-DtoDiscoveryTask gets a specified Double-Take Cloud Migration Center discovery task or all the discovery tasks belonging to a specified user.
	All the discovery tasks for the authenticated user is returned if nothing is supplied.

.PARAMETER TaskId
	The discovery task ID to get.

.PARAMETER UserId
	The user ID to get the discovery task list.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoDiscoveryTask returns the discovery task(s).

.EXAMPLE
	Get-DtoDiscoveryTask -TaskId discoveryTaskID

.EXAMPLE    
	Get-DtoDiscoveryTask -UserId userID    
#>
function Get-DtoDiscoveryTask
{
	[CmdletBinding()]
	Param (
		[Parameter(Position = 0)]
		[int]$TaskId,

		[Parameter()]
		[string]$UserId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		Get-DtoEntity -ControllerName "discoveryTasks" -EntityTypeName "DoubleTake.Dto.DiscoveryTask" -EntityId $TaskId -UserId $UserId -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}

<#
.SYNOPSIS
	Lists log entries for a Double-Take Cloud Migration Center discovery task. Can be filtered for a specific server.

.DESCRIPTION
	Get-DtoDiscoveryTaskLogEntry lists the log entries for a specified Double-Take Cloud Migration Center discovery task. The log entries can
	be filtered for a specific server.

.PARAMETER DiscoveryTaskId
	The discovery task ID to get the log entry list.

.PARAMETER ServerId
	The id of the server for which the log entries will be filtered.

.PARAMETER LastId
	The last log entry log ID. If used, only log entries after this ID will be retrieved.

.PARAMETER HostName
	The DNS name of the API hosting server.

.PARAMETER Scheme
	The Scheme to use. http or https

.PARAMETER Headers
	The headers of the web request.

.INPUTS
	None.

.OUTPUTS
	Get-DtoDiscoveryTaskLogEntry returns the log entry list.

.EXAMPLE
	Get-DtoDiscoveryTaskLogEntry -DiscoveryTaskId discoveryTaskId -ServerId serverId -LastId lastLogEntryLogID
#>
function Get-DtoDiscoveryTaskLogEntry
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[int]$DiscoveryTaskId,

		[Parameter()]
		[int]$ServerId,

		[Parameter()]
		[int]$LastId,

		[Parameter()]
		[string]$HostName = $global:DtDefaultHostName,

		[Parameter()]
		[ValidateSet("http", "https")]
		[string]$Scheme = $global:DtDefaultScheme,

		[Parameter()]
		$Headers = $(Get-DtoCurrentHeader)
	)

	Process
	{
		$controllerName = "discoveryTasks/$DiscoveryTaskId/log"
		[string]$query = $null
		if ($PSCmdlet.MyInvocation.BoundParameters.ContainsKey("ServerId"))
		{
			$query = "serverId=$ServerId"
		}

		if ($PSCmdlet.MyInvocation.BoundParameters.ContainsKey("LastId"))
		{
			if (![string]::IsNullOrEmpty($query))
			{
				$query = $query + "&"
			}

			$query = $query + "lastId=$LastId"
		}

		Get-DtoEntity -ControllerName $controllerName -EntityTypeName "DoubleTake.Dto.DiscoveryTaskLogEntry" -Query $query -HostName $HostName -Scheme $Scheme -Headers $Headers
	}
}
