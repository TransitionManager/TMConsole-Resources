
#Import Batches
Function Get-TMImportBatch {
	param(
		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $false)][int]$BatchId,
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL
	)

	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	## Construct the server URI
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')
	
	## Check version 5
	if ($global:TMSessions[$TMSession].TMVersion -like '5*') {

		$uri = "https://$Instance/tdstm/ws/import/batches"
	}
	## Get the version 4 URI
	else {
		$uri = "https://$Instance/tdstm/module/importbatch/$($BatchId ? $BatchId : "list")"

	}

	## Attempt the Request
	try {
		$response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
		if ($response.StatusCode -eq 200) {
			$Result = ($response.Content | ConvertFrom-Json).data
		}
		return , @($Result)
	}
	catch {
		throw $_
	}
}

#Import Batch Records
Function Get-TMImportBatchRecord {
	param(
		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $true)][int]$BatchId,
		[Parameter(Mandatory = $false)][int]$RecordId,
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL
	)
	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	## Construct the server URI
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')
	
	## Check version 5
	if ($global:TMSessions[$TMSession].TMVersion -like '5*') {

		if (-not $RecordId) {

			## Get a List of the records if no specific record was requested
			$uri = "https://$Instance/tdstm/ws/import/batch/$($BatchId)/records"
		}
		else {
			## Get a specific record
			$uri = "https://$Instance/tdstm/ws/import/batch/$($BatchId)/record/$($RecordId)"

		}
	}
	else {

		## TODO  Get the 4.7 Web Service URI for this
		$uri = "https://$Instance/tdstm/module/importbatch/$($BatchId ? $BatchId : "list")"

	}

	## Attempt the Request
	try {
		$response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
		if ($response.StatusCode -eq 200) {
			$Result = ($response.Content | ConvertFrom-Json).data
		}
		return $Result
	}
	catch {
		throw $_
	}
}

