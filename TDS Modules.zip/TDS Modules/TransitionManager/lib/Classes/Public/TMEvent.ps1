
class TMEvent {
	$id = $null
	[String]$name
	[String]$description       
	[Int[]]$moveBundle        
	[String]$runbookStatus     
	[String]$runbookBridge1    
	[String]$runbookBridge2    
	[String]$videolink         
	[String]$estStartTime      
	[String]$estCompletionTime 
	[Bool]$apiActionBypass = $false

	## Constructor 1: Name Alone
	TMEvent ([String]$_name) {
		$this.name = $_name
	}
	
	## Constructor 2: Name, Description
	TMEvent ([String]$_name, [String]$_description) {
		$this.name = $_name
		$this.description = $_description
	}
	
	## Constructor 3: PSCustomObject
	TMEvent ([PSCustomObject]$_tmeventpscustomobject) {
		
		$this.id = $_tmeventpscustomobject.id ?? $null
		$this.name = $_tmeventpscustomobject.name
		$this.description = $_tmeventpscustomobject.description
		$this.moveBundle = $_tmeventpscustomobject.moveBundle
		$this.runbookStatus = $_tmeventpscustomobject.runbookStatus
		$this.runbookBridge1 = $_tmeventpscustomobject.runbookBridge1
		$this.runbookBridge2 = $_tmeventpscustomobject.runbookBridge2
		$this.videolink = $_tmeventpscustomobject.videoLink
		$this.estStartTime = $_tmeventpscustomobject.estStartTime
		$this.estCompletionTime = $_tmeventpscustomobject.estCompletionTime
		$this.apiActionBypass = $_tmeventpscustomobject.apiActionBypass ?? $false
	}
	
	## Constructor 4: Hashtable
	TMEvent ([Hashtable]$_tmeventhashtable) {
		
		$this.id = $_tmeventhashtable.id ?? $null
		$this.name = $_tmeventhashtable.name
		$this.description = $_tmeventhashtable.description
		$this.moveBundle = $_tmeventhashtable.moveBundle
		$this.runbookStatus = $_tmeventhashtable.runbookStatus
		$this.runbookBridge1 = $_tmeventhashtable.runbookBridge1
		$this.runbookBridge2 = $_tmeventhashtable.runbookBridge2
		$this.videolink = $_tmeventhashtable.videoLink
		$this.estStartTime = $_tmeventhashtable.estStartTime
		$this.estCompletionTime = $_tmeventhashtable.estCompletionTime
		$this.apiActionBypass = $_tmeventhashtable.apiActionBypass ?? $false
	}
}