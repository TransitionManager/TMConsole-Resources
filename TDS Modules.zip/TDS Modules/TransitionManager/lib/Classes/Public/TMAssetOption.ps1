class TMAssetOption {
	[Int]$id
	[String]$label

	TMAssetOption() {}

	TMAssetOption([String]$_label) {
		$this.label = $_label
	}

	TMAssetOption([Int]$_id, [String]$_label) {
		$this.id = $_id
		$this.label = $_label
	}

	static [TMAssetOption[]]Get() {
		return (Get-TMAssetOption)
	}

	static [TMAssetOption[]]Get([String]$_tmSession) {
		return (Get-TMAssetOption -TMSession $_tmSession)
	}

	static [TMAssetOption[]]Get([String]$_tmSession, [String]$_type) {
		return (Get-TMAssetOption -TMSession $_tmSession -Type $_type)
	}

	static [TMAssetOption]Get([String]$_tmSession, [String]$_type, [String]$_name) {
		return (Get-TMAssetOption -TMSession $_tmSession -Type $_type -Name $_name)
	}

    [void]Create() {
        New-TMAssetOption -InputObject $this
    }

    [void]Create([String]$_tmSession) {
        New-TMAssetOption -TMSession $_tmSession -InputObject $this
    }

    [void]Delete() {
        Remove-TMAssetOption -InputObject $this
    }

    [void]Delete([String]$_tmSession) {
        Remove-TMAssetOption -TMSession $_tmSession -InputObject $this
    }
}


class TMAssetEnvironment : TMAssetOption {
	TMAssetEnvironment([String]$_name) : base($_name) {}

	TMAssetEnvironment([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMAssetEnvironment[]]Get() {
		return [TMAssetOption]::Get('Default', 'Asset Environment')
	}

	static [TMAssetEnvironment[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Environment')
	}

	static [TMAssetEnvironment]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Environment', $_name)
	}
}


class TMAssetPlanStatus : TMAssetOption {
	TMAssetPlanStatus([String]$_name) : base($_name) {}

	TMAssetPlanStatus([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMAssetPlanStatus[]]Get() {
		return [TMAssetOption]::Get('Default', 'Asset Plan Status')
	}

	static [TMAssetPlanStatus[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Plan Status')
	}

	static [TMAssetPlanStatus]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Plan Status', $_name)
	}
}


class TMAssetPriority : TMAssetOption {
	TMAssetPriority([String]$_name) : base($_name) {}

	TMAssetPriority([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMAssetPriority[]]Get() {
		return [TMAssetOption]::Get('Default', 'Asset Priority')
	}

	static [TMAssetPriority[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Priority')
	}

	static [TMAssetPriority]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Priority', $_name)
	}
}


class TMDependencyType : TMAssetOption {
	TMDependencyType([String]$_name) : base($_name) {}

	TMDependencyType([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMDependencyType[]]Get() {
		return [TMAssetOption]::Get('Default', 'Dependency Type')
	}

	static [TMDependencyType[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Dependency Type')
	}

	static [TMDependencyType]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Dependency Type', $_name)
	}
}


class TMDependencyStatus : TMAssetOption {
	TMDependencyStatus([String]$_name) : base($_name) {}

	TMDependencyStatus([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMDependencyStatus[]]Get() {
		return [TMAssetOption]::Get('Default', 'Dependency Status')
	}

	static [TMDependencyStatus[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Dependency Status')
	}

	static [TMDependencyStatus]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Dependency Status', $_name)
	}
}


class TMAssetType : TMAssetOption {
	TMAssetType([String]$_name) : base($_name) {}

	TMAssetType([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMAssetType[]]Get() {
		return [TMAssetOption]::Get('Default', 'Asset Type')
	}

	static [TMAssetType[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Type')
	}

	static [TMAssetType]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Asset Type', $_name)
	}
}


class TMTaskCategory : TMAssetOption {
	TMTaskCategory([String]$_name) : base($_name) {}

	TMTaskCategory([Int]$_id, [String]$_name) : base($_id, $_name) {}

	static [TMTaskCategory[]]Get() {
		return [TMAssetOption]::Get('Default', 'Task Category')
	}

	static [TMTaskCategory[]]Get([String]$_tmSession) {
		return [TMAssetOption]::Get($_tmSession, 'Task Category')
	}

	static [TMTaskCategory]Get([String]$_tmSession, [String]$_name) {
		return [TMAssetOption]::Get($_tmSession, 'Task Category', $_name)
	}
}
