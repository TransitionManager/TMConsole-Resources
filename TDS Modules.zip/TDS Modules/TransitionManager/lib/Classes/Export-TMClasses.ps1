Get-ChildItem -Path "$($PSScriptRoot)\Public" -Recurse -Filter "*.ps1" | ForEach-Object {
	. "$($_.FullName)"
}