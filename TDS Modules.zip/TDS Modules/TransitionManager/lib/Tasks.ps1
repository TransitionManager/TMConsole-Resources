

## Tasks
Function Get-TMTasks {
	[CmdletBinding(DefaultParameterSetName = 'EventName')]
	param(
		[Parameter(Mandatory = $false, ParameterSetName = 'EventName')][String]$EventName,
		[Parameter(Mandatory = $false, ParameterSetName = 'EventId')][Int]$EventId,
		[Parameter(Mandatory = $false)][Switch]$JustMine = $false,
		[Parameter(Mandatory = $false)][Switch]$JustActionalble = $false,
		[Parameter(Mandatory = $false)][String]$TMSession = "Default",
		[Parameter(Mandatory = $false)][String]$Server = $global:TMSessions[$TMSession].TMServer,
		[Parameter(Mandatory = $false)]$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,
		[Parameter(Mandatory = $false)][int]$ProjectId = $global:TMSessions[$TMSession].UserContext.project.id
	)

	Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"



	## Get Session Configuration
	$TMSessionConfig = $global:TMSessions[$TMSession]
	if (-not $TMSessionConfig) {
		Write-Host 'TMSession: [' -NoNewline
		Write-Host $TMSession -ForegroundColor Cyan
		Write-Host '] was not Found. Please use the New-TMSession command.'
		Throw "TM Session Not Found.  Use New-TMSession command before using features."
	}

	#Honor SSL Settings
	if ($TMSessionConfig.AllowInsecureSSL) {
		$TMCertSettings = @{SkipCertificateCheck = $true }
	}
 	else { 
		$TMCertSettings = @{SkipCertificateCheck = $false }
	}

	# Write-Host "Getting TM Tasks - Just Mine: " $JustMine ", Just Actionable: " $JustActionalble
	$instance = $Server.Replace('/tdstm', '')
	$instance = $instance.Replace('https://', '')
	$instance = $instance.Replace('http://', '')
	
	$uri = "https://"
	$uri += $instance
	$uri += '/tdstm/ws/task'
	
	if ($JustMine) { $justMyTasks = 1 } else { $justMyTasks = 0 }
	$uri += '?justMyTasks=' + $justMyTasks
	
	if ($JustActionalble) { $vJustActionalble = 1 } else { $vJustActionalble = 0 }
	$uri += '&justActionable=' + $vJustActionalble
	
	## Resolve the Project and Event ID
	if ($PSCmdlet.ParameterSetName -eq 'EventName') {
		$EventId = Get-TMEvent -Name $EventName | Select-Object -ExpandProperty id
	}

	## Supply the Project and Move Event
	$uri += '&project=' + $ProjectId
	$uri += '&moveEvent=' + $EventId

	try {
		$Response = Invoke-WebRequest -Method Get -Uri $uri -WebSession $TMSessionConfig.TMWebSession @TMCertSettings
	}
	catch {
		return $_
	}

	if ($Response.StatusCode -eq 200) {
		$ContentJson = $Response.Content | ConvertFrom-Json
		$ContentJson.data
	}
}