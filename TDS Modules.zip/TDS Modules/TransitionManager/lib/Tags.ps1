function Get-TMTag {
	<#
    .SYNOPSIS
    Gets a Tag from TransitionManager
    
    .DESCRIPTION
    This function will retrieve one or more Tags from TransitionManager by name or Id
    
    .PARAMETER TMSession
    The name of the TM Session to use when retrieving a Tag
    
    .PARAMETER Server
    The URI of the TransitionManager instance
    
    .PARAMETER AllowInsecureSSL
    Switch indicating that insecure SSL may be used
    
    .PARAMETER ResetIDs
    Switch indicating that the Tag(s) should be returned without Id's
	
    .PARAMETER Name
    The name of the Tag to be retrieved
    
    .PARAMETER Id
    The Id of the Tag to be retrieved
    
    .EXAMPLE
    Get-TMTag -TMSession 'TMDDEV' -Name 'TestTag'

	.EXAMPLE
    $AllTags = Get-TMTag -TMSession 'TMDDEV'

	.EXAMPLE
    Get-TMTag -TMSession 'TMDDEV' -Id @(123, 546, 23)
    
    .OUTPUTS
    TMTag object representing the Tag in TransitionManager
	#>
	
	[CmdletBinding(DefaultParameterSetName = 'ByName')]
	param (
		[Parameter(Mandatory = $false)]
		[String]$TMSession = "Default",

		[Parameter(Mandatory = $false)]
		[String]$Server = $global:TMSessions[$TMSession].TMServer,

		[Parameter(Mandatory = $false)]
		$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,

		[Parameter(Mandatory = $false)]
		[Switch]$ResetIDs,

		[Parameter(Mandatory = $false, 
			Position = 0, 
			ValueFromPipeline = $true, 
			ParameterSetName = 'ByName')]
		[String[]]$Name,

		[Parameter(Mandatory = $false, 
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ById')]
		[Int[]]$Id
	)

	begin {
		Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

		## Get Session Configuration
		$TMSessionConfig = $global:TMSessions[$TMSession]
		if (-not $TMSessionConfig) {
			Write-Host 'TMSession: [' -NoNewline
			Write-Host $TMSession -ForegroundColor Cyan
			Write-Host '] was not Found. Please use the New-TMSession command.'
			Throw "TM Session Not Found.  Use New-TMSession command before using features."
		}

		# Format the request parameters
		$Instance = $Server.Replace('/tdstm', '').Replace('https://', '').Replace('http://', '')
		$Uri = "https://$Instance/tdstm/ws/tag"

		Set-TMHeaderAccept -TMSession $TMSession -Accept 'JSON'

		$WebRequestSplat = @{
			Method               = 'GET'
			Uri                  = $Uri
			WebSession           = $TMSessionConfig.TMWebSession
			SkipCertificateCheck = $AllowInsecureSSL
		}

		# Make the request
		try {
			Write-Verbose "Web Request Parameters:"
			Write-Verbose ($WebRequestSplat | ConvertTo-Json -Depth 10)
			Write-Verbose "Invoking web request"
			$Response = Invoke-WebRequest @WebRequestSplat
			Write-Verbose "Response status code: $($Response.StatusCode)"
			Write-Verbose "Response Content: $($Response.Content)"
		}
		catch {
			throw $_
		}

		if ($Response.StatusCode -eq 200) {
			$Result = ($Response.Content | ConvertFrom-Json -Depth 10).data
		}
		else {
			throw "Couldn't get tag(s)"
		}
	}
	
	process {

		# Filter the results by the Name(s) passed in
		if ($Name) {
			$Result = $Result | Where-Object name -in $Name
		}

		# Filter the results by the ID(s) passed in
		if ($Id) {
			$Result = $Result | Where-Object id -in $Id
		}

		# Remove thew IDs if the ResetIDs switch was passed
		if ($ResetIDs) {
			for ($i = 0; $i -lt $Result.Count; $i++) {
				$Result[$i].id = $null
			}
		}

		$Result | ForEach-Object {
			[TMTag]::new($_.id, $_.name, $_.description, $_.color)
		}
	}
}


function New-TMTag {
	<#
    .SYNOPSIS
    Creates a new Tag in TransitionManager
    
    .DESCRIPTION
    This function will create a new Tag in TransitionManager
    
    .PARAMETER TMSession
    The name of the TM Session to use when creating a Tag
    
    .PARAMETER Server
    The URI of the TransitionManager instance
    
    .PARAMETER AllowInsecureSSL
    Switch indicating that insecure SSL may be used
    
    .PARAMETER Name
    The name of the Tag to be created
    
    .PARAMETER Description
    The new Tag's description
	
	.PARAMETER Color
	The color of the Tag to be created
	
    .PARAMETER InputObject
    A TMTag object representing the Tag to be created
	
    .PARAMETER Passthru
    Switch indicating that the new Tag should be returned after creation
	
	.EXAMPLE
	$NewTagSplat = @{
		Name = 'VM'
		Description = "This asset is a virtual machine"
		Color = 'Blue'
		TMSession = 'TMDDEV'
		Passthru = $true
	}
	New-TMTag @NewTagSplat

	.EXAMPLE
	New-TMSession -Credential $Credential -Server 'tmddev.transitionmanager.net' -AllowInsecureSSL $true -SessionName 'TMDDEV'
	New-TMSession -Credential $Credential -Server 'tmddev2.transitionmanager.net' -AllowInsecureSSL $true -SessionName 'TMDDEV2'
	Get-TMTag -TMSession TMDDEV2 | New-TMTag -TMSession TMDDEV -Passthru
	
	.OUTPUTS
    If Passthru switch is used, a TMTag object representing the created Tag. Otherwise, none
	#>

	[CmdletBinding(DefaultParameterSetName = 'ByProperty')]
	param (
		[Parameter(Mandatory = $false)]
		[String]$TMSession = "Default",

		[Parameter(Mandatory = $false)]
		[String]$Server = $global:TMSessions[$TMSession].TMServer,

		[Parameter(Mandatory = $false)]
		$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,

		[Parameter(Mandatory = $false,
			Position = 0,
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ByProperty')]
		[String]$Name,

		[Parameter(Mandatory = $false, 
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ByProperty')]
		[String]$Description = "",

		[Parameter(Mandatory = $false, 
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ByProperty')]
		[ArgumentCompleter({ [TMTag]::ValidColors })]
		[ValidateScript( { $_ -in [TMTag]::ValidColors } )]
		[String]$Color = "Grey",

		[Parameter(Mandatory = $true, 
			ParameterSetName = 'ByObject')]
		[TMTag]$InputObject,

		[Parameter(Mandatory = $false)]
		[Switch]$Passthru
	)

	begin {
		Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

		## Get Session Configuration
		$TMSessionConfig = $global:TMSessions[$TMSession]
		if (-not $TMSessionConfig) {
			Write-Host 'TMSession: [' -NoNewline
			Write-Host $TMSession -ForegroundColor Cyan
			Write-Host '] was not Found. Please use the New-TMSession command.'
			Throw "TM Session Not Found.  Use New-TMSession command before using features."
		}

		# Format the request parameters
		$Instance = $Server.Replace('/tdstm', '').Replace('https://', '').Replace('http://', '')
		$Uri = "https://$Instance/tdstm/ws/tag"

		Set-TMHeaderAccept -TMSession $TMSession -Accept 'Any'
		Set-TMHeaderContentType -TMSession $TMSession -ContentType 'JSON'

		$WebRequestSplat = @{
			Method               = 'POST'
			Uri                  = $Uri
			WebSession           = $TMSessionConfig.TMWebSession
			SkipCertificateCheck = $AllowInsecureSSL
			Body                 = ""
		}
	}

	process {

		$TagsToAdd = [System.Collections.ArrayList]::new()

		# Format the object to be sent to TM
		switch ($PSCmdlet.ParameterSetName) {
			'ByObject' {
				foreach ($Object in $InputObject) {
					if ([String]::IsNullOrWhiteSpace($Object.Name)) {
						Write-Error "InputObject does not have a 'Name' property"
						return
					}

					[void]$TagsToAdd.Add([TMTag]::new($Object.Name, $Object.Description, $Object.Color))
				}
			}

			'ByProperty' {
				[void]$TagsToAdd.Add([TMTag]::new($Name, $Description, $Color))
			}
		}

		# Process each of the tags to add
		foreach ($Tag in $TagsToAdd) {

			# Make sure the tag doesn't already exist
			$TagCheck = Get-TMTag -TMSession $TMSession -Name $Tag.Name
			if ($TagCheck) {
				if ($Passthru) {
					$TagCheck
				}
				return
			}

			# Make sure the color is valid
			if ($Tag.Color -notin [TMTag]::ValidColors) {
				Write-Verbose "Tag '$($Tag.Name)' did not have a valid color, so it has been set to Grey"
				$Tag.Color = 'Grey'
			}
	
			# Format the body of the request
			$WebRequestSplat.Body = ($Tag | ConvertTo-Json -Compress)

			# Make the request
			try {
				Write-Verbose "Web Request Parameters:"
				Write-Verbose ($WebRequestSplat | ConvertTo-Json -Depth 10)
				Write-Verbose "Invoking web request"
				$Response = Invoke-WebRequest @WebRequestSplat
				Write-Verbose "Response status code: $($Response.StatusCode)"
				Write-Verbose "Response Content: $($Response.Content)"
			}
			catch {
				throw $_
			}
	
			if ($Response.StatusCode -eq 200) {
				if ($Passthru) {
					try {
						New-Object TMTag -Property ($Response.Content | ConvertFrom-Json).data
					}
					catch {
						Get-TMTag -TMSession $TMSession -Name $Name
					}
				}
			}
			elseif ($Response.StatusCode -eq 204) {
				if ($Passthru) {
					Get-TMTag -TMSession $TMSession -Name $Name
				}
			}
			else {
				Write-Error "Tag '$Name' could not be created"
			}
		}
	}
}


function Remove-TMTag {
	<#
    .SYNOPSIS
    Removes a Tag from TransitionManager
    
    .DESCRIPTION
    This function will remove a Tag in TransitionManager by Name or Id
    
    .PARAMETER TMSession
    The TransitionManager session to be used when deleting a Tag
    
    .PARAMETER Server
    The URI of the TransitionManager instance
    
    .PARAMETER AllowInsecureSSL
    Switch indicating that insecure SSL may be used
    
    .PARAMETER Name
    The name of the Tag to be removed
    
    .PARAMETER Id
    The Id of the Tag to be removed
	
	.EXAMPLE
	Get-TMTag -TMSession TMDDEV | Remove-TMTag -TMSession TMDDEV

	.EXAMPLE
	Remove-TMTag -Name 'Tag1', 'Tag2'

	.EXAMPLE
	Remove-TMTag -Id 489
	
    .OUTPUTS
    None
	#>

	[CmdletBinding(DefaultParameterSetName = 'ByName')]
	param (
		[Parameter(Mandatory = $false)]
		[String]$TMSession = "Default",

		[Parameter(Mandatory = $false)]
		[String]$Server = $global:TMSessions[$TMSession].TMServer,

		[Parameter(Mandatory = $false)]
		$AllowInsecureSSL = $global:TMSessions[$TMSession].AllowInsecureSSL,

		[Parameter(Mandatory = $false, 
			Position = 0, 
			ParameterSetName = 'ByName')]
		[String[]]$Name,

		[Parameter(Mandatory = $false, 
			ValueFromPipelineByPropertyName = $true, 
			ParameterSetName = 'ById')]
		[Int[]]$Id
	)

	begin {
		Write-Verbose "ParameterSet = $($PSCmdlet.ParameterSetName)"

		## Get Session Configuration
		$TMSessionConfig = $global:TMSessions[$TMSession]
		if (-not $TMSessionConfig) {
			Write-Host 'TMSession: [' -NoNewline
			Write-Host $TMSession -ForegroundColor Cyan
			Write-Host '] was not Found. Please use the New-TMSession command.'
			Throw "TM Session Not Found.  Use New-TMSession command before using features."
		}

		# Format the request parameters
		$Instance = $Server.Replace('/tdstm', '').Replace('https://', '').Replace('http://', '')

		Set-TMHeaderAccept -TMSession $TMSession -Accept 'Any'
	}

	process {
		$IDsToRemove = [System.Collections.ArrayList]::new()
		switch ($PSCmdlet.ParameterSetName) {
			'ByName' {
				(Get-TMTag -TMSession $TMSession -Name $Name).id | ForEach-Object {
					[void]$IDsToRemove.Add($_)
				}
			}
			'ById' { 
				$Id | ForEach-Object {
					[void]$IDsToRemove.Add($_)
				}
			}
		}

		foreach ($TagId in $IDsToRemove) {
			$WebRequestSplat = @{
				Method               = 'DELETE'
				Uri                  = "https://$Instance/tdstm/ws/tag/$TagId"
				WebSession           = $TMSessionConfig.TMWebSession
				SkipCertificateCheck = $AllowInsecureSSL
			}
	
			# Make the request
			try {
				Write-Verbose "Web Request Parameters:"
				Write-Verbose ($WebRequestSplat | ConvertTo-Json -Depth 10)
				Write-Verbose "Invoking web request"
				$Response = Invoke-WebRequest @WebRequestSplat
				Write-Verbose "Response status code: $($Response.StatusCode)"
				Write-Verbose "Response Content: $($Response.Content)"
			}
			catch {
				throw $_
			}
	
			if ($Response.StatusCode -notin 200, 204) {
				Write-Error "Tag with Id $TagId could not be removed"
			}
		}
	}
}