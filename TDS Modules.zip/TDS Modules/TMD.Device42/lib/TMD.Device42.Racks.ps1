
function Get-D42Racks {
	param(
	)
	Get-D42Data -table "racks"
	
}