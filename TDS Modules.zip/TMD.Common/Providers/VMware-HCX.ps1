

$Global:ProviderSetup = @{

    ProviderName    = 'VMware HCX'
    StartupMessage  = 'Importing VMware HCX Module and Configuration'
    ModulesToImport = @('VMware.VimAutomation.Hcx')
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration

    }
}

