
$Global:ProviderSetup = @{

    ProviderName    = 'CloudEndure'
    StartupMessage  = 'Importing CloudEndure Module and Configuration'
    ModulesToImport = @(
        "BAMCIS.Logging",
        "BAMCIS.DynamicParam",
        "BAMCIS.Common",
        "CloudEndure"
    )
    StartupScript   = [scriptblock] {
       # Define Provider Specific Configuration

    }
}
