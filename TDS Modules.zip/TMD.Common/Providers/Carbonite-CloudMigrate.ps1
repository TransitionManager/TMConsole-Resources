
$Global:ProviderSetup = @{

    ProviderName    = 'Carbonite CloudMigrate'
    StartupMessage  = 'Importing Carbonite CloudMigrate Module and Configuration'
    ModulesToImport = @('TMD.CarboniteCloudMigrate')
    StartupScript   = [scriptblock] {
        
        # Define Provider Specific Configuration

    }
}

