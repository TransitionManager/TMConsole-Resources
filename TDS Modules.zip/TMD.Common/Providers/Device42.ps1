
$Global:ProviderSetup = @{

    ProviderName    = 'Device42'
    StartupMessage  = 'Importing Device42 Module and Configuration'
    ModulesToImport = @('TMD.Device42')
    StartupScript   = [scriptblock] {
        
       # Define Provider Specific Configuration

    }
}
