
## Functions for Adding and Removing the Credentials

Function Invoke-TmdModuleHelp {
	param(
		[Parameter(Mandatory = $true, Position = 0)][String]$Page
	)
    
    Invoke-Item -Path 'http://www.google.com'
}