
Function Update-TMDVsCodeLaunchConfig {
	param(
		[Parameter(mandatory = $true, Position = 0)][string]$TmdPsRoot,
		[Parameter(mandatory = $False, Position = 1)][string]$TmdPsSessionName,
		[Parameter(mandatory = $False, Position = 1)][string]$SessionPid,
		[Parameter(mandatory = $False, Position = 1)][string]$SessionRunspaceId,
		[Parameter(mandatory = $False, Position = 2)][switch]$Clear

	)
	
	## Get the path for VS Code's Launch file and Open it
	# $LaunchConfigFile = Join-Path $TmdPsRoot '.vscode' 'launch.json'
	$LaunchConfigFile = Join-Path $appPaths.defaultConfig 'launch.json'
	$LaunchConfig = Get-Content -Path $LaunchConfigFile | ConvertFrom-Json
	
	## Add the
	## Session PID is not used any longer
	# if ($SessionPid) {
	# 	$LaunchConfig.configurations[0].processId = $SessionPid.ToString()
	# 	$LaunchConfig.configurations[0].runspaceId = $SessionRunspaceId
	# 	# $LaunchConfig.configurations[0].script = Join-Path $TmdPsRoot 'App' 'Scripts' 'Invoke-TMActionRequestDebugging.ps1' 
	# }
	
	## Update the Launch Config File (Old way)
	## Session PID is not used any longer
	if ($TmdPsSessionName) {
		$LaunchConfig.configurations[0].args = [array]@($TmdPsSessionName)
		$LaunchConfig.configurations[0].script = Join-Path $TmdPsRoot 'App' 'Scripts' 'Invoke-TMActionRequestDebugging.ps1' 
	}

	
	## Save Launch Configuration
	## If the settings should be 
	if ($Clear) {
		## Clear Session Connection Config
		# $LaunchConfig.configurations[0].processId = "0"
		# $LaunchConfig.configurations[0].runspaceId = 0
		
		## Clear Session Name based config
		$LaunchConfig.configurations[0].args = [array]@('')
		$LaunchConfig.configurations[0].script = ''
	}
	
	$LaunchConfig | ConvertTo-Json -Depth 5 | Set-Content -Path $LaunchConfigFile
}