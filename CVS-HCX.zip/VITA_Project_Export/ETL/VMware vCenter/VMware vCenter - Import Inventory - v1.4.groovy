/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "VMware vCenter - Import Inventory - v1.4",
  "Description": "",
  "ProviderName": "VMware vCenter",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*
	Script: VMware vCenter - Inventory Import
	Script Version: 1.4
	Minimum TM Version: 4.6.1

	TODO:
		Prior to release, undo the VITA specific changes this script co-developed
		// load 'DSLS

		Disabled Fields: (VMs, Clusters and Hosts)
			Virtual - *
			License Key
			Network - *
			IP Address
			Processor - 
			Memory - *
			OS
			Disks - *
			SerialNumber

		Network - VLAN - Disabled for all classes (no room for field)
*/

//////////////////////////////
// ETL Config Switches
//////////////////////////////
def config = [
	processData: [
		extensions:			false,
		vCenterServers: 	true,
		cluster: 			false,
		datacenter: 		false,
		folder: 			true,
		resourcePool: 		true,
		host: 				false,
		vm: 				true,
		datastore: 			false,
		vdisk: 				false,
		virtualNetwork: 	false,
		virtualSwitches: 	false
	],
	matchOnNameAlone: [
		vCenterServer:  	true,
		cluster: 			true,
		host: 				true,
		vm: 				true
	],
	bundles: [
		clusters: 			'VM Clusters',
		newDevices: 		'New Devices from vCenter',
		templates: 			'VM Template Device'
	],
	trimFromName: [
		cluster: 			'.tdsops.net',
		host: 				'.tdsops.net',
		vm: 				'.tdsops.net',
		datastore: 			'',
		resourcePool: 		'',
		vdisk: 				'',
		datacenter:			'',
		folder:				'',
		virtualNetworks:	'',
		virtualSwitches:	''
	]
]

enums = [
	powerState: [
		0: 'Powered OFF',
		1: 'Powered ON',
		2: 'Suspended'
	],
	guestState: [
		0: 'Not Running',
		1: 'Resetting',
		2: 'Running',
		3: 'ShuttingDown',
		4: 'Standby',
		5: 'Unknown'
	],
	toolsStatus: [
		0: 'Tools NOT Installed',
		1: 'Tools NOT Running',
		2: 'Tools Running',
		3: 'Tools are OUTDATED'
	]
]

//////////////////////////////
// Define import order
//////////////////////////////
domain Application
domain Device
domain Storage
domain Dependency

//////////////////////////////
// Script Functions
//////////////////////////////

// Construct an ensureArray function
def ensureArray = { data ->
	if(!data){
		return []
	}
	if (data.getClass().getName() == 'java.util.ArrayList') {
		return data
	} else {
		dataArray = new ArrayList()
		dataArray.add(data)
		return dataArray
	}
}

//////////////////////////////
//  Metadata
//////////////////////////////
def vCenterServerVar
def vCenterLocationTypeVar
rootNode 'Metadata'
read labels
iterate {
	extract 'LocationType' set metaVCenterLocationTypeVar
	vCenterLocationTypeVar = metaVCenterLocationTypeVar 
}

//////////////////////////////
//  vCenter Servers
//////////////////////////////
if (config.processData.vCenterServers){
	rootNode 'vCenterServers'
	read labels
	iterate {

		// Set the domain
		domain Application
		set typeVar with 'vCenter'
		extract 'name' set metaVCenterServerVar
		vCenterServerVar = metaVCenterServerVar 

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with prepend('vCenter: ') set assetNameVar load 'Name'
		
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		
		// Additional Details
		extract 'assetDetails' set assetDetailsVar
		load 'Version' with assetDetailsVar.version
		load 'Description' with assetDetailsVar.about.FullName
		
		// Find the Cluster
		find Application by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		elseFind Application by \
			'DSID-vCenter' like  '-%' + assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		elseFind Application by \
			'Name' eq assetNameVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		elseFind Application by \
			'Name' eq assetNameVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			into 'id'
		elseFind Application by \
			'URL' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		if(config.matchOnNameAlone.vCenterServer){
			// Search using the full name + Known Endpoint
			elseFind Application by \
				'Name' eq assetNameVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				into 'id'
			// Search using just the URL name + Known Endpoint
			elseFind Application by \
				'Name' eq vCenterServerVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				into 'id'
			//Search using the URL field + Known Endpoint
			elseFind Application by \
				'URL' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'id'
			// Search using the full name + WITHOUT Endpoint
			elseFind Application by \
				'Name' eq assetNameVar \
				into 'id'
			// Search using just the URL name + WITHOUT Endpoint
			elseFind Application by \
				'Name' eq vCenterServerVar \
				into 'id'
			//Search using the URL field + WITHOUT Endpoint
			elseFind Application by \
				'URL' eq vCenterServerVar \
				into 'id'
		}

		// Process the Root Folder
		if(config.processData.folder){
			
			// Get the folder name
			set rootFolderVar with assetDetailsVar.rootFolder.Value.toString()

			domain Dependency
			
			// Find the Folder
			find Storage by \
				'DSID-vCenter' eq rootFolderVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq 'Folder' \
				into 'asset'
			
			elseFind Storage by \
				'DSID-vCenter' like '%' + rootFolderVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq 'Folder' \
				into 'asset'
			
			whenNotFound 'asset' create {
				'Name' rootFolderVar
				'DSID-vCenter' rootFolderVar
				'DSEP-vCenter' vCenterServerVar
				'DSOT-vCenter' 'Folder'
			}
			
			// Find the vCenter Server
			find Application by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'dependent'
			
			whenNotFound 'dependent' create {
				'DSID-vCenter' assetIdVar 
				'DSEP-vCenter' vCenterServerVar 
				'DSOT-vCenter' typeVar
				'Name' assetNameVar
			}
			load 'type' with 'vCenter Managed'
			load 'comment' with 'vCenter Manages the root Folder'
			load 'status' with 'Validated'
			load 'dataFlowFreq' with 'constant'
		}

		

	}
}
//////////////////////////////
//  vCenter Extensions
//////////////////////////////
if (config.processData.extensions){
	rootNode 'vcenterExtensions'
	read labels
	iterate {
		
		extract 'Key' set extensionKeyVar
		switch(extensionKeyVar) {
				// HCX Hybrid Cloud 
				case 'com.vmware.hybridity':
					
					domain Application
					set dsotvCenterVar with 'HCX Server'
					set vendorVar with 'VMware'

					extract 'Server' set serverVar
					extract 'Description' set descriptionVar
					extract 'Version' set versionVar
					
					List endpointListVar = serverVar.toArray()
					def httpServerEndpointVar = endpointListVar.find { it['Type'] == 'HTTPS'}

					set assetNameVar with 'HCX Server: ' + httpServerEndpointVar['Url']
					set adminEmailVar with httpServerEndpointVar['AdminEmail']
					set serverThumbprintVar with httpServerEndpointVar['ServerThumbprint']

					load 'Name' with assetNameVar
					init 'Bundle' with 'HCX Servers'
					init 'url' with httpServerEndpointVar['Url']

					load 'DSID-vCenter' with serverThumbprintVar
					load 'DSEP-vCenter' with vCenterServerVar
					load 'DSOT-vCenter' with dsotvCenterVar
					
					load 'Vendor' with vendorVar
					load 'Technology' with descriptionVar['Label']
					load 'Version' with versionVar
					init 'Description' with 'Admin email: ' + adminEmailVar

					// Find the Extension/HCX Server App
					find Application by \
						'DSID-vCenter' eq serverThumbprintVar \
						and 'DSEP-vCenter' eq vCenterServerVar \
						and 'DSOT-vCenter' eq dsotvCenterVar  \
						and 'Vendor' eq vendorVar \
						into 'id'
					elseFind Application by \
						'Name' like 'HCX Server: %' +httpServerEndpointVar['Url'] \
						and 'Vendor' eq vendorVar \
						into 'id'
					
					// Create a dependency to the vCenter
					domain Dependency
					load 'asset' with assetNameVar
					find Application \
						by 'DSID-vCenter' eq serverThumbprintVar \
						into 'asset'
					elseFind Application \
						by 'Name' eq serverThumbprintVar \
						into 'asset'
					load 'dependent' with vCenterServerVar
					find Application \
						by 'Name' eq 'vCenter: ' + vCenterServerVar \
						into 'dependent'
					load 'status' with 'Validated'
					load 'type' with 'vCenter Managed'
					load 'comment' with 'vCenter Extension'
					load 'dataFlowFreq' with 'constant'
					break
		} 
	}
}		

//////////////////////////////
//  Clusters
//////////////////////////////
if (config.processData.cluster){
	rootNode 'clusters'
	read labels
	iterate {
		
		// Set the domain
		domain Application
		set typeVar with 'ClusterComputeResource'
		
		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' set originalAssetNameVar
		extract 'name' transform with replace(config.trimFromName.cluster ,'') prepend(typeVar+': ') set assetNameVar load 'Name'
		load 'Vendor' with 'VMware'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Bundle' with config.bundles.clusters
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		drsConfig = 'Automation Level: ' + assetDetailsVar.drsConfig.drsAutomationLevel + ', Enabled: ' + assetDetailsVar.drsConfig.drsEnabled
		// load 'Virtual - DRS Config' with drsConfig
		// load 'Virtual - HA Enabled' with assetDetailsVar.haEnabled

		// Find the Cluster
		find Application by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		elseFind Application by \
			'Name' eq assetNameVar \
			and 'Vendor' eq 'VMware' \
			into 'id'
		elseFind Application by \
			'Name' eq originalAssetNameVar \
			and 'Vendor' eq 'VMware' \
			into 'id'
		
		// If matching by name only is allowed
		if (config.matchOnNameAlone.cluster){
			elseFind Application by 'Name' eq assetNameVar into 'id'
			elseFind Application by 'Name' eq originalAssetNameVar into 'id'
		}

		//
		// Create Dependencies for each Resource Type
		//

		// vCenter Managed Dependency
		domain Dependency
		load 'asset' with assetNameVar
		// Find the Cluster
		find Application by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'asset'
		load 'dependent' with vCenterServerVar
		find Application \
			by 'Name' eq 'vCenter: ' + vCenterServerVar \
			into 'dependent'
		load 'status' with 'Validated'
		load 'type' with 'vCenter Managed'
		load 'comment' with 'vCenter Managed Cluster'
		load 'dataFlowFreq' with 'constant'
		
		extract 'assetResources' set assetResourcesVar
		if (config.processData.datastore){
			for (datastore in ensureArray(assetResourcesVar.datastore)) {
				
				// Create the Resource Asset details
				datastoreIdVar = datastore['Value']
				datastoreTypeVar = 'Datastore'
				datastoreTempNameVar = datastoreTypeVar + ": " + datastoreIdVar
				
				domain Dependency
				find Application by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}
				
				find Storage by \
					'DSID-vCenter' eq datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' datastoreIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' datastoreTypeVar
					'Name' datastoreTempNameVar
				}
				load 'type' with 'Datastore'
				load 'comment' with 'Cluster Requires Datastore'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.virtualNetwork){
			for (network in ensureArray(assetResourcesVar.network)) {
				
				// Create the Resource Asset details
				networkIdVar = network['Value']
				networkTypeVar = 'VirtualNetwork'
				networkTempNameVar = networkTypeVar + ": " + networkIdVar
				
				domain Dependency
				find Application by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				elseFind Device by \
					'DSID-vCenter' like '%' + networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' networkIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' networkTypeVar
					'Name' networkTempNameVar
					// 'Manufacturer' 'VMware'
					// 'Model' 'Network'
					// 'Device Type' 'Network'
				}
				load 'type' with 'Network'
				load 'comment' with 'Cluster Offers Virtual Network'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.host){
			for (host in ensureArray(assetResourcesVar.host)) {
				
				// Create the Resource Asset details
				hostIdVar = host['Value']
				hostTypeVar = 'HostSystem'
				hostTempNameVar = hostTypeVar + ": " + hostIdVar
				
				domain Dependency
				find Application by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' hostIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' hostTypeVar
					'Name' hostTempNameVar
					// 'Manufacturer' 'Unknown'
					// 'Model' 'Unknown'
					// 'Device Type' 'Unknown'
				}
				load 'type' with 'Cluster Runs On'
				load 'comment' with 'Cluster has Host Members'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.resourcePool){
			for (resourcePool in ensureArray(assetResourcesVar.resourcePool)) {
				
				// Create the Resource Asset details
				resourcePoolIdVar = resourcePool['Value']
				resourcePoolTypeVar = 'ResourcePool'
				resourcePoolTempNameVar = resourcePoolTypeVar + ": " + resourcePoolIdVar
				
				domain Dependency
				find Application by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq resourcePoolIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq resourcePoolTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + resourcePoolIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq resourcePoolTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' resourcePoolIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' resourcePoolTypeVar
					'Name' resourcePoolTempNameVar
				}
				load 'type' with 'Logical Organization'
				load 'comment' with 'Cluster Organizes resources into Resource Pools'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
	}
}
	 
//////////////////////////////
//  Hosts
//////////////////////////////
if (config.processData.host){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'vmHosts'
	read labels
	iterate {

		// Set the domain
		domain Device
		set typeVar with 'HostSystem'

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name'  set originalAssetNameVar
		extract 'name' transform with replace(config.trimFromName.host ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		load 'DSID-VMwareUUID' with assetDetailsVar.hardwareUuid
		// load 'License Key' with assetDetailsVar.licenseKey
		// load 'Virtual - Connection State' with assetDetailsVar.connectionState
		// load 'Virtual - Power State' with enums.powerState[assetDetailsVar.powerState]
		// load 'Virtual - Is Standalone' with assetDetailsVar.isStandalone
		// load 'Virtual - Software Version' with assetDetailsVar.product['FullName']

		// System Info / Hardware
		set assetSystemInfoVar with assetDetailsVar.systemInfo
		
		// Manufacturer
		find Manufacturer by 'name' eq assetSystemInfoVar['Vendor'] into 'manufacturer'
		whenNotFound 'manufacturer' create {'name' assetSystemInfoVar['Vendor']}

		// Model
		find Model by 'modelName' eq assetSystemInfoVar['Model'] and 'manufacturer' eq assetSystemInfoVar['Vendor'] into 'model'
		elseFind Model by 'modelName' eq assetSystemInfoVar['Model'] into 'model'
		whenNotFound 'model' create {
			'modelName'  assetSystemInfoVar['Model']
			'manufacturer' assetSystemInfoVar['Vendor']
			'assetType' 'Server'
			'usize' 1 
		}

		// Serial Numbers and other identifying data
		load 'serialNumber' with assetSystemInfoVar['SerialNumber']
		for (identifier in ensureArray(assetSystemInfoVar['OtherIdentifyingInfo'])) {
			
			// TODO Fix this

			// if(identifier && ideentifier.IdentifierType) {
			// 	switch(identifier.IdentifierType.Key) {
			// 		case 'AssetTag':
			// 			load 'Asset Tag' with identifier['Value']
			// 			break
					
			// 		case 'ServiceTag':
			// 			load 'serialNumber' with identifier['Value']
			// 			break
			// }}
		}

		// Network Details
		// set assetNetworkVar with assetDetailsVar.network
		// List ipAddresses = []
		// List macAddresses = []
		// load 'Network - Domain' with assetNetworkVar.domainName
		// load 'Network - Hostname' with assetNetworkVar.hostname

		// for (nic in ensureArray(assetNetworkVar.nics)) {
		// 	if(	nic.ip 
		// 		&& nic.ip != '' 
		// 		&& nic.ip != null 
		// 		&& nic.ip != 'null' 
		// 		&& !ipAddresses.contains(nic.ip)
		// 	) { 
		// 		ipAddresses.add(nic.ip) 
		// 	} 
		// 	if(	nic.mac 
		// 		&& nic.mac != '' 
		// 		&& nic.mac != null 
		// 		&& nic.mac != 'null'
		// 		&& !macAddresses.contains(nic.mac)
		// 	) { 
		// 		macAddresses.add(nic.mac) 
		// 	}
		// }
		
		// set ipAddressVar with ipAddresses.join(', ')
		// set macAddressVar with macAddresses.join(', ')

		// if (ipAddressVar.length() > 255){
			// load 'IP Address'  with ipAddressVar.substring(0,254)
			// ipLen = ipAddressVar.length() > 512 ? 512 : ipAddressVar.length()
			// load 'Network - IP Address 2' with ipAddressVar.substring(255,ipLen)
		// } else {
			// load 'IP Address'  with ipAddressVar
		// }
		// if (macAddressVar.length() > 255){
			// load 'IP Address'  with macAddressVar.substring(0,254)
			// macLen = macAddressVar.length() > 512 ? 512 : macAddressVar.length()
			// load 'Network - Mac Address 2' with macAddressVar.substring(255,macLen)
		// } else {
		// 	// load 'Network - Mac Address'  with macAddressVar
		// }

		// Processor Details
		// set assetProcessorVar with assetDetailsVar.processor
		// load 'Processor - Model' with assetProcessorVar.cpuModel
		// load 'Processor - Count' with assetProcessorVar.cpuInfo.NumCpuPackages
		// load 'Processor - Core Count' with assetProcessorVar.cpuInfo.NumCpuCores
		// load 'Processor - Thread Count' with assetProcessorVar.cpuInfo.NumCpuThreads
		// load 'Processor - Speed' with assetProcessorVar.cpuInfo.Hz

		// Memory Details
		// set assetMemoryVar with assetDetailsVar.memory
		// load 'Memory - Used' with assetMemoryVar.totalGB
		// load 'Memory - Total' with assetMemoryVar.usedGB
		
		// Find the Asset
		find Device by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'Manufacturer' eq assetSystemInfoVar['Vendor'] \
			and 'Model' eq assetSystemInfoVar['Model'] \
			and 'External Ref Id' eq assetSystemInfoVar['SerialNumber'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar\
			and 'Manufacturer' eq assetSystemInfoVar['Vendor'] \
			and 'Model' eq assetSystemInfoVar['Model'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar\
			and 'Manufacturer' eq assetSystemInfoVar['Vendor'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar\
			and 'Model' eq assetSystemInfoVar['Model'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'External Ref Id' eq assetSystemInfoVar['SerialNumber'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'serialNumber' eq assetSystemInfoVar['SerialNumber'] \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'serialNumber' eq DOMAIN.serialNumber \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'External Ref Id' eq DOMAIN.serialNumber \
			into 'id'
		if (config.matchOnNameAlone.host){
			elseFind Device by 'Name' eq assetNameVar into 'id'
			elseFind Device by 'Name' eq originalAssetNameVar into 'id'
		}

		if (FINDINGS.size() < 1){
			load 'Bundle' with config.bundles.newDevices
		}

		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		if (config.processData.cluster){
			for (clusterVar in ensureArray(assetResourcesVar.cluster)) {
				
				
				// Figure out what kind of resource this is.  It could be a cluster (for cluster hosts) or a Folder if it's unclustered
				
				set hostingObjectTypeVar with clusterVar.split('-')[0]
				set hostingObjectIdVar with clusterVar.replace(hostingObjectTypeVar+'-','')
				
				
				// Based on which kind of resource it is, create the necessary dependency
				switch	(hostingObjectTypeVar){
					
					case 'ClusterComputeResource':
						hostingObjectIdTempNameVar = "Cluster: " + hostingObjectIdVar		
						domain Dependency
						find Device by \
							'DSID-vCenter' eq assetIdVar \
							and 'DSEP-vCenter' eq vCenterServerVar \
							and 'DSOT-vCenter' eq typeVar \
							into 'dependent'

						whenNotFound 'dependent' create {
							'DSID-vCenter' assetIdVar
							'DSEP-vCenter' vCenterServerVar
							'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
							'DSOT-vCenter' typeVar
							'Name' assetNameVar
						}

						find Application by \
							'DSID-vCenter' eq clusterVar \
							and 'DSEP-vCenter' eq vCenterServerVar \
							and 'DSOT-vCenter' eq 'ClusterComputeResource' \
							into 'asset'
						elseFind Application by \
							'DSID-vCenter' like '%' + clusterVar \
							and 'DSEP-vCenter' eq vCenterServerVar \
							and 'DSOT-vCenter' eq 'ClusterComputeResource' \
							into 'asset'

						whenNotFound 'asset' create {
							'DSID-vCenter' clusterVar
							'DSEP-vCenter' vCenterServerVar
							'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
							'DSOT-vCenter' 'ClusterComputeResource'
							'Name' hostingObjectIdTempNameVar
						}
						
						load 'type' with 'Cluster Runs On'
						load 'comment' with 'Host Supports Cluster'						
						load 'status' with 'Validated'
						load 'dataFlowFreq' with 'constant'
						break
					
					
					default: 
						break
				} 		
			}
		}
		if (config.processData.datastore){
			for (datastore in ensureArray(assetResourcesVar.datastore)) {
				
				// Create the Resource Asset details
				datastoreIdVar = datastore['Value']
				datastoreTypeVar = 'Datastore'
				datastoreTempNameVar = datastoreTypeVar + ": " + datastoreIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' datastoreIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' datastoreTypeVar
					'Name' datastoreTempNameVar
				}
				load 'type' with 'Datastore'
				load 'comment' with 'Hosts require datastores'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.virtualNetwork){
			for (network in ensureArray(assetResourcesVar.network)) {
				
				// Create the Resource Asset details
				networkIdVar = network['Value']
				networkTypeVar = 'VirtualNetwork'
				networkTempNameVar = networkTypeVar + ": " + networkIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				elseFind Device by \
					'DSID-vCenter' like '%' + networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' networkIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' networkTypeVar
					'Name' networkTempNameVar
				}
				load 'type' with 'Network'
				load 'comment' with 'Hosts Offer Virtual Network'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.virtualSwitch){
			for (virtualSwitch in ensureArray(assetResourcesVar.virtualSwitch)) {
				
				// Create the Resource Asset details
				virtualSwitchIdVar = virtualSwitch
				virtualSwitchTypeVar = "VirtualSwitch"
				virtualSwitchTempNameVar = virtualSwitchTypeVar + ": " + virtualSwitchIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq virtualSwitchIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq virtualSwitchTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + virtualSwitchIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq virtualSwitchTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' virtualSwitchIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' virtualSwitchTypeVar
					'Name' virtualSwitchTempNameVar
					// 'Manufacturer' 'VMware'
					// 'Model' 'Network'
					// 'Device Type' 'Network'
				}
				load 'type' with 'Network'
				load 'comment' with 'Hosts Connect to Virtual Switches'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// TODO Fix this
		// for (storage in ensureArray(assetResourcesVar.storage)) {
			
		// 	// This node has all the data in it, create the assets.
		// 	domain Storage
		// 	storageTypeVar = 'Datastore'
		// 	storageTempNameVar = storage['Name']
		// 	uuidVar = storage['Path'].split('/')[3]
		// 	storageIdVar = storageTypeVar + '-' + uuidVar
		// 	if (storageTempNameVar) {
		// 		storageTempNameVar = storage['Name']
		// 	} else {
		// 		storageTempNameVar = storageIdVar
		// 	}
			
		// 	load 'Name' with storageTempNameVar
		// 	load 'DSID-vCenter' with storageIdVar
		//	load 'DSEP-vCenter' with vCenterServerVar
		//  load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		
		// 	load 'DSOT-vCenter' with storageTypeVar
		// 	load 'LUN' with storageIdVar
		// 	load 'Access Mode' with storage['AccessMode']
		// 	load 'Format' with storage['Type']
		// 	load 'Size' with storage['CapacityGB'].toInteger()
		// 	load 'Scale' with 'GB'

		// 	// Find the Datastore
		// 	find Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'DSID-vCenter' eq storageIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		into 'id'
		// 	elseFind Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'DSID-vCenter' like '%' + storageIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		into 'id'
		// 	elseFind Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'LUN' like uuidVar \
		// 		into 'id'

		// 	// Build the dependencies
		// 	domain Dependency
		// 	find Device by \
		// 		'DSID-vCenter' eq assetIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		and 'DSOT-vCenter' eq typeVar \
		// 		into 'asset'
			// whenNotFound 'asset' create {
			// 		'DSID-vCenter' assetIdVar
			//		'DSEP-vCenter' vCenterServerVar
			//		'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
			// 		'DSOT-vCenter' typeVar
			// 		'Name' assetNameVar
			// 	}
		// 	find Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'DSID-vCenter' eq storageIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		into 'dependent'
		// 	elseFind Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'DSID-vCenter' like '%' + storageIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		into 'dependent'
		// 	elseFind Storage by \
		// 		'DSOT-vCenter' eq storageTypeVar \
		// 		and 'LUN' like uuidVar \
		// 		into 'dependent'
		// 	whenNotFound 'dependent' create {
		// 		'DSOT-vCenter' storageTypeVar
		// 		'Name' storageTempNameVar
		// 		'LUN' storageIdVar
		// 		'DSID-vCenter' storageIdVar
		//		'DSEP-vCenter' vCenterServerVar
		//		'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
		// 	}
		// 	load 'type' with 'Storage'
		// 	load 'comment' with 'Host has Local Storage'
		// 	load 'status' with 'Validated'
		// 	load 'dataFlowFreq' with 'constant'
		// }

	}
}

//////////////////////////////
//  VMs
//////////////////////////////
if (config.processData.vm){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'vms'
	read labels
	iterate {

		// Set the domain
		domain Device
		set typeVar with 'VirtualMachine'

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.vm ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		load 'DSID-VMwareUUID' with assetDetailsVar.persistentId
		if(assetDetailsVar.notes?.length() > 255) {
			load 'Description' with assetDetailsVar.notes.substring(0,251)+'...'
		} else {
			load 'Description' with assetDetailsVar.notes
		}
		
		// Virtual Details
		// load 'Virtual - Connection State' with assetDetailsVar.connectionState
		// load 'Virtual - Guest ID' with assetDetailsVar.guest.guestId
		// load 'Virtual - Power State' with enums.powerState[assetDetailsVar.powerState]
		// load 'Virtual - Software Version' with assetDetailsVar.hardwareVersion
		// load 'Virtual - Tools Status' with enums.toolsStatus[assetDetailsVar.guest.toolsStatus]
		// load 'Virtual - Tools Version' with assetDetailsVar.guest.toolsVersion
		// load 'Virtual - Guest State' with enums.guestState[assetDetailsVar.guest.state]

		// System Info / Virtual Hardware
		// load 'OS' with assetDetailsVar.guest.osFullName
		// load 'Disks - Total Provisioned' with assetDetailsVar.provisionedSpaceGB
		// load 'Disks - Total Used' with assetDetailsVar.usedSpaceGB
		// load 'Memory - Used' with assetDetailsVar.memoryGB
		// load 'Processor - Cores Per Proc' with assetDetailsVar.coresPerSocket
		// load 'Processor - Count' with assetDetailsVar.numCpu
		
		// Device Model Data
		load 'Manufacturer' with 'VMware'
		load 'Model' with 'VM'
		load 'Device Type' with 'VM'
		// load 'Serial #' with assetDetailsVar.persistentId

		// Network Details
		// List ipAddresses = []
		// List macAddresses = []
		// load 'Network - Hostname' with assetDetailsVar.guest.hostName
		// load 'Network - NIC Count' with assetDetailsVar.guest.nicCount

		// if (assetDetailsVar.guest.ipAddress) { 
		// 	for (ipAddress in ensureArray(assetDetailsVar.guest.ipAddress) ){ 
		// 		ipAddresses.push(ipAddress) 
		// 	}
		// }
		// for (nic in ensureArray(assetDetailsVar.guest.nics)){
		// 	if(nic.ipAddress){
		// 		if(nic.ipAddress != '' && nic.ipAddress != null){
		// 			for (ip in ensureArray(nic.ipAddresses)) {
		// 				if (!ipAddresses.contains(ip)) { ipAddresses.push(ip) }
		// 			}
		// 		}
		// 	}
		// 	if(nic.macAddress){
		// 		if(nic.macAddress != '' && nic.macAddress != null){
		// 			for (mac in ensureArray(nic.macAddress)) {
		// 				if (!macAddresses.contains(mac)) { macAddresses.push(mac) }
		// 			}
		// 		}
		// 	}
		// }
		
		// set ipAddressVar with ipAddresses.join(', ')
		// set macAddressVar with macAddresses.join(', ')

		// if (ipAddressVar.length() > 255){
		// 	load 'IP Address'  with ipAddressVar.substring(0,254)
		// 	ipLen = ipAddressVar.length() > 512 ? 512 : ipAddressVar.length()
		// 	load 'Network - IP Address 2' with ipAddressVar.substring(255,ipLen)
		// } else {
		// 	load 'IP Address'  with ipAddressVar
		// }
		// if (macAddressVar.length() > 255){
		// 	load 'IP Address'  with macAddressVar.substring(0,254)
		// 	macLen = macAddressVar.length() > 512 ? 512 : macAddressVar.length()
		// 	load 'Network - Mac Address 2' with macAddressVar.substring(255,macLen)
		// } else {
		// 	load 'Network - Mac Address'  with macAddressVar
		// }

		// Find the Asset
		find Device by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSOT-vCenter' eq typeVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			into 'id'
		elseFind Device by \
			'Name' eq assetNameVar \
			and 'Manufacturer' eq 'VMware' \
			and 'Model' eq 'VM' \
			into 'id'
		elseFind Device by \
            'Name' eq assetNameVar \
            and 'serialNumber' eq assetDetailsVar.persistentId \
            into 'id'
		elseFind Device by \
			'Name' eq assetNameVar\
			and 'Manufacturer' eq 'VMware' \
			into 'id'
        if (config.matchOnNameAlone.vm){
			elseFind Device by \
				'Name' eq assetNameVar \
				into 'id'
		}

		if (FINDINGS.size() < 1){
			load 'Bundle' with config.bundles.newDevices
		}

		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		
		// Cluster
		if (config.processData.cluster){
			for (cluster in ensureArray(assetResourcesVar.cluster)) {
				
				// Create the Resource Asset details
				clusterIdVar = cluster['id']
				clusterTypeVar = 'ClusterComputeResource'
				clusterTempNameVar = cluster['Name']
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' typeVar + ': ' + assetIdVar
				}
				
				find Application by \
					'DSID-vCenter' eq clusterIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq clusterTypeVar \
					into 'dependent'
				elseFind Application by \
					'DSID-vCenter' like '%' + clusterIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq clusterTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' clusterIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' clusterTypeVar
					'Name' clusterTempNameVar
				}
				load 'type' with 'VM Runs On'
				load 'comment' with 'VMs run on a Cluster'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		
		// Datastore
		if (config.processData.datastore){
			for (datastore in ensureArray(assetResourcesVar.datastore)) {
				
				// Create the Resource Asset details
				datastoreTypeVar = 'Datastore'
				datastoreIdVar = datastore.id
				datastoreTempNameVar = datastore.name
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}
				
				find Storage by \
					'DSID-vCenter' eq datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' datastoreIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' datastoreTypeVar
					'Name' datastoreTempNameVar
				}
				load 'type' with 'Datastore'
				load 'comment' with 'VMs require Datastores'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// Virtual Network
		if (config.processData.virtualNetwork){
			for (network in ensureArray(assetResourcesVar.network)) {
				
				// Create the Resource Asset details
				networkIdVar = network['Value']
				networkTypeVar = 'VirtualNetwork'
				networkTempNameVar = networkTypeVar + ": " + networkIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' networkIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' networkTypeVar
					'Name' networkTempNameVar
				}
				load 'type' with 'Network'
				load 'comment' with 'VMs Connect to Virtual Networks'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// Virtual Switch
		if (config.processData.virtualSwitch){
			for (virtualSwitch in ensureArray(assetResourcesVar.virtualSwitch)) {
				
				// Create the Resource Asset details
				virtualSwitchIdVar = virtualSwitch
				virtualSwitchTypeVar = "VirtualSwitch"
				virtualSwitchTempNameVar = virtualSwitchTypeVar + ": " + virtualSwitchIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq virtualSwitchIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq virtualSwitchTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + virtualSwitchIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq virtualSwitchTypeVar \
					into 'dependent'
				// whenNotFound 'dependent' create {
				// 	'DSID-vCenter' virtualSwitchIdVar
				// 	'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				// 	'DSEP-vCenter' vCenterServerVar
				// 	'DSOT-vCenter' virtualSwitchTypeVar
				// 	'Name' virtualSwitchTempNameVar
				// 	'Manufacturer' 'VMware'
				// 	'Model' 'Network'
				// 	'Device Type' 'Network'
				// }
				load 'type' with 'Network'
				load 'comment' with 'VMs connect to Virtual Switches'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// Folder
		if (config.processData.folder){
				
			// Create the Resource Asset details
			set folderId with assetResourcesVar.folder.id
			set folderName with assetResourcesVar.folder.name
			
			domain Dependency
			find Device by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar \
				into 'asset'
			whenNotFound 'asset' create {
				'DSID-vCenter' folderId
				'DSEP-vCenter' vCenterServerVar
				'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				'DSOT-vCenter' typeVar
				'Name' assetNameVar
			}

			find Storage by \
				'DSID-vCenter' eq folderId \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq 'Folder' \
				into 'dependent'
			elseFind Storage by \
				'DSID-vCenter' like '%' + folderId \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq 'Folder' \
				into 'dependent'
			whenNotFound 'dependent' create {
				'DSID-vCenter' folderId
				'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				'DSEP-vCenter' vCenterServerVar
				'DSOT-vCenter' 'Folder'
			}
			load 'type' with 'Logical Organization'
			load 'comment' with 'VMs are Organized into Folders'
			load 'status' with 'Validated'
			load 'dataFlowFreq' with 'constant'
		}

		// VM Hosts  - We only want to process this data if there IS NO Cluster.
		// As we have no need to know which hosts a given VM runs on (unless it's unclustered)
		if(clusterIdVar == ''){
			if (config.processData.host){
				for (host in ensureArray(assetResourcesVar.host)) {
					
					// Create the Resource Asset details
					hostTypeVar = 'HostSystem'
					hostIdVar = host.id
					hostTempNameVar = hostTypeVar + ": " + hostIdVar
					
					domain Dependency
					find Device by \
						'DSID-vCenter' eq assetIdVar \
						and 'DSEP-vCenter' eq vCenterServerVar \
						and 'DSOT-vCenter' eq typeVar \
						into 'asset'
					whenNotFound 'asset' create {
						'DSID-vCenter' assetIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' typeVar
						'Name' assetNameVar
					}
					
					find Device by \
						'DSID-vCenter' eq hostIdVar \
						and 'DSEP-vCenter' eq vCenterServerVar \
						and 'DSOT-vCenter' eq hostTypeVar \
						into 'dependent'
					elseFind Device by \
						'DSID-vCenter' like '%' + hostIdVar \
						and 'DSEP-vCenter' eq vCenterServerVar \
						and 'DSOT-vCenter' eq hostTypeVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' hostIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' hostTypeVar
						'Name' hostTempNameVar
						'Manufacturer' 'Unknown'
						'Model' 'Unknown'
						'Device Type' 'Server'
					}
					load 'type' with 'VM Runs On'
					load 'comment' with 'VMs run on Hosts too - Maybe redundant'
					load 'status' with 'Validated'
					load 'dataFlowFreq' with 'constant'
				}
			}
		}
		// VM Hard Drive
		if (config.processData.vdisk){
			for (hardDisk in ensureArray(assetResourcesVar.hardDisk)) {
				
				// Create the Resource Asset details
				hardDiskIdVar = hardDisk['id']
				hardDiskTypeVar = 'vDisk'
				hardDiskTempNameVar = 'vDisk: ' + assetNameVar + ': ' + hardDisk['name']
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq hardDiskIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hardDiskTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + hardDiskIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hardDiskTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'Name' hardDiskTempNameVar
					'DSID-vCenter' hardDiskIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' hardDiskTypeVar
				}
				load 'type' with 'VM-vDisk'
				load 'comment' with 'VMs have vDisks'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// Resource Pool
		if (config.processData.resourcePool){
			for (resourcePool in ensureArray(assetResourcesVar.resourcePool)) {
				
				// Create the Resource Asset details
				resourcePoolIdVar = resourcePool['Value']
				resourcePoolTypeVar = 'ResourcePool'
				resourcePoolTempNameVar = resourcePoolTypeVar + ": " + resourcePoolIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq resourcePoolIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq resourcePoolTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + resourcePoolIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq resourcePoolTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' resourcePoolIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' resourcePoolTypeVar
					'Name' resourcePoolTempNameVar
				}
				load 'type' with 'Resource Pool'
				load 'comment' with 'VMs are stored in Resource Pools'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
	}
}

//////////////////////////////
//  Datastores
//////////////////////////////
if (config.processData.datastore){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'datastores'
	read labels
	iterate {

		// Set the domain
		domain Storage
		set typeVar with 'Datastore'

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.datastore ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		// load 'DSLS-vCenter' with NOW
		load 'Validation' with 'Validated'
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		set capacityGBVar with assetDetailsVar.capacityGB.toString().tokenize('.')[0]
		def capacitySizeVar = (capacityGBVar == '0') ? '1' :  capacityGBVar
		load 'size' with capacitySizeVar
		load 'scale' with 'GB'

		set freeSpaceGBVar with assetDetailsVar.freeSpaceGB.toString().tokenize('.')[0]
		def freeSpaceSizeVar = (freeSpaceGBVar == '0') ? '1' :  freeSpaceGBVar
		load 'Space - Free' with assetDetailsVar.freeSpaceGB

		load 'LUN' with assetDetailsVar.uuid
		load 'Format' with assetDetailsVar.type
		load 'Description' with 'Maintenance Mode: ' + assetDetailsVar.maintenanceMode + ', FS Version: ' + assetDetailsVar.fileSystemVersion + ', State: ' + assetDetailsVar.state

		// Find the Datastore
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		elseFind Storage by \
			'LUN' like assetDetailsVar.uuid \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'

		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		if (config.processData.folder){
			for (folder in ensureArray(assetResourcesVar.folder)) {
				
				// Create the Resource Asset details
				folderIdVar = folder
				folderTypeVar = 'Folder'
				folderTempNameVar = folderTypeVar + ": " + folderIdVar
				
				domain Dependency
				find Storage by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}
				
				find Storage by \
					'DSID-vCenter' eq folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' folderIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' folderTypeVar
					'Name' folderTempNameVar
				}
				load 'type' with 'Logical Organization'
				load 'comment' with 'Datastores contain folders'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
	}
}

//////////////////////////////
//  Resource Pools
//////////////////////////////
if (config.processData.resourcePool){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'resourcePools'
	read labels
	iterate {

		// Set the domain
		domain Storage
		set typeVar with "ResourcePool"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.resourcePool ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		// Find the ResourcePool
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		

		// Create Dependency to the Parent Object
		if( assetDetailsVar.parentId == null){
			
			// vCenter Managed Dependency
			domain Dependency
			// load 'asset' with assetNameVar
			// Find the Cluster
			find Storage by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'asset'
			load 'dependent' with vCenterServerVar
			find Application \
				by 'Name' eq 'vCenter: ' + vCenterServerVar \
				into 'dependent'
			load 'status' with 'Validated'
			load 'type' with 'vCenter Managed'
			load 'comment' with 'vCenter Managed Resource Pool'
			load 'dataFlowFreq' with 'constant'

		}else{

			// Set the Parent Object
			parentIdVar = assetDetailsVar.parentId
			parentObjectType = parentIdVar.tokenize("-")[0]
			
			domain Dependency
			find Storage by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar \
				into 'asset'
			whenNotFound 'asset' create {
				'DSID-vCenter' assetIdVar
				'DSEP-vCenter' vCenterServerVar
				'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				'DSOT-vCenter' typeVar
				'Name' assetNameVar
			}

			// Find the Dependent Asset by determining the ObjectType
			switch(parentObjectType) {
				case 'HostSystem':
					find Device \
						by 'DSID-vCenter' eq parentIdVar \
						and 'DSOT-vCenter' eq parentObjectType \
						and 'DSEP-vCenter' eq vCenterServerVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' parentIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' parentObjectType
						'Name' parentIdVar
					}
					break
				case 'Datacenter':
					find Storage \
						by 'DSID-vCenter' eq parentIdVar \
						and 'DSOT-vCenter' eq parentObjectType \
						and 'DSEP-vCenter' eq vCenterServerVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' parentIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' parentObjectType
						'Name' parentIdVar
					}
					break
				case 'Folder':
					find Storage \
						by 'DSID-vCenter' eq parentIdVar \
						and 'DSOT-vCenter' eq parentObjectType \
						and 'DSEP-vCenter' eq vCenterServerVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' parentIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' parentObjectType
						'Name' parentIdVar
					}
					break
				case 'ClusterComputeResource':
					find Application \
						by 'DSID-vCenter' eq parentIdVar \
						and 'DSOT-vCenter' eq parentObjectType \
						and 'DSEP-vCenter' eq vCenterServerVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' parentIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' parentObjectType
						'Name' parentIdVar
					}
					break
				case 'ResourcePool':
					find Storage \
						by 'DSID-vCenter' eq parentIdVar \
						and 'DSOT-vCenter' eq parentObjectType \
						and 'DSEP-vCenter' eq vCenterServerVar \
						into 'dependent'
					whenNotFound 'dependent' create {
						'DSID-vCenter' parentIdVar
						'DSEP-vCenter' vCenterServerVar
						'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
						'DSOT-vCenter' parentObjectType
						'Name' parentIdVar
					}
					break

				default:
					break
			}
			
			// Don't create a dependent object here.  There are too many types it could be,
			// and by virtue of this script, the asset WILL exist after asset batches are imported
			
			load 'type' with 'Logical Organization'
			load 'comment' with 'Resource Pools are Stored Logically'
			load 'status' with 'Validated'
			load 'dataFlowFreq' with 'constant'
		
		}
	}
}

//////////////////////////////
//  Hard Disks / vDisks
//////////////////////////////
if (config.processData.vdisk){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'hardDisks'
	read labels
	iterate {

		// Set the domain
		domain Storage
		set typeVar with "vDisk"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		set vmIdVar with assetIdVar.split('/')[0]
		
		extract 'name' transform with replace(config.trimFromName.vdisk ,'') prepend(vmIdVar + ': ') set assetNameVar load 'Name'
		
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW

		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		load 'Format' with assetDetailsVar.storageFormat
		
		// Refine Capacity GB to Integer
		set capacityGBVar with assetDetailsVar.capacityGB.toString().tokenize('.')[0]
		def capacitySizeVar = (capacityGBVar == '0') ? '1' :  capacityGBVar

		load 'size' with capacitySizeVar
		load 'scale' with 'GB'
		
		// Refine Free Space GB to Integer
		set datastoreNameVar with assetDetailsVar.filename.split(']')[0].replace('[','')
		set filePathVar with assetDetailsVar.filename.split(']')[1]
		
		load 'DSID-VMwareUUID' with assetDetailsVar.uuid
		load 'External Ref Id' with assetDetailsVar.contentId
		set persistenceVar with assetDetailsVar.persistence
		
		// set diskTypeVar with assetDetailsVar.diskType
		// set writeThroughVar with assetDetailsVar.writeThrough

		// Find the vDisk
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		
		extract 'assetResources' set assetResourcesVar
		// Datastore
		if (config.processData.datastore){
			for (datastore in ensureArray(assetResourcesVar.datastore)) {
				
				// Create the Resource Asset details
				datastoreIdVar = datastore['Value']
				datastoreTypeVar = 'Datastore'
				datastoreTempNameVar = datastoreTypeVar + ": " + datastoreNameVar
				
				domain Dependency
				find Storage by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + datastoreIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq datastoreTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'Name' datastoreNameVar
					'DSID-vCenter' datastoreIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' datastoreTypeVar
				}
				load 'type' with 'Datastore'
				load 'comment' with 'vDisks are stored in a Datastore'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}  
		
	}
}

//////////////////////////////
//  Datacenter
//////////////////////////////
if (config.processData.datacenter){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'datacenters'
	read labels
	iterate {

		// Set the domain
		domain Storage
		set typeVar with "Datacenter"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.datacenter ,'') set assetNameVar load 'Name'
		
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		load 'Size' with 0

		// Find the Cluster
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'id'
		elseFind Storage by \
			'Name' eq assetNameVar \
			into 'id'
	
		// Create Dependencies for each Resource Type
		extract 'assetDetails' set assetDetailsVar
		for (datastore in ensureArray(assetDetailsVar.datastore)) {
			
			// Create the Resource Asset details
			datastoreIdVar = datastore['Value']
			datastoreTypeVar = 'Datastore'
			datastoreTempNameVar = datastoreTypeVar + ": " + datastoreIdVar
			
			domain Dependency
			find Storage by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar \
				into 'dependent'
			whenNotFound 'dependent' create {
				'DSID-vCenter' assetIdVar
				'DSEP-vCenter' vCenterServerVar
				'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				'DSOT-vCenter' typeVar
				'Name' assetNameVar
			}
			
			find Storage by \
				'DSID-vCenter' eq datastoreIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq datastoreTypeVar \
				into 'asset'
			elseFind Storage by \
				'DSID-vCenter' like '%' + datastoreIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq datastoreTypeVar \
				into 'asset'
			whenNotFound 'asset' create {
				'DSID-vCenter' datastoreIdVar
				'DSEP-vCenter' vCenterServerVar
				'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
				'DSOT-vCenter' datastoreTypeVar
				'Name' datastoreTempNameVar
			}
			load 'type' with 'Datastore'
			load 'comment' with 'Datacenters contain Datastores'
			load 'status' with 'Validated'
			load 'dataFlowFreq' with 'constant'
		}
		if (config.processData.virtualNetwork){
			for (network in ensureArray(assetDetailsVar.network)) {
				
				// Create the Resource Asset details
				networkIdVar = network['Value']
				networkTypeVar = 'VirtualNetwork'
				networkTempNameVar = networkTypeVar + ": " + networkIdVar
				
				domain Dependency
				find Storage by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				elseFind Device by \
					'DSID-vCenter' like '%' + networkIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq networkTypeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' networkIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' networkTypeVar
					'Name' networkTempNameVar
				}
				load 'type' with 'Network'
				load 'comment' with 'Datacenters contain virtual Networks'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// vCenter Managed Dependency
		domain Dependency
		load 'asset' with assetNameVar
		// Find the Cluster
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar  \
			into 'asset'
		load 'dependent' with vCenterServerVar
		find Application \
			by 'Name' eq 'vCenter: ' + vCenterServerVar \
			into 'dependent'
		load 'status' with 'Validated'
		load 'type' with 'vCenter Managed'
		load 'comment' with 'vCenter Managed Data Center'
		load 'dataFlowFreq' with 'constant'
	}
}

//////////////////////////////
//  Folder
//////////////////////////////
if (config.processData.folder){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'folders'
	read labels
	iterate {

		// Set the domain
		domain Storage
		set typeVar with "Folder"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.folder ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		load 'Size' with 0
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		load 'size' with 0
		load 'scale' with 'GB'

		set freeSpaceGBVar with assetDetailsVar.freeSpaceGB.toString().tokenize('.')[0]
		def freeSpaceSizeVar = (freeSpaceGBVar == '0') ? '1' :  freeSpaceGBVar
		load 'Space - Free' with freeSpaceSizeVar

		load 'LUN' with assetDetailsVar.uuid
		load 'Format' with assetDetailsVar.type
		load 'Description' with 'Maintenance Mode: ' + assetDetailsVar.maintenanceMode + ', FS Version: ' + assetDetailsVar.fileSystemVersion + ', State: ' + assetDetailsVar.state

		// Find the Folder
		find Storage by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		elseFind Storage by \
			'LUN' like assetDetailsVar.uuid \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'

		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		if (config.processData.folder){
			for (folder in ensureArray(assetResourcesVar.folder)) {
				
				// Create the Resource Asset details
				folderIdVar = folder
				folderTypeVar = 'Folder'
				folderTempNameVar = folderTypeVar + ": " + folderIdVar
				
				domain Dependency
				find Storage by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				elseind Storage by \
					'DSID-vCenter' like '%' + folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' folderIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' folderTypeVar
					'Name' folderTempNameVar
				}
				load 'type' with 'Logical Organization'
				load 'comment' with 'Folders Contain Folders'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}

		// Folders have a parent folder.  They Depend on the parent folder
		// if there is no parent folder, it's a root folder and is supported by 'vcenter'
		if(assetDetailsVar.parentId == null){
			
			// vCenter Managed Dependency
			domain Dependency
			load 'asset' with assetNameVar
			// Find the Folder
			find Storage by \
				'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'asset'
			load 'dependent' with vCenterServerVar
			find Application \
				by 'Name' eq 'vCenter: ' + vCenterServerVar \
				into 'dependent'
			// The parent object might be a device, storage or application
			elseFind Asset \
				by 'DSID-vCenter' eq assetDetailsVar.parentId \
				and 'DSEP-vCenter' eq vCenterServerVar \
				into 'dependent'
			load 'status' with 'Validated'
			load 'type' with 'vCenter Managed'
			load 'comment' with 'vCenter Managed Folder'
			load 'dataFlowFreq' with 'constant'

		} else {
			
			// Parent Folder Dependency
			domain Dependency
			load 'asset' with assetNameVar
			// Find the Cluster
			find Storage \
				by 'DSID-vCenter' eq assetIdVar \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'asset'
			load 'dependent' with assetDetailsVar.parentId
			find Storage \
				by 'DSID-vCenter' eq assetDetailsVar.parentId \
				and 'DSEP-vCenter' eq vCenterServerVar \
				and 'DSOT-vCenter' eq typeVar  \
				into 'dependent'
			whenNotFound 'dependent' create {
				'Name' assetDetailsVar.parentId
				'DSID-vCenter' assetDetailsVar.parentId
				'DSEP-vCenter' vCenterServerVar
				'DSOT-vCenter' typeVar
			}
			load 'status' with 'Validated'
			load 'type' with 'Logical Organization'
			load 'comment' with 'Folder Depends on Parent Folder'
			load 'dataFlowFreq' with 'constant'

		}
	}
}

//////////////////////////////
//  Virtual Networks
//////////////////////////////
if (config.processData.virtualNetwork){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'virtualNetworks'
	read labels
	iterate {

		// Set the domain
		domain Device
		set typeVar with "DistributedVirtualPortgroup"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.virtualNetworks ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
		load 'Size' with 0
		
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		// Manufacturer and Model
		load 'Manufacturer' with 'VMware'
		load 'Model' with 'Virtual Network'

		// load 'Network - VLAN' with assetDetailsVar.vlan
		
		def ipPools = []
		for (ipPool in ensureArray(assetDetailsVar.ipPool)) {
			ipPools.push('id: ' + ipPool.id + ', name: ' + ipPool.id)
		}
		load 'IP Address' with ipPools.join('|')

		// Find the Datastore
		find Device by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
		
		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		if (config.processData.host){
			for (host in ensureArray(assetResourcesVar.host)) {
				
				// Create the Resource Asset details
				hostIdVar = host['Value']
				hostTypeVar = 'HostSystem'
				hostTempNameVar = hostTypeVar + ": " + hostIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'

				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'

				whenNotFound 'dependent' create {
					'DSID-vCenter' hostIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' hostTypeVar
					'Name' hostTempNameVar
					// 'Manufacturer' 'Unknown'
					// 'Model' 'Unknown'
					// 'Device Type' 'Unknown'
				}
				load 'type' with 'Cluster Runs On'
				load 'comment' with 'Cluster offer Virtual Networks'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.folder){
			for (folder in ensureArray(assetResourcesVar.folder)) {
				
				// Create the Resource Asset details
				folderIdVar = folder['Value']
				folderTypeVar = 'Folder'
				folderTempNameVar = folderTypeVar + ": " + folderIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'

				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' folderIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' folderTypeVar
					'Name' folderTempNameVar
				}
				load 'type' with 'Logical Organization'
				load 'comment' with 'Networks are organized into folders'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		// if (config.processData.virtualNetwork){
		// 	for (network in ensureArray(assetResourcesVar.network)) {

		// 		// Create the Resource Asset details
		// 		networkIdVar = network['Value']
		// 		networkTypeVar = 'VirtualNetwork'
		// 		networkTempNameVar = networkTypeVar + ": " + networkIdVar
				
		// 		domain Dependency
		// 		find Device by \
		// 			'DSID-vCenter' eq assetIdVar \
		// 			and 'DSEP-vCenter' eq vCenterServerVar \
		// 			and 'DSOT-vCenter' eq typeVar \
		// 			into 'asset'
		// 		whenNotFound 'asset' create {
		// 			'DSID-vCenter' assetIdVar
		// 			'DSEP-vCenter' vCenterServerVar
		// 			'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
		// 			'DSOT-vCenter' typeVar
		// 			'Name' assetNameVar
		// 		}

		// 		find Device by \
		// 			'DSID-vCenter' eq networkIdVar \
		// 			and 'DSEP-vCenter' eq vCenterServerVar \
		// 			and 'DSOT-vCenter' eq networkTypeVar \
		// 			into 'dependent'
		// 		elseFind Device by \
		// 			'DSID-vCenter' like '%' + networkIdVar \
		// 			and 'DSEP-vCenter' eq vCenterServerVar \
		// 			and 'DSOT-vCenter' eq networkTypeVar \
		// 			into 'dependent'
		// 		whenNotFound 'dependent' create {
		// 			'DSID-vCenter' networkIdVar
		// 			'DSEP-vCenter' vCenterServerVar
		// 			'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
		// 			'DSOT-vCenter' networkTypeVar
		// 			'Name' networkTempNameVar
		// 		}
		// 		load 'type' with 'Network'
		// 		load 'status' with 'Validated'
		// 		load 'dataFlowFreq' with 'constant'
		// 	}
		// }
		if (config.processData.vm){
			for (vm in ensureArray(assetResourcesVar.vm)) {

				// Create the Resource Asset details
				vmIdVar = vm['Value']
				vmTypeVar = 'VirtualMachine'
				vmTempNameVar = vmTypeVar + "-" + vmIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq vmIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq vmTypeVar \
					into 'asset'
				elseFind Device by \
					'DSID-vCenter' like '%' + vmIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq vmTypeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' vmIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' vmTypeVar
					'Name' vmTempNameVar
				}
				load 'type' with 'Network'
				load 'comment' with 'VMs connect to Virtual Networks'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
	}
}

//////////////////////////////
//  Virtual Switches
//////////////////////////////
if (config.processData.virtualSwitches){
	// Process the Hosts and create/update dependency to the Clusters appropriately
	rootNode 'virtualSwitches'
	read labels
	iterate {

		// Set the domain
		domain Device
		set typeVar with "VmwareDistributedVirtualSwitch"

		// Asset ID and Name and Asset Required Details
		extract 'id' set assetIdVar load 'DSID-vCenter'
		extract 'name' transform with replace(config.trimFromName.virtualSwitches ,'') set assetNameVar load 'Name'
		load 'DSOT-vCenter' with typeVar
		load 'DSEP-vCenter' with vCenterServerVar
		load 'DSOpt-vCenter-LocationType' with vCenterLocationTypeVar
		load 'Validation' with 'Validated'
		// load 'DSLS-vCenter' with NOW
			
		// Class Asset Details
		extract 'assetDetails' set assetDetailsVar
		
		// Manufacturer and Model
		load 'Manufacturer' with 'VMware'
		load 'Model' with 'Virtual Switch'

		// load 'Network - VLAN' with assetDetailsVar.vlan
		load 'DSID-VMwareUUID' with assetDetailsVar.uuid
		load 'Description' with 'MTU: ' + assetDetailsVar.uuid + "; Notes: " + assetDetailsVar.notes
		
		// Find the Datastore
		find Device by \
			'DSID-vCenter' eq assetIdVar \
			and 'DSEP-vCenter' eq vCenterServerVar \
			and 'DSOT-vCenter' eq typeVar \
			into 'id'
	
		// Create Dependencies for each Resource Type
		extract 'assetResources' set assetResourcesVar
		if (config.processData.host){
			for (host in ensureArray(assetResourcesVar.host)) {
				
				// Create the Resource Asset details
				hostIdVar = host['Value']
				hostTypeVar = 'HostSystem'
				hostTempNameVar = hostTypeVar + ": " + hostIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + hostIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq hostTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' hostIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' hostTypeVar
					'Name' hostTempNameVar
					'Manufacturer' 'Unknown'
					'Model' 'Unknown'
					'Device Type' 'Unknown'
				}
				load 'type' with 'Cluster Runs On'
				load 'comment' with 'Clusters offer Virtual Switches'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.folder){
			for (folder in ensureArray(assetResourcesVar.folder)) {
				
				// Create the Resource Asset details
				folderIdVar = folder['Value']
				folderTypeVar = 'Folder'
				folderTempNameVar = folderTypeVar + ": " + folderIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Storage by \
					'DSID-vCenter' eq folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				elseFind Storage by \
					'DSID-vCenter' like '%' + folderIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq folderTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' folderIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' folderTypeVar
					'Name' folderTempNameVar
				}
				load 'type' with 'Logical Organization'
				load 'comment' with 'Virtual Switches are organized into Folders'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		// for (portgroup in ensureArray(assetResourcesVar.portgroup)) {

		// 	// Create the Resource Asset details
		// 	portgroupIdVar = portgroup['Value']
		// 	portgroupTypeVar = 'VirtualPortGroup'
		// 	portgroupTempNameVar = portgroupTypeVar + ": " + portgroupIdVar
			
		// 	domain Dependency
		// 	find Device by \
		// 		'DSID-vCenter' eq assetIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		and 'DSOT-vCenter' eq typeVar \
		// 		into 'asset'
			// whenNotFound 'asset' create {
			// 		'DSID-vCenter' assetIdVar
			//		'DSEP-vCenter' vCenterServerVar
					// 'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
			// 		'DSOT-vCenter' typeVar
			// 		'Name' assetNameVar
			// }
		// 	find Device by \
		// 		'DSID-vCenter' eq portgroupIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		and 'DSOT-vCenter' eq portgroupTypeVar \
		// 		into 'dependent'
		// 	elseFind Device by \
		// 		'DSID-vCenter' like '%' + portgroupIdVar \
		//		and 'DSEP-vCenter' eq vCenterServerVar \
		// 		and 'DSOT-vCenter' eq portgroupTypeVar \
		// 		into 'dependent'
		// 	whenNotFound 'dependent' create {
		// 		'DSID-vCenter' portgroupIdVar
		//		'DSEP-vCenter' vCenterServerVar
					// 'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
		// 		'DSOT-vCenter' portgroupTypeVar
		// 		'Name' portgroupTempNameVar
		// 	}
		// 	load 'type' with 'Network'
		//	load 'comment' with 'Virtual Switches have Virtual Port Groups'
		// 	load 'status' with 'Validated'
		// 	load 'dataFlowFreq' with 'constant'
		// }
		if (config.processData.vm){
			for (vm in ensureArray(assetResourcesVar.vm)) {

				// Create the Resource Asset details
				vmIdVar = vm['Value']
				vmTypeVar = 'VirtualMachine'
				vmTempNameVar = vmTypeVar + "-" + vmIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Device by \
					'DSID-vCenter' eq vmIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq vmTypeVar \
					into 'dependent'
				elseFind Device by \
					'DSID-vCenter' like '%' + vmIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq vmTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' vmIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' vmTypeVar
					'Name' vmTempNameVar
				}
				load 'type' with 'Network'
				load 'comment' with 'VMs connect to Virtual Switches'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
		if (config.processData.cluster){
			for (cluster in ensureArray(assetResourcesVar.cluster)) {
		
				// Create the Resource Asset details
				clusterIdVar = cluster
				clusterTypeVar = 'ClusterComputeResource'
				clusterTempNameVar = clusterTypeVar + ": " + clusterIdVar
				
				domain Dependency
				find Device by \
					'DSID-vCenter' eq assetIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq typeVar \
					into 'asset'
				whenNotFound 'asset' create {
					'DSID-vCenter' assetIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' typeVar
					'Name' assetNameVar
				}

				find Application by \
					'DSID-vCenter' eq clusterIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq clusterTypeVar \
					into 'dependent'
				elseFind Application by \
					'DSID-vCenter' like '%' + clusterIdVar \
					and 'DSEP-vCenter' eq vCenterServerVar \
					and 'DSOT-vCenter' eq clusterTypeVar \
					into 'dependent'
				whenNotFound 'dependent' create {
					'DSID-vCenter' clusterIdVar
					'DSEP-vCenter' vCenterServerVar
					'DSOpt-vCenter-LocationType' vCenterLocationTypeVar
					'DSOT-vCenter' clusterTypeVar
					'Name' clusterTempNameVar
				}
				load 'type' with 'Networking'
				load 'comment' with 'Clusters offer Virtual Switches'
				load 'status' with 'Validated'
				load 'dataFlowFreq' with 'constant'
			}
		}
	}
}


