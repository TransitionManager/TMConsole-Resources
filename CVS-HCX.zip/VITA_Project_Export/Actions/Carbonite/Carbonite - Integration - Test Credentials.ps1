<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Integration - Test Credentials 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Test the Carbonite Credentials by connecting to a VRA.
#>

## Parameter Configuration
$Params = @{
	VRA = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '10.193.103.236'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'

$ScriptBlock = [scriptblock ] { param($params)

    ## Setup Carbonite
    Set-Location $params.TmdPsRoot
    . .\App\Providers\Carbonite.ps1
    
    ## Create a Server Object
    Write-Host "Testing Connectivity"
    $DTVRA = New-DtServer -Name ($params.VRA + ":6325") -Credential $Params.Credential
    
    ## Connect to the VRA
    $ServerInfo = Get-DtServerInfo -ServiceHost $DTVRA | ConvertTo-Json
    
	## Return a few objects for the Pwsh shell to receive as $Result
    @{
        ServerInfo = $ServerInfo
    } | ConvertTo-Json -Depth 100 -Compress
}
# $ServerInfo = Invoke-WindowsPowerShell -Params $params -ScriptBlock $ScriptBlock
Invoke-WindowsPowerShell -Params $params -ScriptBlock $ScriptBlock

$ServerInfo | Write-Host -ForegroundColor Yellow


