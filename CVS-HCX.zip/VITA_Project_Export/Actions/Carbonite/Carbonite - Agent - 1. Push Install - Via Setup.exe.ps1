<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 1. Push Install - Via Setup.exe 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	ActivationCode = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Activation Code'
	}
	CarboniteShare = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '\\JSSHARE\Data\Server\Carbonite\Migrate_8.3\DoubleTake_8.3.1.14.0\setup\dt\x64'
	}
}
## End of TM Configuration, Begin Script

## Create Progress Items
Write-Progress -Id 0 -Activity 'Install Carbonite Agent' -PercentComplete 0
Write-Progress -Id 40 -ParentId 0 -Activity 'Collect Carbonite Machine Details' -PercentComplete 0

## Collect the required credential from PS Storage
$DomainAdminCredential = Get-StoredCredential 'COV-DOMAIN-ADMIN'


## Check if Carbonite is already installed
if ((Test-Connection -ComputerName $Params.DeviceHostname -TCPPort 6325 -TimeoutSeconds 5 )) {
    
    ## Report Carbonite is already installed
    Write-Host "Carbonite is already installed"
    Write-Progress -Id 5 -ParentId 0 -Activity 'Validate Machine Access' -PercentComplete 100 -Completed -CurrentOperation "Skipped"
    Write-Progress -Id 10 -ParentId 0 -Activity 'Create DTSetup.ini file' -PercentComplete 100 -Completed -CurrentOperation "Skipped"
    Write-Progress -Id 20 -ParentId 0 -Activity 'Copy Installer to Computer' -PercentComplete 100 -Completed -CurrentOperation "Skipped"
    Write-Progress -Id 30 -ParentId 0 -Activity 'Run Carbonite Installer' -PercentComplete 100 -Completed -CurrentOperation "Skipped"
}
else {

    
    ## Validate Machine Access
    Write-Progress -Id 5 -ParentId 0 -Activity 'Validating Machine Access' -PercentComplete 5
    $RemoteMachineAdminShare = '\\' + $Params.DeviceHostName + '\c$\TMDTemp'
    
    ## Validate Access to Carbonite Share
    Test-FolderPath $Params.CarboniteShare
    
    ## Validate Access to Target Computer
    Test-FolderPath $RemoteMachineAdminShare
    Write-Progress -Id 5 -ParentId 0 -Activity 'Validating Machine Access' -PercentComplete 100 -Completed
    
    ## Create DT Setup Info
    Write-Progress -Id 10 -ParentId 0 -Activity 'Validating Machine Access' -PercentComplete 5
    $SetupPath = Join-Path $Params.CarboniteShare 'setup.exe'
    
    $DTSetup = @"
[Config]
DTSETUPTYPE=DTSO
DTACTIVATIONCODE={0}
DOUBLETAKEFOLDER="C:\Program Files\Carbonite\Replication"
QMEMORYBUFFERMAX=1024
DISKQUEUEFOLDER="C:\Program Files\Carbonite\Replication"
DISKQUEUEMAXSIZE=UNLIMITED
DISKFREESPACEMIN=50
PORT=6320
WINFW_CONFIG_OPTION=ALL
LICENSE_ACTIVATION_OPTION=0
"@ -f $Params.ActivationCode
    
    $DTSetup -replace '\n', "`r`n" | Out-File -FilePath ($RemoteMachineAdminShare + '\DTSetup.ini') -Force -Encoding ASCII
    Write-Progress -Id 10 -ParentId 0 -Activity 'DTSetup.ini file created' -PercentComplete 100 -Completed

    ## Copy Setup File to Computer
    Write-Progress -Id 20 -ParentId 0 -Activity 'Copying Installer to Computer' -PercentComplete 5
    Copy-Item `
        -Path $SetupPath `
        -Destination $RemoteMachineAdminShare `
        -Force
    Write-Progress -Id 20 -ParentId 0 -Activity 'Installer Copied to Computer' -PercentComplete 100 -Completed
    
    ## Invoke PSExec
    Write-Progress -Id 30 -ParentId 0 -Activity 'Running Carbonite Installer' -PercentComplete 5
    $PsExec = Join-Path $appPaths.winExes 'PsExec.exe'
    $InstallCommand = 'C:\Windows\System32\cmd.exe'
    $InstallArguments = '/c ""c:\TmdTemp\setup.exe" /s /v"DTSETUPINI="C:\TmdTemp\DTSetup.ini" /qn /lv "c:\TmdTemp\dtinstall.log""'

    $ErrorActionPreference = 'Continue'
    &($PsExec) ('\\' + $Params.DeviceHostName) -s -h -u $DomainAdminCredential.UserName -p $DomainAdminCredential.GetNetworkCredential().Password -r 'TMD-PsExec' -nobanner -accepteula $InstallCommand $InstallArguments *>&1 `
    | Where-Object { $_.Exception.Message -ne '' } `
    | ForEach-Object {
        if ($_.Exception) {
            $_.Exception.Message
        }
        else { 
            $_
        }
    } `
    | Tee-Object -Variable PsExecSessionOutput | Write-Host | Out-Null
    $ErrorActionPreference = 'Stop'

    $LastLine = $PsExecSessionOutput | Select-Object -Last 1
    if ($LastLine.SubString($LastLine.length - 7, 7) -eq 'code 0.') {
        Write-Progress -Id 30 -ParentId 0 -Activity 'Starting Carbonite Services' -PercentComplete 75 -Completed
    }
    else {
        Write-Progress -Id 30 -ParentId 0 -Activity 'Installation Failed' -PercentComplete 100 -Completed
        Throw "Installation Failed"
    }

    ## Wait for Carbonite Serivces to answer
    $Ready = $false
    while (-not $Ready) {

        ## Sleep for a second
        Start-Sleep -Seconds 5

        ## Test if the TCP Port is open
        $Ready = Test-Connection -ComputerName $Params.DeviceHostname -TCPPort 6325 -TimeoutSeconds 2

    }
    
    ## Mark Completion of installation
    Write-Host 'Carbonite Installation Completed'
    Write-Progress -Id 30 -ParentId 0 -Activity 'Installation Completed' -PercentComplete 100 -Completed

}

## Get The Server's details from the machine - Using Windows PowerShell Wrapper
Write-Progress -Id 40 -ParentId 0 -Activity 'Getting Carbonite Server Details' -PercentComplete 5
$GetServerDetailScriptBlock = { param($Params, $DomainAdminCredential)
    
    ## Setup Carbonite
    Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll'
    
    # Get the server details to confirm installation
    Write-Host 'Getting server info'
    $DTServer = New-DtServer -Name ($Params.DeviceHostname + ":6325") -Credential $DomainAdminCredential
    $DTServerInfo = Get-DtServerInfo -ServiceHost $DTServer
    
    ## Make sure an object was returned
    if (-not $DTServerInfo) {
        Write-Host 'Carbonite Double-Take DID NOT install properly.'
        Throw 'Carbonite Double-Take DID NOT install properly.'
    }
    else {
        @{ 
            DTServerInfo = $DTServerInfo
        } | ConvertTo-Json -Compress
    }
}
Invoke-WindowsPowerShell -Params @($Params, $DomainAdminCredential) -ScriptBlock $GetServerDetailScriptBlock -ErrorAction Continue

## Make sure a DTServerInfo is returned
if ($DTServerInfo -eq "") {
    throw "Unable to retrieve Carbonite details from the server."

}

## Convert the XML portion of the Server Info
[xml]$SystemStateXml = $DTServerInfo.SystemStateDefinition
$SystemState = $SystemStateXml | ConvertFrom-Xml

## Check if the correct version is installed
$InstalledVersion = $SystemState.Configuration.ServiceInfo.ProductVersion.Value
Write-Host "Installed Carbonite Version:"$InstalledVersion
if ($InstalledVersion -ne '8.3.1.14.0') {
    Write-Host 'The incorrect version of Carbonite Replication is installed.  Expected 8.3.1.14.0, but got'$InstalledVersion
    throw 'The incorrect version of Carbonite Replication is installed.'
}

## Update the Asset Fields
Update-TMTaskAsset -Field 'DSID-Carbonite' -Value $DTServerInfo.NodeLockedServerInfo
Update-TMTaskAsset -Field 'CM-Activation Code' -Value $SystemState.Configuration.ServiceInfo.ActivationCode.Value
Update-TMTaskAsset -Field 'CM-Installed Version' -Value $InstalledVersion
Write-Progress -Id 40 -ParentId 0 -Activity 'Carbonite Server Details Collected' -PercentComplete 100 -Completed


