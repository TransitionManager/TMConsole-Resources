<####### TransitionManager Action Script ######

	ActionName			= Carbonite - Agent - 3. Apply Server Settings from TM 
	ProviderName		= Carbonite 
	CredentialName 		= 

	Description			= Apply Server Property Settings on VRA
#>

## Parameter Configuration
$Params = @{
	DeviceHostname = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
	}
	'ServerOption-EncryptNetworkData' = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= '1'
	}
}
## End of TM Configuration, Begin Script

## Get the Domain Admin Credential from PS Store
$DomainAdminCredential = Get-StoredCredential -CredentialName 'COV-DOMAIN-ADMIN'
 
## Load Carbonite Replication Module
Write-Progress -Id 10 -ParentId 0 -Activity "Load Carbonite Replication Module" -PercentComplete 5

# Set-Location $params.TmdPsRoot
# . .\App\Providers\Carbonite.ps1

## Import Doubletake Module
Import-Module 'C:\Program Files\Carbonite\Replication\Console\DoubleTake.PowerShell.dll' -UseWindowsPowerShell
    
    
$CompatibilitySession = Get-PSSession -Name WinPSCompatSession
Invoke-Command -Session $CompatibilitySession -ArgumentList @($Params, $DomainAdminCredential) -ScriptBlock {
   param($Params, $DomainAdminCredential)
    
    Write-Progress -Id 10 -ParentId 0 -Activity  "Carbonite Replication Module Loaded" -PercentComplete 100 -Completed
    
    $ErrorActionPreference = 'Continue'

    ## Create a Server Object
    Write-Host "TMD-Update:Progress: 30"
    Write-Host "Connecting to ["$params.DeviceHostname"] as ["$DomainAdminCredential.Username"]"
    $DTServer = New-DtServer -Name ($params.DeviceHostname + ":6325") -Credential $DomainAdminCredential

    ## Get the Resulting DT Server Activation Status
    $CompatibilitySessionerverOptions = $params.PSObject.Properties | Where-Object { $_.Name -like 'ServerOption-*' }
    $CompatibilitySessionerverOptions | ForEach-Object {
        
        # Deal with appropriate typing
        if ($_.Value -eq 'true') { $OptionValue = $True }
        if ($_.Value -eq 'false') { $OptionValue = $False }
        if ($_.Value -match "^\d+$") { $OptionValue = [Int64]$_.Value }
    
        $OptionName = $_.Name.Replace('ServerOption-', '')
    
        Write-Host "Changing Options on Server"$OptionName" = "$OptionValue
        Set-DTOption -ServiceHost $DTServer -Setting (@{$OptionName = $OptionValue })
    }
    # }
    # Invoke-WindowsPowerShell -Params $Params -ScriptBlock $CompatibilitySessioncriptBlock
}


