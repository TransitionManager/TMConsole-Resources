<####### TransitionManager Action Script ######

	ActionName			= HCX - Post-Migration Checklist 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= Confirms the Source Machine is down, and the Target is up.  Target HCX Settings for the machine are then validated against the Target vCenter.
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	SourcevCenter = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-vCenter'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	Network = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network'
	}
	Folder = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Target Folder'
	}
	ClusterName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr02-w01-comp01'
	}
	TargetvCenter = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr02-w01vc01.cov.virginia.gov'
	}
	Datastore = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Datastore'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.SourcevCenter } | Select-Object -ExpandProperty Name)


## Create Progress Items
Write-Progress -Id 10 -ParentId 0 -Activity 'Log Into vCenter Servers' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 20 -ParentId 0 -Activity 'Check State of VM on Source vCenter' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 30 -ParentId 0 -Activity 'Check State of VM on Target vCenter' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 40 -ParentId 0 -Activity 'Checking Datastore Location' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 50 -ParentId 0 -Activity 'Checking Folder Placement' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 60 -ParentId 0 -Activity 'Checking Network Connections' -PercentComplete 0 -CurrentOperation 'Pending'

## 
## Allow Insecure SSL
## 
if (ConvertTo-Boolean $Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

##
## Connect to the vCenter Servers
##
Write-Progress -Id 10 -ParentId 0 -Activity 'Log Into vCenter Servers' -PercentComplete 5 -CurrentOperation 'Signing Into Source vCenter'
Connect-ViServer -Server $Params.SourcevCenter -Credential $vCenterCredential  | Out-Null
Write-Progress -Id 10 -ParentId 0 -Activity 'Log Into vCenter Servers' -PercentComplete 33 -CurrentOperation 'Signing Into Target vCenter'
Connect-ViServer -Server $Params.TargetvCenter -Credential $vCenterCredential | Out-Null
Write-Progress -Id 10 -ParentId 0 -Activity 'Log Into vCenter Servers' -PercentComplete 66 -CurrentOperation 'Getting VM from vCenters'

## 
## Check the VMs in each vCenter
## 
$SourceVM = Get-VM -Server  $Params.SourcevCenter | Where-Object { $_.Name -like $Params.VMName + '*' }
$TargetVM = Get-VM -Name $Params.VMName -Server $Params.TargetvCenter
Write-Progress -Id 10 -ParentId 0 -Activity 'Log Into vCenter Servers' -PercentComplete 100 -CurrentOperation 'Getting VM from vCenters' -Completed

## Confirm the Machine is Powered Off in the Source and On in the Target
if (($SourceVM.PowerState -eq 'PoweredOff') -and ($TargetVM.PowerState -eq 'PoweredOn') ) {
    Write-Progress -Id 20 -ParentId 0 -Activity 'VM is DOWN on Source vCenter' -PercentComplete 100 -Completed
    Write-Progress -Id 30 -ParentId 0 -Activity 'VM is UP on Target vCenter' -PercentComplete 100 -Completed
    Write-Host "The VM is only running in QTS." -ForegroundColor Cyan
}
else {
    $Errors = $True
    Write-Progress -Id 20 -ParentId 0 -Activity 'VM is DOWN on Source vCenter' -PercentComplete 25
    Write-Progress -Id 30 -ParentId 0 -Activity 'VM is UP on Target vCenter' -PercentComplete 25
    Write-Host 'The VM is has the following state:  SOURCE:'$SourceVM.PowerState', TARGET: '$TargetVM.PowerState -ForegroundColor Magenta
}

##
## Check Device Datastore
##
# $TargetDatastoreCluster = Get-DatastoreCluster -Server $Params.TargetvCenter -Name $Params.Datastore

### Confirm DataStore Cluster assignments
# ## Check the Data Store the VM uses and confirm it's in the list of Datastores the Cluster uses
# if ($TargetDatastoreCluster.ExtensionData.ChildEntity.Value -contains $TargetVM.ExtensionData.Datastore.Value) {
#     Write-Progress -Id 40 -ParentId 0 -Activity 'Target Datastore is Correct' -PercentComplete 100 -Completed
#     Write-Host  ('The VM is in the correct Datastore Cluster: ' + $DatastoreClusterName ) -ForegroundColor Cyan
# }
# else {
#     $Errors = $True
#     Write-Progress -Id 40 -ParentId 0 -Activity 'Datastore is INCORRECT' -PercentComplete 25
#     $INCORRECTDataStore = Get-Datastore -Server $Params.TargetvCenter -Id $TargetVM.ExtensionData.Datastore[0].Value
#     Write-Host ('The VM is NOT in the correct Datastore!  Required Datastore Cluster: ' + `
#             $DatastoreClusterName + `
#             ', Current Datastore: ' + $INCORRECTDataStore.Name
#     ) -ForegroundColor Magenta
# }


## Datastore Clusters are in use, get the Datastore Cluster and it's component member details
$TargetDatastore = Get-Datastore -Server $Params.TargetvCenter -Name $Params.Datastore

## Confirm Singular Datastore assignment
if (-Not ($TargetVM.DatastoreIdList -contains $TargetDatastore.Id)) {
    $Errors = $True
    Write-Progress -Id 40 -ParentId 0 -Activity 'Datastore is INCORRECT' -PercentComplete 25
    $INCORRECTDataStore = Get-Datastore -Server $Params.TargetvCenter -Id $TargetVM.ExtensionData.Datastore[0].Value
    Write-Host ('The VM is NOT in the correct Datastore!  Required Datastore Cluster: ' + `
            $Params.Datastore + `
            ', Current Datastore: ' + $INCORRECTDataStore.Name
    ) -ForegroundColor Magenta
}
else {
    Write-Progress -Id 40 -ParentId 0 -Activity 'Target Datastore is Correct' -PercentComplete 100 -Completed
    Write-Host ('The VM is in the correct Datastore: ' + $Params.Datastore ) -ForegroundColor Cyan
}


##
## Check the Folder
##
if ($Params.Folder -like '*/*') {
    
    ## Get the Root Server Instance and folder
    $ServiceInstance = Get-View ServiceInstance -Server $Params.TargetvCenter
    $RootFolderId = Get-View -Server $Params.TargetvCenter -Id $ServiceInstance.Content.RootFolder -Property Value | Select-Object -ExpandProperty MoRef | Select-Object -ExpandProperty Value
   
    ## Walk up the tree from the root folder
    $RootFolder = Get-Folder -Id $RootFolderId -Server $Params.TargetvCenter -ErrorAction SilentlyContinue
    
    ## Split the /folder/path/into an array
    $TargetFolderPath = $Params.Folder -split ('/')
    
    ## Walk up the Folder Path tree to get the end folder
    foreach ($FolderName in $TargetFolderPath) {
        
        ## If the string is empty, skip the loop (This allows for a leading or trailing /)
        if ($FolderName -eq '') {
            continue
        }

        $RootFolder = Get-Inventory -Name $FolderName -Location $RootFolder -Server $Params.TargetvCenter -ErrorAction SilentlyContinue
        if ((Get-Inventory -Server $Params.TargetvCenter -Location $RootFolder -NoRecursion | Select-Object -ExpandProperty Name) -contains "vm") {
            $RootFolder = Get-Inventory -Name "vm" -Location $RootFolder -Server $Params.TargetvCenter -NoRecursion
        }
    }

    ## Get the last folder that was used
    $RootFolder | Where-Object { $_ -is [VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl] } | Where-Object {
        $TargetFolder = Get-Folder -Name $_.Name -Location $RootFolder.Parent -NoRecursion -Server $Params.TargetvCenter
    }
    
}
else {
    
    ## Get the Container Folder  By Name only
    $TargetFolder = Get-Folder -Server $Params.TargetvCenter -Name $Params.TargetFolder
}

## Check the Folder Placement
if ($TargetVM.FolderId -Eq $TargetFolder.Id) {
    Write-Progress -Id 50 -ParentId 0 -Activity 'Target Folder is Correct' -PercentComplete 100 -Completed
    Write-Host ('The VM is in the correct Folder: ' + $Params.Folder ) -ForegroundColor Cyan
}
else {
    $Errors = $True
    Write-Progress -Id 50 -ParentId 0 -Activity 'Target Folder is INCORRECT' -PercentComplete 25
    Write-Host ('The VM is NOT the correct Folder!  Required Folder: ' + `
            $Params.Folder + `
            ', Current Folder: ' + $TargetVM.Folder.Name
    ) -ForegroundColor Magenta
}

##
## Check the Network
##
$TargetNetwork = Get-VirtualNetwork -Server $Params.TargetvCenter -Name $Params.Network
if ($TargetVM.ExtensionData.Network -eq $TargetNetwork.id) {
    Write-Progress -Id 60 -ParentId 0 -Activity 'Target Network is Correct' -PercentComplete 100 -Completed
    Write-Host  ('The VM is on the correct Network: ' + $Params.Network ) -ForegroundColor Cyan
}
else {
    $Errors = $True
    Write-Progress -Id 50 -ParentId 0 -Activity 'Target Network is INCORRECT' -PercentComplete 25
    Write-Host ('The VM is NOT on the correct Network!  Required Network: ' + `
            $Params.Network + `
            ', Current Network: ' + $TargetVM.ExtensionData.Network
    ) -ForegroundColor Magenta
}

## Check for Errors
if ($Errors) {
    Write-Host "The Machine did not pass all of the checks. Check the logs." -ForegroundColor Magenta
    Throw 'The Machine did not pass all of the checks. Check the logs.'
}
else {
    Write-Host 'All Tests have passed.' -ForegroundColor Cyan
}


