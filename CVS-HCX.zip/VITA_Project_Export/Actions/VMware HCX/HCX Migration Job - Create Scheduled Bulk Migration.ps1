<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Job - Create Scheduled Bulk Migration 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
		Value			= 'vpr01-hcxmgr01.cov.virginia.gov'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Yes'
	}
	Folder = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Target Folder'
	}
	Network = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network'
	}
	ClusterName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr02-w01-comp01'
	}
	DestVCenter = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'vpr02-w01vc01.cov.virginia.gov'
	}
	DestDatastore = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target Datastore'
	}
}
## End of TM Configuration, Begin Script

## List the Required Credentials
$RequiredCredentials = @(
  
    ## vCenter Servers
    @{
        Id                 = 11
        Name               = 'VITA-vCenter-CESC-VPR01'
        URL                = 'vpr01-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 12
        Name               = 'VITA-vCenter-CESCVI-VC02'
        URL                = 'cescvi-vc02.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    
    }
    @{
        Id                 = 13
        Name               = 'VITA-vCenter-QTS-VPR02'
        URL                = 'vpr02-w01vc01.cov.virginia.gov'
        AuthenticationTest = [scriptblock] {
            Connect-VIServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
  
    ## HCX Servers
    @{
        Id                 = 14
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vpr01-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
    @{
        Id                 = 15
        Name               = 'VITA-HCX-HCX01'
        URL                = 'vc02-hcxmgr01.cov.virginia.gov' 
        AuthenticationTest = [scriptblock] {
            Connect-HcxServer -Credential $SuppliedCredential -Server $URL | Out-Null
        }
    }
)

## Get the HCX and vCenter Credentials from the Local Store
$HcxCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.HCXServer } | Select-Object -ExpandProperty Name)
$vCenterCredential = Get-StoredCredential -CredentialName ($RequiredCredentials | Where-Object { $_.URL -eq $Params.DestVCenter } | Select-Object -ExpandProperty Name)

## Create Progress Items
Write-Progress -Id 0 -Activity 'Create HCX Migrations' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 10 -ParentId 0 -Activity 'Validate vCenter Server' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 20 -ParentId 0 -Activity 'Validate HCX Server' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 30 -ParentId 0 -Activity 'Validate HCX Destination Network' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 40 -ParentId 0 -Activity 'Validate HCX Destination Folder' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 50 -ParentId 0 -Activity 'Validate Source VMWare Tools' -PercentComplete 0 -CurrentOperation 'Pending'
Write-Progress -Id 60 -ParentId 0 -Activity 'Validate Source VMware Hardware Version' -PercentComplete 0 -CurrentOperation 'Pending'

## Allow SSL Certificates that are not trusted
if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Write Initial Progress Indicators 
Write-Progress -Id 0 -Activity 'Validate HCX Migration Job Readiness' -PercentComplete 0

## Authenticate to TM and HCX
Write-Progress -Id 1 -ParentId 0 -Activity 'Authenticating' -PercentComplete 5 -CurrentOperation 'Authenitcating'
Import-Module TransitionManager
Connect-HCXServer -Server $Params.HCXServer -Credential $HcxCredential | Out-Null
$DestvCenter = Connect-VIServer -Server $Params.DestVCenter -Credential $vCenterCredential

## Ensure the connections were established.
if (-not $DestvCenter -or -not $global:DefaultHcxServers  ) {
    throw 'Authentication Failure.  Please check your username and password'
}

## Get the VM reference
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 10 -CurrentOperation 'Getting HCX Data'
$HcxSourceSite = Get-HCXSite -Source -Server $Params.HCXServer
$HCXDestinationSite = Get-HCXSite -Destination -Server $Params.HCXServer
$HcxVM = Get-HCXVM -Name $Params.VMName -Server $Params.HCXServer -Site $HcxSourceSite

## Get Network Configurations
$SourceNetwork = Get-HCXNetwork -Site $HcxSourceSite | Where-Object { $_.Name -eq $Params.Network }
$DestinationNetwork = Get-HCXNetwork -Site $HcxDestinationSite | Where-Object { $_.Name -eq $Params.Network }
    
## If the Networks were found, add them to the network map
$MapNetworks = @{
    SourceNetwork      = $SourceNetwork
    DestinationNetwork = $DestinationNetwork
}

## Ensure we have a network map
if ($MapNetworks.Count -gt 0) {
    $NetworkMapping = $MapNetworks | ForEach-Object { New-HCXNetworkMapping -SourceNetwork $_.SourceNetwork -DestinationNetwork $_.DestinationNetwork }
}
else {
    Throw "Unable to locate Target Network."
}


## Get Target Folder (Via a Path lookup using vCenter)
if ($Params.Folder -like '*/*') {
    
    ## Get the Root Server Instance and folder
    $ServiceInstance = Get-View ServiceInstance -Server $DestvCenter
    $RootFolderId = Get-View -Server $DestvCenter -Id $ServiceInstance.Content.RootFolder -Property Value | Select-Object -ExpandProperty MoRef | Select-Object -ExpandProperty Value
   
    ## Walk up the tree from the root folder
    $RootFolder = Get-Folder -Id $RootFolderId -Server $DestvCenter -ErrorAction SilentlyContinue
    
    ## Split the /folder/path/into an array
    $TargetFolderPath = $Params.Folder -split ('/')
    
    ## Walk up the Folder Path tree to get the end folder
    foreach ($FolderName in $TargetFolderPath) {
        
        ## If the string is empty, skip the loop (This allows for a leading or trailing /)
        if ($FolderName -eq '') {
            continue
        }

        $RootFolder = Get-Inventory -Name $FolderName -Location $RootFolder -Server $DestvCenter -ErrorAction SilentlyContinue
        if ((Get-Inventory -Location $RootFolder -NoRecursion | Select-Object -ExpandProperty Name) -contains "vm") {
            $RootFolder = Get-Inventory -Name "vm" -Location $RootFolder -Server $DestvCenter -NoRecursion
        }
    }

    ## Get the last folder that was used
    $RootFolder | Where-Object { $_ -is [VMware.VimAutomation.ViCore.Impl.V1.Inventory.FolderImpl] } | Where-Object {
        $DestinationFolder = Get-Folder -Name $_.Name -Location $RootFolder.Parent -NoRecursion -Server $DestvCenter
    }
    
    ## Trim the ID down to a string that HCX can use to find the folder by ID
    $DestFoldervCenterId = $DestinationFolder.Id.Replace('Folder-group-', '*')

    ## Get the Container Folder object
    $HcxDestFolder = Get-HCXContainer | Where-Object { $_.Id -like $DestFoldervCenterId }
}
else {
    
    ## Get the Container Folder  By Name only
    $HcxDestFolder = Get-HCXContainer -Type Folder -Name $Params.TargetFolder
}

## Ensure we have a target datastore
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 60 -CurrentOperation 'Identifying Destination Datastore'
$DestinationDatastore = Get-HCXDatastore -Name $Params.DestDatastore -Site $HCXDestinationSite

## Check that the Datastore was a unique match.
if($DestinationDatastore.count -gt 1){
    Write-Host 'The Datastore'$Params.DestDatastore'could not be uniquely identified.  Please check the value in the Device, '$Params.VMName' and try again'.
    throw 'The Datastore could not be found.'
}

## Get Cluster Configuration
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 70 -CurrentOperation 'Identifying Destination Compute Container'
$DestinationComputeContainer = Get-HCXContainer -Name $Params.ClusterName -Site $HCXDestinationSite -Type 'ComputeContainer'
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 80 -CurrentOperation 'Validating HCX Job'

# Create the Migration Job
$MigrationJobSplat = @{
    VM                     = $HcxVM
    MigrationType          = 'Bulk'
    SourceSite             = $HcxSourceSite
    DestinationSite        = $HCXDestinationSite
    Folder                 = $HcxDestFolder
    TargetComputeContainer = $DestinationComputeContainer
    TargetDatastore        = $DestinationDatastore
    NetworkMapping         = $NetworkMapping
    DiskProvisionType      = 'Thick'
    UpgradeVMTools         = $false
    RemoveISOs             = $false
    ForcePowerOffVm        = $true
    RetainMac              = $True
    UpgradeHardware        = $False
    RemoveSnapshots        = $False
    ScheduleStartTime      = ((Get-Date).AddDays(365))
    ScheduleEndTime        = ((Get-Date).AddDays(366))
}
$NewMigration = New-HCXMigration @MigrationJobSplat

Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 100 -CurrentOperation 'HCX Job Validated' -Completed
            
## start the migration job
if ($NewMigration) {
    Write-Progress -Id 2 -ParentId 0 -Activity 'Submit and Start Job' -PercentComplete 5
    $MigrationJob = Start-HCXMigration -Migration $NewMigration -Confirm:$false
    
    ## Check to make sure the Migration Job started
    if(-Not $MigrationJob) {
        Write-Host 'There was an error starting the migration job.'
        Throw 'There was an error starting the migration job.'
    }

    Write-Host 'Started Migration Job: '$MigrationJob.Id
    Write-Progress -Id 2 -ParentId 0 -Activity 'Submit and Start Job' -PercentComplete 100 -Completed
    Write-Progress -Id 0 -Activity 'HCX Job Started' -PercentComplete 100 -Completed
    
}


