<####### TransitionManager Action Script ######

	ActionName			= Test HCX Authentication 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
	get_credential_TMUserAccount = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM Username and password'
	}
	TMServerName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
}
## End of TM Configuration, Begin Script

## Define the HCX Servers to connect to for Job Lookup
$HcxServer = 'vc02-hcxmgr01.cov.virginia.gov'

if (ConvertTo-Boolean $Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Write Initial Progress Indicators 
Write-Progress -Id 0 -Activity 'Validate HCX Jobs for this event' -PercentComplete 0

## Authenticate to TM and HCX
Write-Progress -Id  0 -Activity 'Getting HCX Jobs' -PercentComplete 5

## All HCX Jobs
$AllHCXJobs = [System.Collections.ArrayList]@()

## Get the HCX Jobs from all of the Servers
foreach ($HCXServer in $HcxServers) {
    
    $uri = 'https://' + $HCXServer + '/hybridity/api/sessions'
    $JSONBody = [ordered]@{
        username = $Credential.username
        password = $Credential.GetNetworkCredential().Password
    } | ConvertTo-Json -Depth 2
    $XMLResponse = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -SkipCertificateCheck -Body $JSONBody -ContentType 'application/json;charset=UTF-8' -SessionVariable HCX
    # $response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
    $Response = $XMLResponse | ConvertFrom-XML
    $UUID = $Response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
    
    ##   
    ## Get the Migrations
    ## 
    $JSONBody = @{
        filter  = @{
            skipDrafts      = $True 
            createTimeEpoch = 1597723200000
        }
        options = @{
            resultLevel = "MOBILITYGROUP_ITEMS"
            compat      = "2.1"
        }
    } | ConvertTo-JSON -Compress -Depth 2
    $uri = 'https://' + $HCXServer + '/hybridity/api/migrations?action=query&hcspUUID=' + $UUID[0]
    $MigrationJobs = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -Body $JSONBody -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX
    
    ## Add these jobs to the total list
    $AllHCXJobs.AddRange($MigrationJobs.data.items) | Out-Null
}


## Get the List of Devices from TM for this event
Write-Progress -Id 0 -Activity 'Getting TM Server List' -PercentComplete 50
Import-Module TransitionManager
New-TMSession -Server $Params.TMServerName -Credential $Params.'TM User Account' -AllowInsecureSSL $True


