<####### TransitionManager Action Script ######

	ActionName			= HCX Migration Job - Update Existing Job Configuration 
	ProviderName		= VMware HCX 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	TMAssetId = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Id'
	}
	TMServerName = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'ulap04670.cov.virginia.gov'
	}
	get_credential_TMUserAccount = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'TM Username and Password'
	}
	HCXServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'DSEP-VMwareHCX'
	}
	AllowInsecureSSL = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'True'
	}
}
## End of TM Configuration, Begin Script

$DefaultDatastore = 'T1-1102-HCX'
$DefaultNetwork = '887-NGIS-TST-SEC-CESC'
$DefaultFolder = 'HCX'
$DefaultCluster = 'vpr02-w01-comp01'


if ($Params.AllowInsecureSSL) {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore | Out-Null
}

## Write Initial Progress Indicators 
Write-Progress -Id 0 -Activity 'Validate HCX Migration Job Readiness' -PercentComplete 0
Write-Progress -Id 1 -ParentId 0 -Activity 'Validate Job Configuration' -PercentComplete 0



## Authenticate to TM and HCX
Write-Progress -Id 1 -ParentId 0 -Activity 'Validating Job Configuration' -PercentComplete 5 -CurrentOperation 'Authenitcating'
$TMCredential = $Params.'TM User Account'
Import-Module TransitionManager
New-TMSession -Server $Params.TMServerName -Credential $TMCredential -AllowInsecureSSL $True
Connect-HCXServer -Server $Params.HCXServer -Credential $Credential | Out-Null

# Authenticate to the API
$uri = 'https://' + $params.HCXServer + '/hybridity/api/sessions'
$JSONBody = [ordered]@{
    username = $Credential.username
    password = $Credential.GetNetworkCredential().Password
} | ConvertTo-Json -Depth 2
$XMLResponse = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -SkipCertificateCheck -Body $JSONBody -ContentType 'application/json;charset=UTF-8' -SessionVariable HCX
$response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values
$Response = $XMLResponse | ConvertFrom-XML
$UUID = $Response.'com.vmware.vchs.hybridity.protocol.RestResponse'.data.myHashMap.entry.'org.codehaus.jettison.json.JSONObject'.myHashMap.entry.Values

## Get the Migrations
$JSONBody = @{
    filter  = @{
        skipDrafts      = $True 
        createTimeEpoch = 1597723200000
    }
    options = @{
        resultLevel = "MOBILITYGROUP_ITEMS"
        compat      = "2.1"
    }
} | ConvertTo-JSON -Compress -Depth 2
$uri = 'https://' + $params.HCXServer + '/hybridity/api/migrations?action=query&hcspUUID=' + $UUID[0]
# $HCXVM = Get-HCXVM -Name $Params.VMName
$MigrationJobs = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -Body $JSONBody -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX

## Find the migration for this machine
$VMMigration = $MigrationJobs.data.items | Where-Object { $_.entity.entityName -eq $Params.VMName } | Sort-Object -Property 'creationDate' -Descending | Select-Object -First 1
if ($VMMigration) {
    Write-Host 'Found Migration Job:'$VMMigration.id
}
else {
    throw ('Unable to find a migration Job for' + $Params.VMName)
}

## Get the HCX Source and Target Sites
# $HcxSourceSite = Get-HCXSite -Source -Server $Params.HCXServer
$HCXDestinationSite = Get-HCXSite -Destination -Server $Params.HCXServer

## Create an Updated Placement for the VM
Write-Host 'Updating HCX Configuration - Target Folder: '$DefaultFolder
$DestinationFolder = Get-HCXContainer -Name $DefaultFolder -Site $HCXDestinationSite
$NewFolder = @{ 
    containerId   = $DestinationFolder.Id
    containerType = $DestinationFolder.Type
}

$PlacementCluster = $VMMigration.placement | Where-Object { $_.type -eq 'cluster' }
$NewCluster = @{
    containerId   = $PlacementCluster.Id
    containerType = $PlacementCluster.Type
}
$UpdatedPlacement = @($NewFolder, $NewCluster)

## Create update for Entity Path
$entityDetails = @{
    entityId   = $VMMigration.entity.entityId
    entityName = $VMMigration.entity.entityName
    entityType = $VMMigration.entity.entityType
}

## Create update for Source
$source = @{
    endpointId   = $VMMigration.source.endpointId
    endpointName = $VMMigration.source.endpointName
    endpointType = $VMMigration.source.endpointType
    resourceId   = $VMMigration.source.resourceId
    resourceType = $VMMigration.source.resourceType
    resourceName = $VMMigration.source.resourceName
}
## Create update for Destination
$destination = @{
    endpointId   = $VMMigration.destination.endpointId
    endpointName = $VMMigration.destination.endpointName
    endpointType = $VMMigration.destination.endpointType
    resourceId   = $VMMigration.destination.resourceId
    resourceType = $VMMigration.destination.resourceType
    resourceName = $VMMigration.destination.resourceName
}

## Create update for Storage
$storage = @{
    diskProvisionType = $VMMigration.storage.defaultStorage.diskProvisionType
    datastoreId       = $VMMigration.storage.defaultStorage.datastoreId
    
}

## Create the Update Request Body
$VMMigrationUpdate = @{
    migrationId = $VMMigration.id
    input       = @{
        migrationType = 'VR'
        entityDetails = $entityDetails
        source        = $source
        destination   = $destination
        storage       = $storage
        placement     = $UpdatedPlacement
        networks      = $VMMigration.networkParams.defaultMappings
        schedule      = $VMMigration.switchoverParams.schedule
    }
}

$UpdateMigrationJSON = @{migrations = @($VMMigrationUpdate) } | ConvertTo-JSON -Compress -Depth 100
$uri = 'https://' + $params.HCXServer + '/hybridity/api/migrations?action=update&hcspUUID=' + $UUID[0]
try {
    $UpdateResponse = Invoke-RestMethod -Uri $uri -Method Post -Credential $Credential -Body $UpdateMigrationJSON -SkipCertificateCheck -ContentType 'application/json;charset=UTF-8' -WebSession $HCX
    if ($UpdateResponse.errors) {
        ## The update resulted in an error
        Write-Host $UpdateResponse.errors.message
    }

    
}
catch {
    throw $_
}


