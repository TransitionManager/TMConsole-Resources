<####### TransitionManager Action Script ######

	ActionName			= PsExec - Remove Source VM Software 
	ProviderName		= TransitionManager 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Device Admin Credential'
	}
	DeviceHostName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Network - Hostname'
		Value			= 'hostn'
	}
}
## End of TM Configuration, Begin Script

## Create Progress Items
Write-Progress -Id 0 -Activity 'Removing VITA Software' -PercentComplete 0

    
## Validate Machine Access
Write-Progress -Id 0 -Activity 'Validating Machine Access' -PercentComplete 5


## Create Script Block for remote Target Computer
$ScriptBlock = {

	# Remove Symantec Netbackup
	$application = Get-WmiObject -Class Win32_Product -Filter "Name = 'Symantec NetBackup Client'"
	if($application){
    	$application.Uninstall()
    }
    
    

	# Remove Power Path
	$application = Get-WmiObject -Class Win32_Product -Filter "Name = 'EMC PowerPath 6.1 (64bit)'"
	if($application){
    	$application.Uninstall()
    }

}

## Validate Machine Access
$RemoteMachineAdminShare = '\\' + $Params.DeviceHostName + '\c$\TMDTemp'
 
## Validate Access to Target Computer
Test-FolderPath $RemoteMachineAdminShare
 
## Create Software Removal Script on Remote Machine
$ScriptBlock | Out-File -FilePath ($RemoteMachineAdminShare + '\Remove-VitaSoftware.ps1') -Force -Encoding ASCII

## Invoke PSExec
Write-Progress -Id 30 -ParentId 0 -Activity 'Software Removal' -PercentComplete 5
$PsExec = Join-Path $appPaths.winExes 'PsExec.exe'
$InstallCommand = 'C:\Windows\system32\WindowsPowerShell\v1.0\powershell.exe'
$InstallArguments = 'c:\TmdTemp\Remove-VitaSoftware.ps1 -NoProfile -NonInteractive'

$ErrorActionPreference = 'Continue'
&($PsExec) ('\\' + $Params.DeviceHostName) -s -h -u $Params.'Device Admin Credential'.UserName -p $Params.'Device Admin Credential'.GetNetworkCredential().Password -r 'TMD-PsExec' -nobanner -accepteula $InstallCommand $InstallArguments *>&1 `
| Where-Object { $_.Exception.Message -ne '' } `
| ForEach-Object {
	if ($_.Exception) {
		$_.Exception.Message
	}
} `
| Tee-Object -Variable PsExecSessionOutput | Write-Host | Out-Null

## Get the last line of the output to ensure that PSExec completed
$LastLine = $PsExecSessionOutput | Select-Object -Last 1
if ($LastLine.SubString($LastLine.length - 7, 7) -eq 'code 0.') {
	Write-Progress -Id 0 -Activity 'Vita Sofware Removed' -PercentComplete 100 -Completed
}
else {
	Throw "Removal Failed"
}


