<####### TransitionManager Action Script ######

	ActionName			= VMware vCenter - Update VM Tags 
	ProviderName		= VMware vCenter 
	CredentialName 		= 

	Description			= 
#>

## Parameter Configuration
$Params = @{
	VMName = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'Name'
	}
	vCenterServer = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'CM-Target vCenter'
	}
	Tags = @{
		Description		= ''
		Context			= 'DEVICE'
		FieldLabel		= 'P2V tags'
	}
	get_credential_DeviceAdminCredential = @{
		Description		= ''
		Context			= 'USER_DEF'
		FieldLabel		= ''
		Value			= 'Device Admin Credential'
	}
}
## End of TM Configuration, Begin Script

## Progress - Start Task
Write-Progress -Id 1 -ParentId 0 -Activity 'Logging into vCenter' -PercentComplete 5
Write-Host "Connecting to " -NoNewline
Write-Host $Params.'vCenter Server' -NoNewline -ForegroundColor Blue
Write-Host " as " -NoNewline
Write-Host $Credential.UserName -ForegroundColor Yellow

Connect-VIServer -Server $Params.'vCenter Server' -Credential $Params.'Device Admin Credential' | Out-Null

## Getting Metadata
Write-Progress -Id 1  -ParentId 0 -Activity 'Collecting VM Data' -PercentComplete 25
$VM = Get-VM -Name $Params.'VM Name'

## Getting Metadata
Write-Progress -Id 1  -ParentId 0 -Activity 'Applying Tags' -PercentComplete 75
Write-Host "Applying Tags to VM " -NoNewline
Write-Host $Params.'VM Name' -ForegroundColor Blue

## Get the tags (converted to array)
$Tags = ConvertTo-Array $Params.Tags
$Tags | Foreach-Object {
    
    $Tag = Get-Tag $_.Trim()
    
    Write-Host "    Applying Tag: " -NoNewline
    Write-Host $Tag -ForegroundColor Yellow
    New-TagAssignment -Tag $Tag -Entity $VM | Out-Null
}
Write-Progress -Id 1  -ParentId 0 -Activity 'Tags Applied' -PercentComplete 100 -Completed


