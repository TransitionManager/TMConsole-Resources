/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "P2V_Backout",
  "Description": "",
  "VersionNumber": 2
}


*********TransitionManager-Recipe-Script*********/


groups: 
		[
		
		// Application groups

			[
				name: 'ALL_APPS',
				filter: [
					class: 'application',
				],
			],

			[
				name: 'APPS_W_DB',
				filter: [
					class: 'device',
					dependency: [
						class: 'application',
						mode: 'requires',
						type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
					],
				],
			],
			[
				name: 'APPS_W_RUNS_ON',
				filter: [
					class: 'device',
					dependency: [
						class: 'application',
						mode: 'requires',
						type: [ 'RUNS ON'],
					],
				],
			],			
			[
				name: 'APPS_WO_RUNS_ON',
				filter: [
					class: 'application',
					include: 'ALL_APPS',
					exclude: 'APPS_W_RUNS_ON',
				],
			],
			[
				name: 'APPS_W_DB_AND_RUNS_ON',
				filter: [
					class: 'application',
					include: 'APPS_W_DB',
					exclude: 'APPS_WO_RUNS_ON',
				],
			],
			[
				name: 'APPS_W_P2V_APP_SVRS',
				filter: [
					class: 'application',
					asset: [ 
						custom7: [ 'App', 'App&DB' ],
					],
				],
			],

			[
				name: 'APPS_W_P2V_DB_SVRS',
				filter: [
					class: 'application',
					asset: [ 
						custom7: 'DB', 
					],
				],
			],
			[
				name: 'APPS_W_P2V_APP_&_DB_SVRS',
				filter: [
					class: 'application',
					asset: [ 
						custom7: 'App&DB', 
					],
				],
			],
			[
				name: 'APPS_W_P2V_SVRS',
				filter: [
					class: 'application',
					include: [ 'APPS_W_P2V_APP_SVRS', 'APPS_W_P2V_DB_SVRS', 'APPS_W_P2V_APP_&_DB_SVRS', ],
				],
			],
			[
				name: 'APPS_WO_P2V_APP_SVRS',
				filter: [
					class: 'application',
					include: 'APPS_W_P2V_SVRS',
					exclude: 'APPS_W_P2V_APP_SVRS',
				],
			],			
	

		// Server groups

			[
				name: 'ALL_SERVERS',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Blade', 'Server', 'VM', ],
					],
				],
			],
			[
				name: 'BLADES',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Blade', ],
					],
				],
			],			
			[
				name: 'RACK-MOUNTED_SERVERS',
				filter: [
					class: 'device',
					asset: [
						assetType: [ 'Server', ],
					],
				],
			],			
			[
				name: 'PHYSICAL_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					asset: [ 
						physical: true, 
					],
				],
			],
			[
				name: 'VIRTUAL_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					exclude: 'PHYSICAL_SERVERS',
				],
			],			
			[
				name: 'VMWARE_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						assetType: 'VM',
						custom1: 'V2V'
					],
				],
			],

		// Server move-method groups

			[
				name: 'ORACLE_PHYSICALS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'Oracle phys',
					],
				],
			],
			[
				name: 'LPARS_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'LPAR',
					],
				],
			],
			[
				name: 'L&S_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'L&S',
					],
				],
			],
			[
				name: 'V2V_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'V2V',
					],
				],
			],
			[
				name: 'P2V_SERVERS',
				filter: [
					class: 'device',
					asset: [ 
						custom1: 'P2V',
					],
				],
			],
		
			[
				name: 'APP_VMS',
				filter: [
					class: 'application',
					dependency: [ 
						class: 'device',
						mode: 'supports',
						type: [ 'Runs On', ],
					],
				],
			],			
			[
				name: 'DB_SERVERS',
				filter: [
					class: 'application',
					dependency: [ 
						class: 'device',
						mode: 'supports',
						type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
					],
				],
			],
			[
				name: 'APP_SERVERS',
				filter: [
					class: 'device',
					include: 'ALL_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_VMWARE_SERVERS',
				filter: [
					class: 'device',
					include: 'VMWARE_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_LPARS',
				filter: [
					class: 'device',
					include: 'LPARS_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_PHYSICALS',
				filter: [
					class: 'device',
					include: 'PHYSICAL_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'P2V_SERVERS',
					exclude: 'DB_SERVERS',
				],
			],
			[
				name: 'APP_NON_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'APP_SERVERS',
					exclude: 'P2V_SERVERS',
				],
			],			
			[
				name: 'DB_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'P2V_SERVERS',
					exclude: 'APP_SERVERS',
				],
			],
			[
				name: 'DB_NON_P2V_SERVERS',
				filter: [
					class: 'device',
					include: 'DB_SERVERS',
					exclude: 'P2V_SERVERS',
				],
			],
		],

tasks:
		[						
			[
				id: 1000,
				title: 'Start P2V event backouts',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
			[
				id: 1700,
				title: '${it.assetName}: Confirm that backout of virtualized servers is required',
				team: 'PROJ_MGR',
				duration: 1,
				filter: [
					group: 'APPS_W_P2V_SVRS',
				],
            ],
          	[
            	id: 2400,
            	title: '${it.assetName}: Bring down target VM',
            	team: 'SYS_ADMIN',
            	duration: 10,
            	filter: [
            		group: 'P2V_SERVERS',
            	],
            	predecessor: [
            		classification: 'application',
            		mode: 'requires',
            	],
          	],         	
          	[
            	id: 2420,
            	title: '${it.assetName}: Bring up original physical server',
            	team: 'SYS_ADMIN',
            	duration: 10,
            	filter: [
            		group: 'P2V_SERVERS',
            	],
          	], 
          	[
            	id: 2450,
            	title: '${it.assetName}: Bring up databases on original physical server',
            	team: 'DB_ADMIN',
            	duration: 20,
            	filter: [
            		group: 'DB_P2V_SERVERS',
            	],
          	],        	        	          
                    	
          	[
				id: 2800,
				title: '${it.assetName}: Re-enable auto-start mechanisms and start up application',
//				whom: '#startupBy',
//				whom: '#SME1',
				whom: '#custom35', // P2C SU by
				team: '',
//				duration: '#startupDuration,7',	
				duration: '#custom36,27', //P2V SU duration	
				category: 'startup',
				filter: [
					group: 'APPS_W_P2V_SVRS',
				],
				predecessor: [
            		classification: 'device',
            		mode: 'supports',
//            		taskSpec: [ 2600, 2700 ],
            	],
            ],
            [
				id: 4600,
				title: '${it.assetName}: Conduct application testing and record results',
//				whom: '#testingBy',
				whom: '#custom37',  // P2V testing by
				team: '',
				duration: '#custom38,27',				
				category: 'startup',
				filter: [
					class: 'application',
					group: 'APPS_W_P2V_SVRS',
				],          
            ],          
          	[
				id: 4900,
				title: '${it.assetName}: All backout tasks, testing complete',
				team: 'AUTO',
				duration: 1,				
				filter: [
					group: 'APPS_W_P2V_SVRS',
				],
            ],
			[
				id: 5000,
				title: 'Resume backups',
				team: 'BACKUP_ADMIN',
//				team: 'DC_OPS',				
				duration: 7,
				type: 'general',
				category: 'moveday',					
			],
			[
				id: 5100,
				title: 'Unmute monitoring alerts',
				team: 'MONITORING_ADMIN',
//				team: 'DC_OPS',				
				duration: 7,
				type: 'general',
				category: 'moveday',
				predecessor: [
            		taskSpec: 5000,
            	]					
			],			                        
          	[
				id: 10000,
				title: 'P2V backout complete complete',
				type: 'milestone',
				team: 'PROJ_MGR',
				category: 'moveday',
			],
		]


