/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "HCX - Create Migration Jobs (prep)",
  "Description": "",
  "VersionNumber": 5
}


*********TransitionManager-Recipe-Script*********/



groups: [
	[
        name: 'hcx_migrate_vms',
        description: 'All VMs being migrated with HCX',
        filter : [
            class: 'device',
			asset: [
				custom71: '%',
			],
        ],
    ],
],
tasks: [

	// Start Wave
	[
        id:1,
        title: 'Start Wave',
        type: 'milestone',
        category: 'startup',
        team: 'PROJ_MGR',
    ],
//	[
//		id: 100,
//		title: 'Validate VM state for HCX Migration: ${it.assetName}',
//		team: 'SYS_ADMIN',
//		invoke: [ 
//			method: 'HCX Migration Job - Validate VM Mapping'
//		],
 //       filter: [
  //          group: 'hcx_migrate_vms'
   //     ]
//		
//	],
	[
		id: 125,
		title: 'HCX Migration Job for: ${set}',
		team: 'AUTO',
		action: 'set',
		setOn: 'custom71',
		filter: [
            group: 'hcx_migrate_vms'
        ]
		
	],
    [
        id: 140,
        title: '${it.assetName}: Validate HCX Readiness',
        team: 'SYS_ADMIN',
        filter: [ 
            class: 'device',
            group: 'hcx_migrate_vms'
        ],
        invoke: [ 
            method: 'HCX Preflight Checklist'
        ],
    ],	
	[
		id: 150,
		title: 'Create HCX Migration Job: ${it.assetName}',
		team: 'SYS_ADMIN',
		invoke: [ 
			method: 'HCX Migration Job - Create Scheduled Bulk Migration'
		],
        filter: [
            group: 'hcx_migrate_vms'
        ]
		
	],
	[
		id: 200,
		title: 'Confirm all HCX jobs were created',
		team: 'SYS_ADMIN',
		action: 'set',
		setOn: 'assetType',		
		invoke: [ 
			method: 'HCX Migration Jobs - Confirm all jobs exist for event',
		],
        filter: [
            group: 'hcx_migrate_vms',
        ],
		predecessor:[
			taskSpec: 150,
		],
	
	],
	

	// Wave Complete
	[
        id:10000,
        title: 'Complete Wave',
        type: 'milestone',
        category: 'startup',
        team: 'PROJ_MGR',
    ],
]


