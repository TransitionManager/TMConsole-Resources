/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "P2V_Event_AUTO",
  "Description": "",
  "VersionNumber": 5
}


*********TransitionManager-Recipe-Script*********/




groups: 
        [
        
        // Application groups

            [
                name: 'ALL_APPS',
                filter: [
                    class: 'application',
                ],
            ],

            [
                name: 'APPS_W_DB',
                filter: [
                    class: 'device',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
                    ],
                ],
            ],
            [
                name: 'APPS_W_RUNS_ON',
                filter: [
                    class: 'device',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: [ 'RUNS ON'],
                    ],
                ],
            ],          
            [
                name: 'APPS_WO_RUNS_ON',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: 'APPS_W_RUNS_ON',
                ],
            ],
            [
                name: 'APPS_W_DB_AND_RUNS_ON',
                filter: [
                    class: 'application',
                    include: 'APPS_W_DB',
                    exclude: 'APPS_WO_RUNS_ON',
                ],
            ],
            [
                name: 'APPS_W_P2V_APP_SVRS',
                filter: [
                    class: 'application',
                    asset: [ 
                        custom7: [ 'App', 'App&DB' ],
                    ],
                ],
            ],

            [
                name: 'APPS_W_P2V_DB_SVRS',
                filter: [
                    class: 'application',
                    asset: [ 
                        custom7: 'DB', 
                    ],
                ],
            ],
            [
                name: 'APPS_W_P2V_APP_&_DB_SVRS',
                filter: [
                    class: 'application',
                    asset: [ 
                        custom7: 'App&DB', 
                    ],
                ],
            ],
            [
                name: 'APPS_W_P2V_SVRS',
                filter: [
                    class: 'application',
                    include: [ 'APPS_W_P2V_APP_SVRS', 'APPS_W_P2V_DB_SVRS', 'APPS_W_P2V_APP_&_DB_SVRS', ],
                ],
            ],
            [
                name: 'APPS_WO_P2V_SVRS',
                filter: [
                    class: 'application',
                    exclude: [ 'APPS_W_P2V_APP_SVRS', 'APPS_W_P2V_DB_SVRS', 'APPS_W_P2V_APP_&_DB_SVRS', ],
                ],
            ],

            [
                name: 'APPS_WO_P2V_APP_SVRS',
                filter: [
                    class: 'application',
                    include: 'APPS_W_P2V_SVRS',
                    exclude: 'APPS_W_P2V_APP_SVRS',
                ],
            ],          
            [
                name: 'TESTING_ONLY_APPS',
                filter: [
                    class: 'application',
                    tag: 'Testing only app',
                    exclude: 'APPS_WO_P2V_APP_SVRS',
                ],
            ],
/*            [
                name: 'VDH_PPD_APPS',
                filter: [
                    class: 'application',
                    tag: 'VDH_P2V_ppd',
                ],
            ],  
*/          [
                name: 'VIRTUALIZING_APPS',
                filter: [
                    class: 'application',
                    include: 'APPS_W_P2V_SVRS',
                ],
            ],
            [
                name: 'APPS_W_P2V_SD_RES',
                filter: [
                    class: 'application',
                    asset: [ custom10: '!= ', ],
                    exclude: 'APPS_WO_P2V_SVRS',
                ],
            ],  
            [
                name: 'APPS_W_P2V_SU_RES',
                filter: [
                    class: 'application',
                    asset: [ custom35: '!= ', ],
                    exclude: 'APPS_WO_P2V_SVRS',
                ],
            ], 
            [
                name: 'APPS_W_P2V_TEST_RES',
                filter: [
                    class: 'application',
                    asset: [ custom37: '!= ', ],
                    exclude: 'APPS_WO_P2V_SVRS',
                ],
            ], 
            [
                name: 'APPS_WO_P2V_SD_RES',
                filter: [
                    class: 'application',
                    include: 'VIRTUALIZING_APPS',                
                    exclude: 'APPS_W_P2V_SD_RES',
                ],
            ],  
            [
                name: 'APPS_WO_P2V_SU_RES',
                filter: [
                    class: 'application',
                    include: 'VIRTUALIZING_APPS',                
                    exclude: 'APPS_W_P2V_SU_RES',
                ],
            ], 
            [
                name: 'APPS_WO_P2V_TEST_RES',
                filter: [
                    class: 'application',
                    include: 'VIRTUALIZING_APPS',                
                    exclude: 'APPS_W_P2V_TEST_RES',
                ],
            ], 

        // Server groups

            [
                name: 'ALL_SERVERS',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Blade', 'Server', 'VM', 'Appliance' ],
                    ],
                ],
            ],
            [
                name: 'BLADES',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Blade', ],
                    ],
                ],
            ],          
            [
                name: 'RACK-MOUNTED_SERVERS',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Server', ],
                    ],
                ],
            ],          
            [
                name: 'PHYSICAL_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    asset: [ 
                        physical: true, 
                    ],
                ],
            ],
            [
                name: 'VIRTUAL_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    exclude: 'PHYSICAL_SERVERS',
                ],
            ],          
            [
                name: 'VMWARE_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        assetType: 'VM',
                        custom1: 'V2V'
                    ],
                ],
            ],

        // Server move-method groups

            [
                name: 'ORACLE_PHYSICALS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'Oracle phys',
                    ],
                ],
            ],
            [
                name: 'LPARS_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'LPAR',
                    ],
                ],
            ],
            [
                name: 'L&S_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'L&S',
                    ],
                ],
            ],
            [
                name: 'V2V_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'V2V',
                    ],
                ],
            ],
/*            [
                name: 'VDH_PPD_SERVERS',
                filter: [
                    class: 'device',
                    tag: 'VDH_P2V_ppd',
                ],  
            ],
*/          [
                name: 'P2V_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'P2V',
                    ],
                ],
            ],
        
            [
                name: 'APP_VMS',
                filter: [
                    class: 'application',
                    dependency: [ 
                        class: 'device',
                        mode: 'supports',
                        type: [ 'Runs On', ],
                    ],
                ],
            ],          
            [
                name: 'DB_SERVERS',
                filter: [
                    class: 'application',
                    dependency: [ 
                        class: 'device',
                        mode: 'supports',
                        type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
                    ],
                ],
            ],
            [
                name: 'APP_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_VMWARE_SERVERS',
                filter: [
                    class: 'device',
                    include: 'VMWARE_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_LPARS',
                filter: [
                    class: 'device',
                    include: 'LPARS_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_PHYSICALS',
                filter: [
                    class: 'device',
                    include: 'PHYSICAL_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_NON_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'APP_SERVERS',
                    exclude: 'P2V_SERVERS',
                ],
            ],          
            [
                name: 'DB_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'APP_SERVERS',
                ],
            ],
            [
                name: 'DB_NON_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS',
                    exclude: 'P2V_SERVERS',
                ],
            ],
            [
                name: 'SERVERS_W_DR',
                filter: [
                    class: 'device',
                    asset: [
                        custom86: '% DR: Yes%']
                ],
            ],
            [
                name: 'P2V_SERVERS_WO_DR',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'SERVERS_W_DR',
                ],
            ],
            [
                name: 'P2V_SERVERS_W_DR',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'P2V_SERVERS_WO_DR',
                ],
            ],
            [
                name: 'KEEP_MAC_SERVERS',
                filter: [
                    class: 'device',
                    tag: 'Keep MAC',
                ],
            ],
        ],

tasks:
        [
            [
                id: 90,
                title: '${it.assetName}: Physical Oracle server in P2V event!',
                team: 'AUTO',
                duration: 7,
                filter: [
                    group: 'ORACLE_PHYSICALS',
                ],
            ],
/*
            [
                id: 100,
                title: 'Start Roll call',
                type: 'milestone',
                team: 'PROJ_MGR',
            ],
            [
                id: 200,
                action: 'rollcall',
                category: 'premove',
            ],
            [
                id: 300,
                title: 'Roll call complete',
                type: 'milestone',
                team: 'AUTO',
            ],          
 */           [
                id: 400,
                title: 'Begin prep tasks',
                team: 'PROJ_MGR',
                type: 'milestone',
                duration: 7,
                category: 'moveday',            
            ],
 /*           [
                id: 410,
                title: 'Auto-milestone',
                type: 'milestone',
                team: 'AUTO',
            ],          
*/            [
                id: 420,
                title: 'Confirm backups for P2V servers',
                team: 'BACKUP_ADMIN',
                type: 'general',
                duration: 7,
                category: 'moveday',            
                predecessor: [
                    taskSpec: 400,
                ],  
			],          

            [
                id: 700,
                title: 'Pause backups',
                team: 'BACKUP_ADMIN',
                duration: 7,
                type: 'general',
                category: 'moveday',
                predecessor: [
                    taskSpec: 420,
                ]                   
            ],                      
            [
                id: 710,
                title: 'Mute monitoring alerts for P2V servers',
                team: 'MONITORING_ADMIN',
                duration: 7,
                type: 'general',
                category: 'moveday',
                predecessor: [
                    taskSpec: 400,
                ]                   
            ],          [
                id: 750,
                title: 'Confirm JOC (804 416 7952 / vitajoc@vita.virginia.gov) notified of event start, change record marked as started',
                team: 'PROJ_MGR',
                duration: 7,
                type: 'general',                
                category: 'moveday',
                predecessor: [
                    taskSpec: 400,
                ]               
            ],          
            [
                id: 1000,
                title: 'Start P2V event',
                type: 'milestone',
                team: 'PROJ_MGR',
                category: 'moveday',
            ],
            [
                id: 1010,
                title: 'Start ${set} tasks',
                type: 'action',
                action: 'set',
                setOn: 'custom26',
                team: 'PROJ_MGR',
                category: 'moveday',
                filter: [
                    group: 'APPS_W_P2V_SVRS',
                ],
            ],            
            [
                id: 1700,
                title: '${it.assetName}: Disable auto-start mechanisms and application off line -- no server shutdown (${it.custom4})',
                whom: '#custom10',  // P2V SD by
                team: '',
//              duration: '#shutdownDuration,7',
                duration: '#custom12, 27',  // P2V SD duration                  
                category: 'shutdown',
                sendNotification: true,
                filter: [
                    group: 'APPS_W_P2V_SD_RES',
                ],
            ],
             [
                id: 1750,
                title: '${it.assetName}: Disable auto-start mechanisms and application off line -- no server shutdown (${it.custom4})',
                whom: '#shutdownBy',  // P2V SD by
                team: '',
//              duration: '#shutdownDuration,7',
                duration: '#custom12, 27',  // P2V SD duration                  
                category: 'shutdown',
                sendNotification: true,
                filter: [
                    group: 'APPS_WO_P2V_SD_RES',
                ],
            ],                       
            [
                id: 2300,
                title: '${it.assetName}: Perform backups and shut down databases on P2V DB server (${it.custom4})',
                whom: '#custom85',   // "DBA res" custom field
                sendNotification: true,
                duration: 30,
                filter: [
                    group: 'DB_P2V_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],
            ],

            // TMD steps for Carbonite filover

            [
                id: 2400,
                title: '${it.assetName}: Validate Carbonite failover ready [TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',
                duration: 120,
//                invoke: [ 
//                    method: 'Carbonite - Replication Job - 3. Monitor until Protected'
 //               ],
                filter: [
                    group: 'P2V_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 2300,
                ],
            ],              
            [
                id: 2500,
                title: '${it.assetName}: Invoke failover [TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 120,
//               invoke: [ 
//                    method: 'Carbonite - Replication Job - 4. Invoke Failover'
//                ],
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 2600,
                title: '${it.assetName}: Monitor until Failover Completes [TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',
//                invoke: [ 
 //                   method: 'Carbonite - Replication Job - 5. Monitor Failover until Complete'
 //               ],
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 2700,
                title: '${it.assetName}: Install VMware tools on target VM and power off (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 2750,
                title: '${it.assetName}: Force the MAC address of the target VM to match the source server (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 7,
                filter: [
                    group: 'KEEP_MAC_SERVERS',
                ],
            ],
            [
                id: 2800,
                title: '${it.assetName}: Add Secondary SCSI Controller (PVSCSI) Power on VM [Possible TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 2900,
                title: '${it.assetName}: Remove SCSI Controller 2 and Change SCSI Controller 1 to PVSCSI and Power on VM [Possible TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 3000,
                title: '${it.assetName}: Validate target VM - Network AD login, host is pingable, confirm virtual (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
             [
                id: 3100,
                title: '${it.assetName}: Remove EBARS Network adapter from VM (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 3200,
                title: '${it.assetName}: Uninstall Carbonite [TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                                
                invoke: [ 
                    method: 'Carbonite - Agent - 9. Remote Uninstall'
                ],
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 3300,
                title: '${it.assetName}: Uninstall Symantec NetBackup, EMC PowerPath packages (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
				invoke: [ 
                    method: 'PsExec - Remove Source VM Software'
                ],
            ],
            [
                id: 3400,
                title: '${it.assetName}: Reboot VM (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ], 
            [
                id: 3500,
                title: '${it.assetName}: Validate target VM - Network AD login, host is pingable, has all required drives (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
           [           
                id: 3600,
                title: '${it.assetName}: Move VM to folder: ${it.custom26}>HostedVMs>Agencies>${it.custom4} (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [           
                id: 3700,
                title: '${it.assetName}: Add VMware tags: (${it.custom86}) (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',
//              invoke: [ 
//                  method: 'VMware vCenter - Update VM Tags'
//              ],              
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 3800,
                title: '${it.assetName}: Remove Replication Job [TMD] (${it.custom4})',
//              team: 'SYS_ADMIN',
                team: 'AUTO',                
 //               invoke: [ 
//                   method: 'Carbonite - Replication Job - 6. Remove Job'
//                ],
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],

            // End Carbonite failover steps

/*            [
                id: 2410,
                title: '${it.assetName}: Verify source server is powered off',
                team: 'SYS_ADMIN',
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ], 
             
              




            // TMD tags, snapshot tasks

            [           
                id: 2445,
                title: '${it.assetName}: Add VMware tags: (${it.custom86})',
                team: 'SYS_ADMIN',              
//              invoke: [ 
//                  method: 'VMware vCenter - Update VM Tags'
//              ],              
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
 
            [           
                id: 2450,
                title: '${it.assetName}: Take a snapshot of VM [TMD]',
                team: 'SYS_ADMIN',              
                invoke: [ 
                    method: 'VMware vCenter - Take Snapshot of VM'
                ],              
                duration: 7,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],
            [
                id: 2460,
                title: '${it.assetName}: Uninstall NetBackup, PowerPath packages',
                team: 'SYS_ADMIN',
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ], 
             
            [
                id: 2467,
                title: '${it.assetName}: If reboot succeeds, remove snapshot, otherwise revert to snapshot and report failure to command center',
                team: 'SYS_ADMIN',
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],              
*/            [
                id: 4000,
                title: '${it.assetName}: Bring up databases on target VM (${it.custom4})',
                whom: '#custom85',   // "DBA res" custom field
                duration: 30,
                sendNotification: true,
                filter: [
                    group: 'DB_P2V_SERVERS',
                ],
            ],
                    
            [
                id: 4100,
                title: '${it.assetName}: Re-enable auto-start mechanisms and bring application on line (${it.custom4})',
//              whom: '#startupBy',
//              whom: '#SME1',
                whom: '#custom35', // P2C SU by
                team: '',
//              duration: '#startupDuration,7', 
                duration: '#custom36,27', //P2V SU duration 
                category: 'startup',
                sendNotification: true,
                filter: [
                    group: 'APPS_W_P2V_SU_RES',
                ],
                predecessor: [
                    classification: 'device',
                    mode: 'supports',
                ],
            ],
            [
                id: 4150,
                title: '${it.assetName}: Re-enable auto-start mechanisms and bring application on line (${it.custom4})',
//              whom: '#startupBy',
//              whom: '#SME1',
                whom: '#startupBy', // P2C SU by
                team: '',
//              duration: '#startupDuration,7', 
                duration: '#custom36,27', //P2V SU duration 
                category: 'startup',
                sendNotification: true,
                filter: [
                    group: 'APPS_WO_P2V_SU_RES',
                ],
                predecessor: [
                    classification: 'device',
                    mode: 'supports',
                ],
            ],            
            [
                id: 4600,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
//              whom: '#testingBy',
                whom: '#custom37',  // P2V testing by
                team: '',
                duration: '#custom38,27',               
                category: 'startup',
                sendNotification: true,
                filter: [
                    class: 'application',
                    group: 'APPS_W_P2V_TEST_RES',
                ],          
            ],
            [
                id: 4650,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
//              whom: '#testingBy',
                whom: '#testingBy',  // P2V testing by
                team: '',
                duration: '#custom38,27',               
                category: 'startup',
                sendNotification: true,
                filter: [
                    class: 'application',
                    group: 'APPS_WO_P2V_TEST_RES',
                ],          
            ],
            [
                id: 4700,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
//              whom: '#testingBy',
                whom: '#custom37',  // P2V testing by
                team: '',
                duration: '#custom38,27',               
                category: 'startup',
                sendNotification: true,
                filter: [
                    class: 'application',
                    group: 'TESTING_ONLY_APPS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'supports',
                    type: 'A2A - Hard',
                ],          
            ],
                     
            [           
                id: 4800,
                title: '${it.assetName}: Unmute monitoring alerts (${it.custom4})',
                team: 'MONITORING_ADMIN',
                duration: 17,
                filter: [
                    group: 'P2V_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],
            ], 

            [
                id: 4810,
                title: '${it.assetName}: Confirm server is correctly configured for backups in CESC (${it.custom4})',
                team: 'BACKUP_ADMIN',
                sendNotification: true,
                filter: [
                    group: 'P2V_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],
            ],
            [
                id: 4820,
                title: '${it.assetName}: backup, monitoring tasks complete',
                team: 'AUTO',
                filter: [
                    group: 'P2V_SERVERS',
                ],
                predecessor: [
                    taskSpec: [ 4810, 4800 ],
                ],
            ],             
            [
                id: 4900,
                title: '${it.assetName}: All server tasks, app testing complete',
                team: 'AUTO',
                duration: 1,                
                filter: [
                    group: 'P2V_SERVERS',
                ],
            ],

            [
                id: 5050,
                title: 'Notify steady-state team to vMotion all VMs to normal or DR-enabled datastores according to the "DR" tag',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
                team: 'PROJ_MGR',
                sendNotification: true,
                duration: 7,                
                filter: [
                    group: 'APPS_W_P2V_SVRS',
                ],
            ],
            [
                id: 5070,
                title: 'Notify asset management team to update CMDB records for virtualized servers as required',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
                team: 'PROJ_MGR',
                sendNotification: true,
                duration: 7,                
                filter: [
                    group: 'APPS_W_P2V_SVRS',
                ],
            ],                                           
            [
                id: 5100,
                title: 'Confirm JOC (804 416 7952 / vitajoc@vita.virginia.gov) notified of event finish, change record marked as complete',
                team: 'PROJ_MGR',
                duration: 7,
                type: 'milestone',              
                category: 'moveday',                
            ],          
            [
                id: 10000,
                title: 'Move event complete',
                type: 'milestone',
                team: 'PROJ_MGR',
                category: 'moveday',
            ],
        ]


