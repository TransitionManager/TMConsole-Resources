/*********TransitionManager-Recipe-Script*********

{
  "RecipeName": "MoveEvent",
  "Description": "",
  "VersionNumber": 39
}


*********TransitionManager-Recipe-Script*********/


// VITA move event recipe

groups: 
        [
        
        // Application groups

            [
                name: 'ALL_APPS',
                filter: [
                    class: 'application',
                ],
            ],
            [
                name: 'TO_APPS',
                filter: [
                    class: 'application',
                    asset: [ 
                        assetName: '%(testing only%', 
                    ],
                ],  
            ],

            [
                name: 'NON_TO_APPS',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: 'TO_APPS',
                ],
            ],          
            [
                name: 'B_SIDE_APPS',
                filter: [
                    class: 'application',
                    asset: [ 
                        assetName: '%(HA-B%', 
                    ],
                ],  
            ],          
            [
                name: 'NON_B_SIDE_APPS',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: 'B_SIDE_APPS',
                ],  
            ],          
            [
                name: 'AIS_APPS',
                filter: [
                    class: 'application',
                    dependency: [
                        class: 'application',
                        mode: 'supports',
                        type: 'AIS',
                    ],
                    exclude: 'TO_APPS'
                ],
            ],
            [
                name: 'NON_AIS_APPS',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: [ 'AIS_APPS', 'TO_APPS' ],
                ],
            ],          
            [
                name: 'NON_TO_NON_AIS_APPS',
                filter: [
                    class: 'application',
                    include: 'NON_TO_APPS',
                    exclude: [ 'AIS_APPS', 'TO_APPS' ],
                ],
            ],          
            [
                name: 'APPS_W_AIS',
                filter: [
                    class: 'application',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: 'AIS',
                    ],
                ],
            ],          
            [
                name: 'NON_TO_APPS_W_AIS',
                filter: [
                    class: 'application',
                    include: 'APPS_W_AIS',
                    exclude: 'TO_APPS'
                ],
            ],          
            [
                name: 'APPS_WO_AIS',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: [ 'APPS_W_AIS', 'TO_APPS' ],
                ],
            ],          
            [
                name: 'NON_AIS_APPS_WO_AIS',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: [ 'APPS_W_AIS', 'AIS_APPS', 'TO_APPS' ],
                ],
            ],
            [
                name: 'APPS_W_DB',
                filter: [
                    class: 'device',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
                    ],
                ],
            ],
            [
                name: 'APPS_W_ORACLE_DB',
                filter: [
                    class: 'device',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: [ 'DB Server Oracle' ],
                    ],
                ],
            ],          
            [
                name: 'APPS_WO_DB',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: 'APPS_W_DB',
                ],
            ],          
            [
                name: 'APPS_W_RUNS_ON',
                filter: [
                    class: 'device',
                    dependency: [
                        class: 'application',
                        mode: 'requires',
                        type: [ 'RUNS ON'],
                    ],
                ],
            ],          
            [
                name: 'APPS_WO_RUNS_ON',
                filter: [
                    class: 'application',
                    include: 'ALL_APPS',
                    exclude: 'APPS_W_RUNS_ON',
                ],
            ],
            [
                name: 'APPS_W_DB_AND_RUNS_ON',
                filter: [
                    class: 'application',
                    include: 'APPS_W_DB',
                    exclude: 'APPS_WO_RUNS_ON',
                ],
            ],
            [
                name: 'APPS_W_AUTO_HEALTH_CHECK_RES',
                filter: [
                    class: 'application',
                    asset: [ custom39: 'AUTO', ],
                    exclude: 'TO_APPS',
                ],
            ],
            [
                name: 'APPS_W_HEALTH_CHECK_RES',
                filter: [
                    class: 'application',
                    asset: [ custom39: '!= ', ],
                    exclude: [ 'APPS_W_AUTO_HEALTH_CHECK_RES', 'TO_APPS' ],
                ],
            ],          
            [
                name: 'APPS_WO_HEALTH_CHECK_RES',
                filter: [
                    class: 'application',
                    exclude: ['APPS_W_HEALTH_CHECK_RES', 'APPS_W_AUTO_HEALTH_CHECK_RES','TO_APPS' ],
                ],
            ],
            [
                name: 'VaCMS_APP',
                filter: [
                    class: 'application',
                    asset: [ assetName: 'Virginia Case Management System (VaCMS) - PROD (ME21)' ],
                ],
            ],
            [
                name: 'VDOT_APPS',
                filter: [
                    class: 'application',
                    asset: [ custom4: 'VDOT' ],
                ],
            ],
                

        // Server groups

            [
                name: 'ALL_SERVERS',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Blade', 'Server', 'VM', ],
                    ],
                ],
            ],
            [
                name: 'PRIORITY_SERVERS',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Blade', 'Server', 'VM', ],
                        custom7: '[PRIORITY]',
                    ],
                ],
            ],
            [
                name: 'NON_PRIORITY_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    exclude: 'PRIORITY_SERVERS',
                ],
            ],                      
            [
                name: 'CLUSTER_NODES',
                filter: [ 
                    class: 'device',
                    asset: [ 
                        custom1: 'Cluster'
                    ],
                ],
            ],

            [
                name: 'BLADES',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Blade', ],
                    ],
                ],
            ],          
            [
                name: 'RACK-MOUNTED_SERVERS',
                filter: [
                    class: 'device',
                    asset: [
                        assetType: [ 'Server', ],
                    ],
                ],
            ],          
            [
                name: 'PHYSICAL_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    asset: [ 
                        physical: true, 
                    ],
                ],
            ],
            [
                name: 'VIRTUAL_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    exclude: 'PHYSICAL_SERVERS',
                ],
            ],          
            [
                name: 'VMWARE_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        assetType: 'VM',
                        custom1: 'V2V'
                    ],
                ],
            ],
            [
                name: 'HCX_SERVERS',
                filter: [
                    class: 'device',
                    include: 'VMWARE_SERVERS',
                    exclude: 'CLUSTER_NODES',
                ],
            ],
            [
                name: 'PRIORITY_HCX_SERVERS',
                filter: [
                    class: 'device',
                    include: 'HCX_SERVERS',
                    exclude: 'NON_PRIORITY_SERVERS',
                ],
            ],          
            [
                name: 'NON_PRIORITY_HCX_SERVERS',
                filter: [
                    class: 'device',
                    include: 'HCX_SERVERS',
                    exclude: 'PRIORITY_SERVERS',
                ],
            ],          
            [
                name: 'DMZ_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom56: '%DMZ%',
                    ],
                ],
            ],
            [
                name: 'VMS_W_EBARS',
                filter: [
                    class: 'device', 
                    tag: 'EBARS',
                    exclude: 'PHYSICAL_SERVERS',
                ],
            ],          
            [
                name: 'PRIORITY_VMS_W_EBARS',
                filter: [
                    class: 'device', 
                    include: 'VMS_W_EBARS',
                    exclude: 'NON_PRIORITY_SERVERS',
                ],
            ],
            [
                name: 'NON_PRIORITY_VMS_W_EBARS',
                filter: [
                    class: 'device', 
                    include: 'VMS_W_EBARS',
                    exclude: 'PRIORITY_SERVERS',
                ],
            ],          // Server move-method groups

            [
                name: 'LPAR_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'LPAR',
                    ],
                ],
            ],
            [
                name: 'HA_LPAR_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'LPAR_HA',
                    ],
                ],
            ],
            [
                name: 'L&S_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'L&S',
                    ],
                ],
            ],
            [
                name: 'V2V_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'V2V',
                    ],
                ],
            ],
            [
                name: 'P2V_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'P2V',
                    ],
                ],
            ],
            [
                name: 'P2P_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'P2P',
                    ],
                ],
            ],
            [
                name: 'P2P_SAN_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'P2P_SAN',
                    ],
                ],
            ],          
            [
                name: 'PCA_ORACLE_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'PCA_ORACLE',
                    ],
                ],
            ],          
            [
                name: 'PCA_nonDB_SERVERS',
                filter: [
                    class: 'device',
                    asset: [ 
                        custom1: 'PCA_nonDB',
                    ],
                ],
            ],
            [
                name: 'APP_VMS',
                filter: [
                    class: 'application',
                    dependency: [ 
                        class: 'device',
                        mode: 'supports',
                        type: [ 'Runs On', ],
                    ],
                ],
            ],          
            [
                name: 'DB_SERVERS',
                filter: [
                    class: 'application',
                    dependency: [ 
                        class: 'device',
                        mode: 'supports',
                        type: [ 'DB Server DB2', 'DB Server MySQL', 'DB Server Oracle', 'DB Server Postgre', 'DB Server SQL', ],
                    ],
                ],
            ],
            [
                name: 'HCX_DB_SERVERS',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS',
                    exclude: 'CLUSTER_NODES',
                ],
            ],
            [
                name: 'HCX_DB_SERVERS_REQ_DB_SD',
                filter: [
                    class: 'device',
                    include: 'HCX_DB_SERVERS',
//                  asset: [ custom64: '1', ],
                    asset: [ custom85: '!= ', ],
                ],
            ],
            [
                name: 'DB_SERVERS_REQ_DB_SD',
                filter: [
                    class: 'device',
                    asset: [ custom85: '!= ', ],
                ],
            ],
            [
                name: 'NON_P2P_DB_SERVERS_REQ_DB_SD',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS_REQ_DB_SD',
                    exclude: 'P2P_SERVERS',
                ],
            ],
            [
                name: 'P2P_DB_SERVERS_REQ_DB_SD',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS_REQ_DB_SD',
                    exclude: 'NON_P2P_DB_SERVERS_REQ_DB_SD',
                ],
            ],
            [
                name: 'CLUSTERED_DB_SERVERS',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS',
                    exclude: 'HCX_DB_SERVERS',
                ],
            ],                      
            [
                name: 'APP_SERVERS',
                filter: [
                    class: 'device',
                    include: 'ALL_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'HCX_APP_SERVERS',
                filter: [
                    class: 'device',
                    include: 'APP_SERVERS',
                    exclude: 'CLUSTER_NODES',
                ],
            ],
            [
                name: 'CLUSTERED_APP_SERVERS',
                filter: [
                    class: 'device',
                    include: 'APP_SERVERS',
                    exclude: 'HCX_APP_SERVERS',
                ],
            ],
            [
                name: 'APP_VMWARE_SERVERS',
                filter: [
                    class: 'device',
                    include: 'VMWARE_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_LPARS',
                filter: [
                    class: 'device',
                    include: 'LPAR_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_PHYSICALS',
                filter: [
                    class: 'device',
                    include: 'PHYSICAL_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
                        [
                name: 'APP_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'DB_SERVERS',
                ],
            ],
            [
                name: 'APP_NON_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'APP_SERVERS',
                    exclude: 'P2V_SERVERS',
                ],
            ],          
            [
                name: 'DB_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'P2V_SERVERS',
                    exclude: 'APP_SERVERS',
                ],
            ],
            [
                name: 'DB_NON_P2V_SERVERS',
                filter: [
                    class: 'device',
                    include: 'DB_SERVERS',
                    exclude: 'P2V_SERVERS',
                ],
            ],

            // VLANs

            [
                name: 'VLANS',
                filter: [
                    class: 'device',
                    asset: [
                        assetName: '%VLAN%'
                    ],              
                ],
            ],
            [
                name: 'SERVERS_W_VLANs',
                filter: [
                        class: 'device',
                        dependency: [
                            class: 'device',
                            mode: 'requires',
                            type: 'VLAN',
                        ],
                ],
            ],
            [
                name: 'APPS_W_VLANs',
                filter: [
                        class: 'device',
                        dependency: [
                            class: 'application',
                            mode: 'requires',
                            type: 'VLAN-app',
                        ],
                ],
            ],
        ],          
        

tasks: 
        [       
            [
                id: 410,
                title: 'Begin prep tasks',
                type: 'milestone',
                team: 'PROJ_MGR',
            ],                  
            [
                id: 700,
                title: 'Pause backups for moving servers',
                team: 'BACKUP_ADMIN',
                duration: 7,
                type: 'general',
                category: 'moveday',
                predecessor: [
                    taskSpec: 410,
                ]                   
            ],
            [
                id: 750,
                title: 'Mute monitoring alerts for moving servers',
                team: 'MONITORING_ADMIN',
//              team: 'DC_OPS',             
                duration: 7,
                type: 'general',                
                category: 'moveday',
                predecessor: [
                    taskSpec: 410,
                ]               
            ],          
            [
                id: 800,
                title: 'Confirm JOC (804 416 7952 / vitajoc@vita.virginia.gov) notified of event start, change record marked as started',
                team: 'PROJ_MGR',
                duration: 7,
                type: 'general',                
                category: 'moveday',
                predecessor: [
                    taskSpec: 410,
                ]               
            ],
            [
                id: 810,
                title: 'Confirm SLC (VITACommandCenter@unisys.com) notified of event start',
                team: 'PROJ_MGR',
                duration: 7,
                type: 'general',                
                category: 'moveday',
                predecessor: [
                    taskSpec: 410,
                ]               
            ],
            [
                id: 1000,
                title: 'Start move event',
                type: 'milestone',
                team: 'PROJ_MGR',
                category: 'moveday',
            ],
            [
                id: 1010,
                title: 'Start ${set} tasks',
                type: 'action',
                action: 'set',
                setOn: 'custom26',
                team: 'PROJ_MGR',
                category: 'moveday',
                filter: [
                    group: 'ALL_APPS',
                ],
            ],
            [
                id: 1500,
                title: '${it.assetName}: Confirm application ready for migration (${it.custom4})',
                whom: '#testingBy',
                team: '',
                sendNotification: true,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: 'APPS_WO_HEALTH_CHECK_RES',
                ],
            ],
            [
                id: 1600,
                title: '${it.assetName}: Confirm application ready for migration (${it.custom4})',
                whom: '#custom39',
                team: '',
                sendNotification: true,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: 'APPS_W_HEALTH_CHECK_RES',
                ],
            ],
            [
                id: 1610,
                title: '${it.assetName}: Put application into read-only mode',
                whom: 'Santosh.Kota@dss.virginia.gov',
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'VaCMS_APP',
                ],          
            ],          
            [
                id: 1650,
                title: '${it.assetName}: Confirm application ready for migration (${it.custom4})',
                team: 'AUTO',
                sendNotification: false,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: 'APPS_W_AUTO_HEALTH_CHECK_RES',
                ],
            ],          
            [
                id: 1700,
                title: '${it.assetName}: Shut down application (${it.custom4})',
                whom: '#shutdownBy',
                team: '',
                sendNotification: true,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: [ 'NON_AIS_APPS_WO_AIS', 'APPS_W_AIS' ]
                ],           
            ],
/*          [
                id: 1710,
                title: '${it.assetName}: Shut down application (${it.custom4})',
                whom: '#shutdownBy',
                team: '',
                sendNotification: true,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: 'APPS_W_AIS',
                ],           
            ],           
*/          [
                id: 1710,
                title: '${it.assetName}: Shut down application (${it.custom4})',
                whom: '#shutdownBy',
                team: '',
                sendNotification: true,
                duration: '#shutdownDuration,7',                
                category: 'shutdown',
                filter: [
                    class: 'application',
                    group: 'AIS_APPS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    type: 'AIS',
                    taskSpec: [ 1500, 1600, 1650 ],
                ],            
            ],          
            [
                id: 1800,
                title: '${it.assetName}: Shut down databases (${it.custom4})',
                whom: '#custom85',   // DBA Res
                sendNotification: true,
                duration: 17,               
                category: 'shutdown',
                filter: [
                    class: 'device',
                    group: 'NON_P2P_DB_SERVERS_REQ_DB_SD',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],           
            ],
            [
                id: 1810,
                title: '${it.assetName}: Disable DB auto-start and shut down databases (${it.custom4})',
                whom: '#custom85',   // DBA Res
                sendNotification: true,
                duration: 17,               
                category: 'shutdown',
                filter: [
                    class: 'device',
                    group: 'P2P_DB_SERVERS_REQ_DB_SD',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],           
            ],


// P2P moves

            [
                id: 2200,
                title:  '[Carb. P2P] ${it.assetName}: Start cutover (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 1810,
                ],
            ],
            [
                id: 2300,
                title:  '[Carb. P2P] ${it.assetName}: Confirm cutover is complete, source server is shut down (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SERVERS',
                ],          
            ],
            [
                id: 2400,
                title:  '[Carb. P2P] ${it.assetName}: Validate target server (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SERVERS',
                ],          
            ],
            [
                id: 2500,
                title:  '[Carb. P2P] ${it.assetName}: Unistall Carbonite agent (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SERVERS',
                ],          
            ],
            [
                id: 2600,
                title:  '[Carb. P2P] ${it.assetName}: Register backup client in QTS (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SERVERS',
                ],          
            ],

// P2P SAN moves

            [
                id: 2700,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Set non-OS drives to off-line (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2710,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Complete sync of system with Carbonite (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2720,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Complete sync of non-OS drives with SAN rsync (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2730,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Cutover source to destination by Carbonite (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2740,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Attach excluded drives to destination system by SAN (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2750,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Set non-OS drives to on-line (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2760,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Perform a complete system restart and check-out (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2770,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Unistall Carbonite agent (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],
            [
                id: 2780,
                title:  '[Carb. P2P w/SAN] ${it.assetName}: Register backup client in QTS (${it.custom4})',
                whom: 'David.Heinrich@unisys.com',
                duration: 1,
                filter: [
                    class: 'device',
                    group: 'P2P_SAN_SERVERS',
                ],          
            ],

// PCA moves

            [
                id: 3000,
                title:  '${it.assetName}: Migrate Oracle server into PCA cloud (${it.custom4})',
                team: 'ORACLE_MIG_ENG',
                sendNotification: true,
                duration: 61,
                filter: [
                    class: 'device',
                    group: 'PCA_ORACLE_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 1800,
                ],           
            ],


// VMs (HCX) moves
          
           [
                id: 3400,
                title: '[PRIORITY] ${it.assetName}: Confirm VM is HCX Switchover-Ready [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 30,
                invoke: [ 
                    method: 'HCX Migration Job - Monitor Job Status'
                ],                              
                filter: [ 
                    class: 'device',
                    group: 'PRIORITY_HCX_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 1800,
                ],
            ],
           [
                id: 3410,
                title: '${it.assetName}: Confirm VM is HCX Switchover-Ready [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 30,
                invoke: [ 
                    method: 'HCX Migration Job - Monitor Job Status'
                ],                              
                filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_HCX_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 1800,
                ],
            ],
            [
                id: 3500,
                title: '[PRIORITY] ${it.assetName}: Invoke failover (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 60,
                 invoke: [ 
                    method: 'HCX Migration Job - Failover Now'
                ],

               filter: [ 
                    class: 'device',
                    group: 'PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3510,
                title: '${it.assetName}: Invoke failover (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 60,
                 invoke: [ 
                    method: 'HCX Migration Job - Failover Now'
                ],

               filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3600,
                title: '[PRIORITY] ${it.assetName}: Monitor until failover is done  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,
                 invoke: [ 
                    method: 'HCX Migration Job - Monitor Job Status'
                ],              
                filter: [ 
                    class: 'device',
                    group: 'PRIORITY_HCX_SERVERS',
                ],
            ],


            [
                id: 3610,
                title: '${it.assetName}: Monitor until failover is done  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,
                 invoke: [ 
                    method: 'HCX Migration Job - Monitor Job Status'
                ],              
                filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3630,
                title: '${it.assetName}: Power down VM, remove secondary EBAR NIC, power on VM  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,           
                filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_VMS_W_EBARS',
                ],
            ], 
            [
                id: 3640,
                title: '[PRIORITY] ${it.assetName}: Power down VM, remove secondary EBAR NIC, power on VM  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,           
                filter: [ 
                    class: 'device',
                    group: 'PRIORITY_VMS_W_EBARS',
                ],
            ],           
            [
                id: 3650,
                title: '[PRIORITY]${it.assetName}:  Update Network and Folder [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,
                 invoke: [ 
                    method: 'VMware vCenter - Update VM Settings on Target'
                ],              
                filter: [ 
                    class: 'device',
                    group: 'PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3660,
                title: '${it.assetName}:  Update Network and Folder [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 90,
                 invoke: [ 
                    method: 'VMware vCenter - Update VM Settings on Target'
                ],              
                filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_HCX_SERVERS',
                ],
            ],            
            [
                id: 3700,
                title: '[PRIORITY] ${it.assetName}: Validate server is running in QTS [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 60,
                 invoke: [ 
                    method: 'HCX - Post-Migration Checklist',
                ],
                filter: [ 
                    class: 'device',
                    group: 'PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3710,
                title: '${it.assetName}: Validate server is running in QTS [TMD]  (${it.custom4})',
                team: 'TDS_MIG_ENG',
                duration: 60,
                 invoke: [ 
                    method: 'HCX - Post-Migration Checklist'
                ],
                filter: [ 
                    class: 'device',
                    group: 'NON_PRIORITY_HCX_SERVERS',
                ],
            ],
            [
                id: 3720,
                title: '${it.assetName}: Start up databases (${it.custom4})',
                whom: '#custom85',   // DBA Res
                sendNotification: true,
                duration: 17,               
                filter: [
                    class: 'device',
                    group: 'NON_P2P_DB_SERVERS_REQ_DB_SD', 
                ],          
            ],
            [
                id: 3730,
                title: '${it.assetName}: Re-enable auto-start mechanisms and start up databases (${it.custom4})',
                whom: '#custom85',   // DBA Res
                sendNotification: true,
                duration: 17,               
                filter: [
                    class: 'device',
                    group: 'P2P_DB_SERVERS_REQ_DB_SD', 
                ],          
            ],            
            [
                id: 3800,
                title: '${it.assetName}: Lift and shift physical device from CESC to QTS, install and validate (${it.custom4})',
                duration: 61,
                team: 'PROJ_MGR',
                sendNotification: true,
                filter: [ 
                    class: 'device',
                    group: 'L&S_SERVERS',
                ],
                predecessor: [ 
                    classification: 'application',
                    mode: 'requires',
                ],
            ],                   
           [
                id: 4460,
                title: '${it.assetName}: Cluster node ready to migrate to QTS  (${it.custom4})',
                duration: 61,
                team: 'AUTO',
                sendNotification: true,
                filter: [ 
                    class: 'device',
                    group: 'CLUSTER_NODES',
                ],
                predecessor: [ 
                    classification: 'application',
                    mode: 'requires',
                ],
            ],
            [
                id: 4470,
                title: '${it.assetName}: Migrate cluster node to QTS  (${it.custom4})',
                duration: 61,
                team: 'CARBONITE_PS',
                sendNotification: true,
                filter: [ 
                    class: 'device',
                    group: 'CLUSTER_NODES',
                ],
                predecessor: [ 
                    classification: 'device',
                    mode: 'supports',
                    type: 'Witness',
                    taskSpec: 4460,
                ],
            ],
            [
                id: 4475,
                title: 'All apps were shut down',
                team: 'AUTO',
                category: 'startup',
                type: 'action',
                action: 'set',
//              setOn: 'custom26',
                setOn: 'assetType',
                filter: [
                    class: 'application',
                    group: 'NON_B_SIDE_APPS',
                ],       
            ],

            [
                id: 4490,
                title: 'Perform all network gateway cutover tasks',
                team: 'PROJ_MGR',
                type: 'general',
                predecessor: [
                    taskSpec: [1000, 4475],
                ],
            ],

            [
                id: 4495,
                title: 'Update DNS records as required due to network gateway changes',
                team: 'PROJ_MGR',
                type: 'general',
                predecessor: [
                    taskSpec: [1000, 4475],
                ],
            ],

// LPAR moves

            [
                id: 4600,
                title:  '${it.custom7} ${it.assetName}: Shut down cluster services (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 11,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 4490,        // LPAR migrations must wait for gateway swings
                ],           
            ],
            [
                id: 4700,
                title:  '${it.custom7} ${it.assetName}: Shut down LPAR in CESC (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 5,
                filter: [
                    class: 'device',
                    group: 'LPAR_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                    taskSpec: 4490,        // LPAR migrations must wait for gateway swings
                ],           
            ],
            [
                id: 4800,
                title:  '${it.custom7} ${it.assetName}: Shut down LPAR in CESC (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 5,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],          
            ],
            [
                id: 4900,
                title:  '${it.custom7} ${it.assetName}: Break replication (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 10,
                filter: [
                    class: 'device',
                    group: 'LPAR_SERVERS',
                ],          
            ],
            [
                id: 5000,
                title:  '${it.custom7} ${it.assetName}: Break replication (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 10,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],          
            ],

            [
                id: 6300,
                title:  '${it.custom7} ${it.assetName}: Bring up LPAR in QTS, verify OS and NFS (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 15,
                filter: [
                    class: 'device',
                    group: [ 'LPAR_SERVERS', 'HA_LPAR_SERVERS' ],
                ],          
            ],
/*            [
                id: 6320,
                title:  '${it.assetName}: Verify backups (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 15,
                filter: [
                    class: 'device',
                    group: [ 'LPAR_SERVERS', 'HA_LPAR_SERVERS' ],
                ], 
                predecessor: [
                    taskSpec: [ 4490, 6300 ],
                ],         
            ], 
*/                                   
            [
                id: 6600,
                title:  '${it.custom7} ${it.assetName}: Start up cluster services (${it.custom4})',
                team: 'LPAR_SYS_ADMIN',
                sendNotification: true,
                duration: 11,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],      
            ],
           [
                id: 6650,
                title: '${it.assetName}: Application ready for startup (${it.custom4})',
                team: 'AUTO',
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'NON_TO_APPS',
                ],
                predecessor: [
                    classification: 'device',
                    mode: 'supports',
                ],           
            ],            
            [
                id: 6700,
                title: '${it.assetName}: Start up application (${it.custom4})',
                whom: '#startupBy',
                team: '',
                duration: '#startupDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: [ 'NON_AIS_APPS_WO_AIS', 'AIS_APPS' ],
                ],
                predecessor: [
                    taskSpec: [ 4490, 4495, 6650 ],
                ],           
            ],
            [
                id: 6740,
                title: '${it.assetName}: Put application into Read-write mode',
                whom: 'Santosh.Kota@dss.virginia.gov',
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'VaCMS_APP',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'supports',
                ],           
            ],
            [
                id: 6750,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
                whom: '#testingBy',
                team: '',
                duration: '#testingDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: [ 'AIS_APPS' ],
                ],  
            ],
            [
                id: 6800,
                title: '${it.assetName}: Start up application (${it.custom4})',
                whom: '#startupBy',
                team: '',
                duration: '#startupDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'NON_TO_APPS_W_AIS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'supports',
                    type: 'AIS',
                    taskSpec: [ 4490, 4495, 6650, 6740 ],
                ],           
            ],
            [
                id: 6900,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
                whom: '#testingBy',
                team: '',
                duration: '#testingDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'NON_AIS_APPS',
                ],  
            ],
            [
                id: 7000,
                title: '${it.assetName}: Conduct application testing and record results (${it.custom4})',
                whom: '#testingBy',
                team: '',
                duration: '#testingDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'TO_APPS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'supports',
                ], 
            ],            
/*            [
                id: 7010,
                title: '${it.assetName}: Conduct business application testing and record results (${it.custom4})',
                whom: 'will.murphy@vdot.virginia.gov',
                team: '',
                duration: '#testingDuration,7',             
                sendNotification: true,
                category: 'startup',
                filter: [
                    class: 'application',
                    group: 'VDOT_APPS',
                ], 
            ],           
*/          [
                id: 7050,
                title: 'All ${set} app testing tasks are complete',
                type: 'action',
                action: 'set',
                setOn: 'custom26',
                team: 'AUTO',
                category: 'moveday',
                filter: [
                    group: 'ALL_APPS',
                ],
            ],            
            [
                id: 7100,
                title:  '${it.assetName}: Delete replication pairs for migrated host (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 30,
                filter: [
                    class: 'device',
                    group: 'LPAR_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],           
            ],
            [
                id: 7200,
                title:  '${it.assetName}: Delete replication pairs for migrated host (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 30,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],           
            ],
            [
                id: 7300,
                title:  '${it.assetName}: Re enable replication set (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 30,
                filter: [
                    class: 'device',
                    group: 'LPAR_SERVERS',
                ],          
            ],
            [            
                id: 7400,
                title:  '${it.assetName}: Re enable replication set (${it.custom4})',
                team: 'LPAR_SAN_ADMIN',
                sendNotification: true,
                duration: 30,
                filter: [
                    class: 'device',
                    group: 'HA_LPAR_SERVERS',
                ],           
            ],
            [           
                id: 7500,
                title: '${it.assetName}: Unmute monitoring alerts (${it.custom4})',
                team: 'MONITORING_ADMIN',
                duration: 61,
                sendNotification: true,
                filter: [
                    group: 'ALL_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],
            ],           
            [
                id: 7600,
                title: '${it.assetName}: Confirm server is correctly configured for backups in QTS (${it.custom4})',
                team: 'BACKUP_ADMIN',
                sendNotification: true,
                filter: [
//                  group: 'V2V_SERVERS',
                    group: 'ALL_SERVERS',
                ],
                predecessor: [
                    classification: 'application',
                    mode: 'requires',
                ],
            ],
            [
                id: 7610,
                title:  'Backups configured, agent started for all moving LPARs',
                team: 'LPAR_SYS_ADMIN',
                duration: 15,
                type: 'action',
                action: 'set',
                setOn: 'assetType',                
                filter: [
                    class: 'device',
                    group: [ 'LPAR_SERVERS', 'HA_LPAR_SERVERS' ],
                ],          
            ],
            [
                id: 7700,
                title: '${it.assetName}: backup, monitoring, etc. tasks complete',
                team: 'AUTO',
                filter: [
                    group: 'ALL_SERVERS',
                ],
                predecessor: [
                    taskSpec: [ 7300, 7400, 7500, 7600, 7610 ],
                ],
            ],
/*          [
                id: 7750,
                title: '${it.assetName}: Update asset management records with changes to location and backup method',
                team: 'ASSET_MGT',
                sendNotification: true,
                filter: [
                    group: 'ALL_SERVERS',
                ],
            ],
*/          [
                id: 7800,
                title: '${it.assetName}: All server tasks, testing complete',
                team: 'AUTO',
                duration: 1,                
                filter: [
                    group: 'ALL_APPS',
                ],
                predecessor: [
                    classification: 'device',
                    mode: 'supports',
                ],
            ],
            [
                id: 7900,
                title: 'All move event tasks complete',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
                team: 'AUTO',
                duration: 7,                
                filter: [
                    group: 'ALL_APPS',
                ],
            ],                                           
            [
                id: 7910,
                title: 'Confirm JOC (804 416 7952 / vitajoc@vita.virginia.gov) notified of event completion, change record marked as complete',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
                team: 'PROJ_MGR',
                duration: 7,                
                filter: [
                    group: 'ALL_APPS',
                ],
            ],
            [
                id: 7920,
                title: 'Notify asset management team to update CMDB records for moved servers as required',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
                team: 'PROJ_MGR',
                duration: 7,                
                filter: [
                    group: 'ALL_APPS',
                ],
                predecessor: [ taskSpec: 7900 ],
            ],
            [
                id: 7930,
                title: 'Confirm that CMDB records for moved servers were updated as required',
                type: 'action',
                action: 'set',
                setOn: 'assetType',
//                team: 'ASSET_MGT',
                team: 'PROJ_MGR',
                duration: 7,                
                filter: [
                    group: 'ALL_APPS',
                ],
                predecessor: [ taskSpec: [ 7910, 7920 ] ],
            ],          
            [
                id: 10000,
                title: 'Move event complete',
                type: 'milestone',
                team: 'PROJ_MGR',
                category: 'moveday',
            ],
        ],


