function Get-D42Assets {
    param(
    )
    Get-D42Data -table "assets"
	
}