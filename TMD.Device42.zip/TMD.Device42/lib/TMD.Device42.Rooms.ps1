function Get-D42Rooms {
	Get-D42Data -table "rooms"
	
}
