
function Get-D42Devices {
    Get-D42Data -table "devices"
}