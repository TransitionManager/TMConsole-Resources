function Get-D42AppCompsDetail {
	param (
		$Server,
		$Credential,
		$AppComp
	)
		
	$uri = "https://$Server/api/1.0/appcomps/" + $AppComp.appcomp_id + "/"
		
	try {
		$response = Invoke-RestMethod -Headers $appConfig.Device42.Headers -Credential $Credential -Method 'GET' -Uri $uri -SkipCertificateCheck -Authentication Basic
		return $response
			
	} catch {
		Write-Host "Something went wrong"
		Write-Host -ForegroundColor Yellow $_
	}
		
}
	