## Define a map of Major Versions to an API Endpoint Table
$Global:Api20EndpointsByVersion = @{

	## Device42 Major version 16 -- API endpoints in v2.0
	'16' = @(
		'device_ignore_rules',
		'listener_connection_stats',
		'scheduled_tasks',
		'services',
		'service_instances',
		'service_listener_ports',
		'service_client_connections',
		'ignored_service'
	)
	
	## Device42 Major version 17 -- API endpoints in v2.0
	'17' = @(
		'device_ignore_rules',
		'listener_connection_stats',
		'scheduled_tasks',
		'services',
		'service_details',
		'service_instances',
		'service_listener_ports',
		'service_client_connections',
		'ignored_service'
	)
}


function Get-D42Data {
	param (
		$Table,
		$Server,
		$Limit = -1,
		[pscredential]$Credential,
		[Int16]$D42MajorVersion = 17
	)

	
	## Build the URI
	$uri = 'https://'
	$uri += $Server
	$uri += '/api/'
	
	
	## Collect the Endpoints available in v2 for this major versino
	$v2Endpoints = $Global:Api20EndpointsByVersion[$D42MajorVersion.toString()]


	## Assign the correct API Version to the request
	if ($Table -in $v2Endpoints) {
		$uri += '2.0/'
	} else {
		## Everything else uses 1.0
		$uri += '1.0/'
	}


	## Handle Changes to the standard table name structure
	if ($table -eq "devices") {
		$uri += "devices/all"
	} else {
		$uri += $Table + '/'
	}

	## Handle Limit Setting, append to URI
	if ($Limit -gt -1 ) {
		$resultSize = $Limit
		$restMethodParms = @{ }
		$uri += "?limit=" + $resultSize
	} else {
		$resultSize = 500
		$restMethodParms = @{FollowRelLink = $true; }
	}

	## Invoke the Web Request
	try {
		$Response = Invoke-RestMethod -Headers $global:Device42Headers -Credential $Credential -Method 'GET' -Uri $uri @restMethodParms -SkipCertificateCheck -Authentication Basic
	} catch {
		Write-Error -Message $_
		Throw $_
	}

	return ($Response).$Table
	
}