function Get-D42Buildings {
	param(
		[Parameter(Mandatory = $false)][Switch]$ShowMenu
	)
	Get-D42Data -table "buildings"
}